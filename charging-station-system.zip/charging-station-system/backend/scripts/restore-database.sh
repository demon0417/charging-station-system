#!/bin/bash

# 数据库恢复脚本
DB_HOST=${1:-localhost}
DB_PORT=${2:-3306}
DB_NAME=${3:-charging_station}
DB_USER=${4:-root}
DB_PASS=${5:-root}
BACKUP_FILE=$6

# 验证参数
if [ -z "$BACKUP_FILE" ]; then
    echo "Usage: $0 [host] [port] [database] [user] [password] backup_file"
    exit 1
fi

if [ ! -f "$BACKUP_FILE" ]; then
    echo "Backup file not found: $BACKUP_FILE"
    exit 1
fi

# 执行恢复
echo "Starting database restore from $BACKUP_FILE..."
mysql -h "$DB_HOST" -P "$DB_PORT" -u "$DB_USER" -p"$DB_PASS" "$DB_NAME" < "$BACKUP_FILE"

if [ $? -eq 0 ]; then
    echo "Database restore completed successfully"
else
    echo "Database restore failed"
    exit 1
fi 