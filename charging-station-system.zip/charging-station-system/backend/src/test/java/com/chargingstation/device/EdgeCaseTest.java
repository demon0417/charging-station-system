package com.chargingstation.device;

import com.chargingstation.device.command.BatchCommandProcessor;
import com.chargingstation.device.command.PriorityCommandQueue;
import com.chargingstation.device.exception.DeviceCommunicationException;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeoutException;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
class EdgeCaseTest {

    @Autowired
    private BatchCommandProcessor batchProcessor;
    
    @Autowired
    private PriorityCommandQueue priorityQueue;
    
    @Test
    void emptyCommandTest() {
        // 测试空指令
        byte[] emptyCommand = new byte[0];
        Map<String, byte[]> commands = new HashMap<>();
        commands.put("DEVICE_001", emptyCommand);
        
        assertThrows(ValidationException.class, 
            () -> batchProcessor.sendBatchCommands(commands, 1000));
    }
    
    @Test
    void maximumCommandSizeTest() {
        // 测试最大指令大小
        byte[] largeCommand = new byte[1024 * 1024]; // 1MB
        Map<String, byte[]> commands = new HashMap<>();
        commands.put("DEVICE_001", largeCommand);
        
        assertThrows(ValidationException.class, 
            () -> batchProcessor.sendBatchCommands(commands, 1000));
    }
    
    @Test
    void zeroTimeoutTest() {
        // 测试超时时间为0
        Map<String, byte[]> commands = new HashMap<>();
        commands.put("DEVICE_001", new byte[]{0x01});
        
        assertThrows(IllegalArgumentException.class, 
            () -> batchProcessor.sendBatchCommands(commands, 0));
    }
    
    @Test
    void negativeTimeoutTest() {
        // 测试负超时时间
        Map<String, byte[]> commands = new HashMap<>();
        commands.put("DEVICE_001", new byte[]{0x01});
        
        assertThrows(IllegalArgumentException.class, 
            () -> batchProcessor.sendBatchCommands(commands, -1000));
    }
    
    @Test
    void maximumQueueSizeTest() {
        // 测试队列容量上限
        String deviceId = "DEVICE_001";
        int maxCommands = 10000;
        
        for (int i = 0; i < maxCommands; i++) {
            PrioritizedCommand command = new PrioritizedCommand(
                "CMD_" + i,
                new byte[]{0x01},
                CommandPriority.NORMAL,
                1000,
                System.currentTimeMillis()
            );
            priorityQueue.enqueue(deviceId, command);
        }
        
        // 验证队列大小
        assertTrue(priorityQueue.getQueueSize(deviceId) <= maxCommands);
    }
    
    @Test
    void specialCharacterDeviceIdTest() {
        // 测试特殊字符设备ID
        String[] specialDeviceIds = {
            "DEVICE#1",
            "DEVICE@2",
            "DEVICE/3",
            "DEVICE\\4",
            "DEVICE 5"
        };
        
        for (String deviceId : specialDeviceIds) {
            Map<String, byte[]> commands = new HashMap<>();
            commands.put(deviceId, new byte[]{0x01});
            
            assertThrows(ValidationException.class, 
                () -> batchProcessor.sendBatchCommands(commands, 1000));
        }
    }
    
    @Test
    void concurrentQueueAccessTest() throws Exception {
        // 测试并发队列访问
        String deviceId = "DEVICE_001";
        int threadCount = 100;
        
        Thread[] threads = new Thread[threadCount];
        for (int i = 0; i < threadCount; i++) {
            final int index = i;
            threads[i] = new Thread(() -> {
                try {
                    PrioritizedCommand command = new PrioritizedCommand(
                        "CMD_" + index,
                        new byte[]{0x01},
                        CommandPriority.NORMAL,
                        1000,
                        System.currentTimeMillis()
                    );
                    priorityQueue.enqueue(deviceId, command);
                } catch (Exception e) {
                    fail("并发访问应该成功");
                }
            });
        }
        
        // 启动所有线程
        for (Thread thread : threads) {
            thread.start();
        }
        
        // 等待所有线程完成
        for (Thread thread : threads) {
            thread.join();
        }
        
        // 验证队列状态
        assertTrue(priorityQueue.getQueueSize(deviceId) <= threadCount);
    }
    
    @Test
    void malformedCommandTest() {
        // 测试格式错误的指令
        byte[][] malformedCommands = {
            {0x01}, // 长度不足
            {0x01, 0x02, 0x03, (byte)0xFF}, // 无效功能码
            null, // 空指令
            new byte[]{} // 空数组
        };
        
        for (byte[] command : malformedCommands) {
            Map<String, byte[]> commands = new HashMap<>();
            commands.put("DEVICE_001", command);
            
            assertThrows(ValidationException.class, 
                () -> batchProcessor.sendBatchCommands(commands, 1000));
        }
    }
} 