package com.chargingstation.accessibility;

import com.deque.html.axe.AXE;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;

import java.net.URL;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class AccessibilityTest {

    @LocalServerPort
    private int port;

    private WebDriver driver;

    @BeforeEach
    void setUp() {
        driver = new ChromeDriver();
    }

    @AfterEach
    void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test
    void pageShouldBeAccessible() {
        // 测试主要页面的可访问性
        String[] pages = {
            "/login",
            "/dashboard",
            "/vehicle",
            "/charging",
            "/parking"
        };

        for (String page : pages) {
            driver.get("http://localhost:" + port + page);
            JSONObject violations = new AXE.Builder(driver, getAxeScriptUrl())
                .analyze()
                .getViolations();

            assertTrue(violations.length() == 0,
                "页面 " + page + " 存在可访问性问题: " + violations.toString(2));
        }
    }

    @Test
    void keyboardNavigationShouldWork() {
        driver.get("http://localhost:" + port);

        // 测试键盘导航
        WebElement firstElement = driver.findElement(By.id("username"));
        firstElement.sendKeys(Keys.TAB);
        
        WebElement activeElement = driver.switchTo().activeElement();
        assertEquals("password", activeElement.getAttribute("id"));

        // 继续Tab导航
        activeElement.sendKeys(Keys.TAB);
        activeElement = driver.switchTo().activeElement();
        assertEquals("login-button", activeElement.getAttribute("id"));
    }

    @Test
    void screenReaderCompatibility() {
        driver.get("http://localhost:" + port);

        // 验证ARIA标签
        List<WebElement> elements = driver.findElements(By.cssSelector("[aria-label]"));
        assertFalse(elements.isEmpty());

        // 验证图片替代文本
        List<WebElement> images = driver.findElements(By.tagName("img"));
        for (WebElement image : images) {
            assertNotNull(image.getAttribute("alt"));
        }

        // 验证表单标签
        List<WebElement> inputs = driver.findElements(By.tagName("input"));
        for (WebElement input : inputs) {
            assertTrue(hasAssociatedLabel(input));
        }
    }

    @Test
    void colorContrastShouldBeAdequate() {
        driver.get("http://localhost:" + port);

        // 检查文本元素的颜色对比度
        List<WebElement> textElements = driver.findElements(
            By.cssSelector("p, h1, h2, h3, h4, h5, h6, span, a")
        );

        for (WebElement element : textElements) {
            String backgroundColor = element.getCssValue("background-color");
            String color = element.getCssValue("color");
            
            assertTrue(hasAdequateContrast(backgroundColor, color),
                "颜色对比度不足: " + element.getText());
        }
    }

    @Test
    void focusIndicatorsShouldBeVisible() {
        driver.get("http://localhost:" + port);

        // 检查所有可聚焦元素的焦点指示器
        List<WebElement> focusableElements = driver.findElements(
            By.cssSelector("a, button, input, select, textarea, [tabindex]")
        );

        for (WebElement element : focusableElements) {
            element.sendKeys(Keys.TAB);
            String outlineStyle = element.getCssValue("outline-style");
            assertNotEquals("none", outlineStyle);
        }
    }

    private URL getAxeScriptUrl() {
        return AccessibilityTest.class.getResource("/axe.min.js");
    }

    private boolean hasAssociatedLabel(WebElement input) {
        String id = input.getAttribute("id");
        if (id != null && !id.isEmpty()) {
            return !driver.findElements(By.cssSelector("label[for='" + id + "']")).isEmpty();
        }
        return false;
    }

    private boolean hasAdequateContrast(String backgroundColor, String color) {
        // 实现WCAG 2.0颜色对比度计算
        // 至少应达到4.5:1的对比度
        return calculateContrastRatio(backgroundColor, color) >= 4.5;
    }

    private double calculateContrastRatio(String backgroundColor, String color) {
        // 将颜色值转换为相对亮度并计算对比度
        double bgLuminance = calculateRelativeLuminance(backgroundColor);
        double fgLuminance = calculateRelativeLuminance(color);
        
        double lighter = Math.max(bgLuminance, fgLuminance);
        double darker = Math.min(bgLuminance, fgLuminance);
        
        return (lighter + 0.05) / (darker + 0.05);
    }

    private double calculateRelativeLuminance(String color) {
        // 实现相对亮度计算
        // 这里是简化实现
        return 0.5;
    }
} 