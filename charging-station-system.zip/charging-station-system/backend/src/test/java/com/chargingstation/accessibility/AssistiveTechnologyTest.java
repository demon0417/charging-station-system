package com.chargingstation.accessibility;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class AssistiveTechnologyTest {

    @LocalServerPort
    private int port;

    private WebDriver driver;

    @BeforeEach
    void setUp() {
        driver = new ChromeDriver();
    }

    @AfterEach
    void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test
    void screenReaderCompatibility() {
        // 测试屏幕阅读器兼容性
        driver.get("http://localhost:" + port);

        // 验证所有图片都有替代文本
        List<WebElement> images = driver.findElements(By.tagName("img"));
        for (WebElement image : images) {
            assertNotNull(image.getAttribute("alt"), 
                "图片缺少替代文本: " + image.getAttribute("src"));
        }

        // 验证所有表单控件都有标签
        List<WebElement> formControls = driver.findElements(
            By.cssSelector("input, select, textarea")
        );
        for (WebElement control : formControls) {
            assertTrue(hasAssociatedLabel(control),
                "表单控件缺少标签: " + control.getAttribute("id"));
        }

        // 验证所有按钮都有可访问的名称
        List<WebElement> buttons = driver.findElements(By.tagName("button"));
        for (WebElement button : buttons) {
            assertTrue(hasAccessibleName(button),
                "按钮缺少可访问名称: " + button.getAttribute("id"));
        }
    }

    @Test
    void keyboardNavigation() {
        // 测试键盘导航
        driver.get("http://localhost:" + port);

        // 验证焦点顺序
        List<WebElement> focusableElements = driver.findElements(
            By.cssSelector("a, button, input, select, textarea, [tabindex]")
        );

        for (WebElement element : focusableElements) {
            element.sendKeys(Keys.TAB);
            WebElement activeElement = driver.switchTo().activeElement();
            assertTrue(isLogicalTabOrder(element, activeElement),
                "Tab键顺序不合理");
        }

        // 验证快捷键
        Map<String, String> shortcuts = Map.of(
            "Alt+S", "搜索",
            "Alt+H", "帮助",
            "Alt+M", "菜单"
        );

        for (Map.Entry<String, String> shortcut : shortcuts.entries()) {
            assertTrue(isShortcutWorking(shortcut.getKey(), shortcut.getValue()),
                "快捷键不工作: " + shortcut.getKey());
        }
    }

    @Test
    void colorContrastAndVisibility() {
        // 测试颜色对比度和可见性
        driver.get("http://localhost:" + port);

        // 验证文本对比度
        List<WebElement> textElements = driver.findElements(
            By.cssSelector("p, h1, h2, h3, h4, h5, h6, span, a")
        );

        for (WebElement element : textElements) {
            String backgroundColor = element.getCssValue("background-color");
            String color = element.getCssValue("color");
            assertTrue(hasAdequateContrast(backgroundColor, color),
                "文本对比度不足: " + element.getText());
        }

        // 验证焦点指示器可见性
        List<WebElement> focusableElements = driver.findElements(
            By.cssSelector("a, button, input, select, textarea, [tabindex]")
        );

        for (WebElement element : focusableElements) {
            element.sendKeys(Keys.TAB);
            assertTrue(hasFocusIndicator(element),
                "缺少焦点指示器: " + element.getAttribute("id"));
        }
    }

    @Test
    void textResizing() {
        // 测试文本缩放
        driver.get("http://localhost:" + port);

        // 测试不同文本大小
        int[] textSizes = {100, 125, 150, 175, 200};
        
        for (int size : textSizes) {
            setTextSize(size);
            assertTrue(isContentReadable(),
                "文本大小 " + size + "% 时内容不可读");
            assertFalse(isContentOverlapping(),
                "文本大小 " + size + "% 时内容重叠");
        }
    }

    private boolean hasAssociatedLabel(WebElement control) {
        String id = control.getAttribute("id");
        if (id != null && !id.isEmpty()) {
            return !driver.findElements(By.cssSelector("label[for='" + id + "']")).isEmpty();
        }
        return false;
    }

    private boolean hasAccessibleName(WebElement element) {
        return !element.getAttribute("aria-label").isEmpty() ||
               !element.getAttribute("aria-labelledby").isEmpty() ||
               !element.getText().isEmpty();
    }

    private boolean isLogicalTabOrder(WebElement current, WebElement next) {
        // 实现Tab键顺序的逻辑验证
        return true;
    }

    private boolean isShortcutWorking(String shortcut, String expectedAction) {
        // 实现快捷键测试
        return true;
    }

    private boolean hasAdequateContrast(String backgroundColor, String color) {
        // 实现WCAG对比度计算
        return true;
    }

    private boolean hasFocusIndicator(WebElement element) {
        return !element.getCssValue("outline").equals("none");
    }

    private void setTextSize(int percentage) {
        // 实现文本大小调整
        ((JavascriptExecutor) driver).executeScript(
            "document.body.style.zoom='" + percentage + "%'"
        );
    }

    private boolean isContentReadable() {
        // 实现内容可读性检查
        return true;
    }

    private boolean isContentOverlapping() {
        // 实现内容重叠检查
        return false;
    }
} 