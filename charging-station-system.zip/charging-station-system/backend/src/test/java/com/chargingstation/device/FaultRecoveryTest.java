package com.chargingstation.device;

import com.chargingstation.device.recovery.DeviceRecoveryManager;
import com.chargingstation.device.simulator.DeviceSimulator;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
@ActiveProfiles("test")
class FaultRecoveryTest {

    @Autowired
    private DeviceRecoveryManager recoveryManager;
    
    @Autowired
    private DeviceSimulator deviceSimulator;
    
    @Test
    void networkDisconnectionRecovery() throws Exception {
        String deviceId = "DEVICE_001";
        CountDownLatch recoveryLatch = new CountDownLatch(1);
        
        // 模拟网络断开
        simulateNetworkFailure(deviceId);
        
        // 触发自动恢复
        recoveryManager.startRecovery(deviceId);
        
        // 等待恢复完成
        boolean recovered = recoveryLatch.await(10, TimeUnit.SECONDS);
        assertTrue(recovered, "设备应该在10秒内恢复");
        
        // 验证设备状态
        assertTrue(deviceSimulator.isDeviceOnline(deviceId));
        assertNull(deviceSimulator.getLastError(deviceId));
    }
    
    @Test
    void multipleDeviceFailureRecovery() throws Exception {
        int deviceCount = 5;
        List<String> deviceIds = new ArrayList<>();
        CountDownLatch recoveryLatch = new CountDownLatch(deviceCount);
        
        // 模拟多个设备故障
        for (int i = 0; i < deviceCount; i++) {
            String deviceId = "DEVICE_" + i;
            deviceIds.add(deviceId);
            simulateRandomFailure(deviceId);
        }
        
        // 触发批量恢复
        deviceIds.forEach(recoveryManager::startRecovery);
        
        // 等待所有设备恢复
        boolean allRecovered = recoveryLatch.await(30, TimeUnit.SECONDS);
        assertTrue(allRecovered, "所有设备应该在30秒内恢复");
        
        // 验证所有设备状态
        for (String deviceId : deviceIds) {
            assertTrue(deviceSimulator.isDeviceOnline(deviceId));
            assertNull(deviceSimulator.getLastError(deviceId));
        }
    }
    
    @Test
    void cascadingFailureRecovery() throws Exception {
        List<String> deviceIds = List.of("DEVICE_001", "DEVICE_002", "DEVICE_003");
        
        // 模拟级联故障
        simulateCascadingFailure(deviceIds);
        
        // 触发恢复
        for (String deviceId : deviceIds) {
            recoveryManager.startRecovery(deviceId);
        }
        
        // 等待恢复完成
        Thread.sleep(5000);
        
        // 验证恢复顺序和最终状态
        for (String deviceId : deviceIds) {
            assertTrue(deviceSimulator.isDeviceOnline(deviceId));
            assertNull(deviceSimulator.getLastError(deviceId));
        }
    }
    
    @Test
    void partialRecoveryScenario() throws Exception {
        String deviceId = "DEVICE_001";
        
        // 模拟部分功能故障
        simulatePartialFailure(deviceId);
        
        // 尝试恢复
        recoveryManager.startRecovery(deviceId);
        
        // 等待恢复尝试
        Thread.sleep(3000);
        
        // 验证部分功能恢复
        assertTrue(deviceSimulator.isDeviceOnline(deviceId));
        assertNotNull(deviceSimulator.getPartialFunctions(deviceId));
        assertTrue(deviceSimulator.getPartialFunctions(deviceId).size() > 0);
    }
    
    private void simulateNetworkFailure(String deviceId) {
        deviceSimulator.disconnect(deviceId);
    }
    
    private void simulateRandomFailure(String deviceId) {
        int failureType = (int) (Math.random() * 3);
        switch (failureType) {
            case 0 -> deviceSimulator.disconnect(deviceId);
            case 1 -> deviceSimulator.simulateHardwareFailure(deviceId);
            case 2 -> deviceSimulator.simulateSoftwareFailure(deviceId);
        }
    }
    
    private void simulateCascadingFailure(List<String> deviceIds) {
        for (int i = 0; i < deviceIds.size(); i++) {
            String deviceId = deviceIds.get(i);
            if (i == 0) {
                deviceSimulator.disconnect(deviceId);
            } else {
                deviceSimulator.simulateDependencyFailure(deviceId, deviceIds.get(i - 1));
            }
        }
    }
    
    private void simulatePartialFailure(String deviceId) {
        deviceSimulator.simulatePartialFailure(deviceId, List.of("charging", "monitoring"));
    }
} 