package com.chargingstation.services;

import com.chargingstation.models.ChargingRecord;
import com.chargingstation.models.Vehicle;
import com.chargingstation.repositories.ChargingRecordRepository;
import com.chargingstation.repositories.VehicleRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ChargingServiceTest {

    @Mock
    private ChargingRecordRepository chargingRecordRepository;

    @Mock
    private VehicleRepository vehicleRepository;

    @InjectMocks
    private ChargingService chargingService;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(chargingService, "ratePerKWh", new BigDecimal("1.5"));
    }

    @Test
    void calculateChargingFee_Success() {
        BigDecimal powerConsumption = new BigDecimal("10.0"); // 10度电
        BigDecimal expectedFee = new BigDecimal("15.00"); // 1.5元/度 * 10度

        BigDecimal fee = ReflectionTestUtils.invokeMethod(chargingService, 
            "calculateChargingFee", powerConsumption);

        assertEquals(expectedFee, fee);
    }

    @Test
    void startCharging_Success() {
        Vehicle vehicle = new Vehicle();
        vehicle.setId(1L);

        when(vehicleRepository.findById(1L)).thenReturn(Optional.of(vehicle));
        when(chargingRecordRepository.findActiveRecordByVehicleId(1L)).thenReturn(Optional.empty());
        when(chargingRecordRepository.save(any(ChargingRecord.class))).thenAnswer(i -> i.getArgument(0));

        ChargingRecord record = chargingService.startCharging(1L);

        assertNotNull(record);
        assertEquals(vehicle, record.getVehicle());
        assertNotNull(record.getStartTime());
        assertNull(record.getEndTime());
    }

    @Test
    void stopCharging_Success() {
        Vehicle vehicle = new Vehicle();
        vehicle.setId(1L);

        ChargingRecord activeRecord = new ChargingRecord();
        activeRecord.setVehicle(vehicle);
        activeRecord.setStartTime(LocalDateTime.now().minusHours(1));

        when(chargingRecordRepository.findActiveRecordByVehicleId(1L))
            .thenReturn(Optional.of(activeRecord));
        when(chargingRecordRepository.save(any(ChargingRecord.class)))
            .thenAnswer(i -> i.getArgument(0));

        BigDecimal powerConsumption = new BigDecimal("10.0");
        ChargingRecord record = chargingService.stopCharging(1L, powerConsumption);

        assertNotNull(record);
        assertNotNull(record.getEndTime());
        assertEquals(new BigDecimal("15.00"), record.getChargingFee());
    }
} 