package com.chargingstation.services;

import com.chargingstation.dto.LicenseRecognitionResult;
import com.chargingstation.exceptions.RecognitionException;
import com.chargingstation.models.enums.VehicleType;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.*;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.util.Base64;
import java.util.Map;
import java.util.concurrent.TimeoutException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LicenseRecognitionServiceTest {

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private LicenseRecognitionService service;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(service, "apiUrl", "http://api.example.com");
        ReflectionTestUtils.setField(service, "apiKey", "test-api-key");
        ReflectionTestUtils.setField(service, "timeout", 5000);
        ReflectionTestUtils.setField(service, "minConfidence", 0.8);
    }

    @Test
    void recognizeLicense_Success() throws Exception {
        // 准备测试数据
        String imageBase64 = Base64.getEncoder().encodeToString(
            new byte[]{(byte) 0xFF, (byte) 0xD8, 0x00, 0x00} // JPEG文件头
        );
        
        String responseJson = """
            {
                "success": true,
                "data": {
                    "plate_number": "京A12345",
                    "vehicle_type": "小型汽车",
                    "confidence": 0.95
                }
            }
            """;
            
        Map<String, Object> responseMap = Map.of(
            "success", true,
            "data", Map.of(
                "plate_number", "京A12345",
                "vehicle_type", "小型汽车",
                "confidence", 0.95
            )
        );

        // Mock API响应
        when(restTemplate.exchange(
            anyString(),
            eq(HttpMethod.POST),
            any(HttpEntity.class),
            eq(String.class)
        )).thenReturn(new ResponseEntity<>(responseJson, HttpStatus.OK));
        
        when(objectMapper.readValue(responseJson, Map.class))
            .thenReturn(responseMap);

        // 执行测试
        LicenseRecognitionResult result = service.recognizeLicense(imageBase64);

        // 验证结果
        assertNotNull(result);
        assertEquals("京A12345", result.getPlateNumber());
        assertEquals(VehicleType.SMALL, result.getVehicleType());
        assertEquals(0.95, result.getConfidence());
    }

    @Test
    void recognizeLicense_InvalidImage() {
        // 准备无效的Base64数据
        String invalidBase64 = "invalid-base64";

        // 执行测试并验证异常
        RecognitionException exception = assertThrows(
            RecognitionException.class,
            () -> service.recognizeLicense(invalidBase64)
        );
        
        assertTrue(exception.getMessage().contains("Base64编码无效"));
    }

    @Test
    void recognizeLicense_LowConfidence() throws Exception {
        // 准备测试数据
        String imageBase64 = Base64.getEncoder().encodeToString(
            new byte[]{(byte) 0xFF, (byte) 0xD8, 0x00, 0x00}
        );
        
        Map<String, Object> responseMap = Map.of(
            "success", true,
            "data", Map.of(
                "plate_number", "京A12345",
                "vehicle_type", "小型汽车",
                "confidence", 0.5
            )
        );

        // Mock API响应
        when(restTemplate.exchange(
            anyString(),
            eq(HttpMethod.POST),
            any(HttpEntity.class),
            eq(String.class)
        )).thenReturn(new ResponseEntity<>(objectMapper.writeValueAsString(responseMap), HttpStatus.OK));
        
        when(objectMapper.readValue(anyString(), eq(Map.class)))
            .thenReturn(responseMap);

        // 执行测试并验证异常
        RecognitionException exception = assertThrows(
            RecognitionException.class,
            () -> service.recognizeLicense(imageBase64)
        );
        
        assertTrue(exception.getMessage().contains("识别置信度"));
    }

    @Test
    void recognizeLicense_Timeout() {
        // 准备测试数据
        String imageBase64 = Base64.getEncoder().encodeToString(
            new byte[]{(byte) 0xFF, (byte) 0xD8, 0x00, 0x00}
        );

        // Mock超时异常
        when(restTemplate.exchange(
            anyString(),
            eq(HttpMethod.POST),
            any(HttpEntity.class),
            eq(String.class)
        )).thenThrow(new TimeoutException("API请求超时"));

        // 执行测试并验证异常
        RecognitionException exception = assertThrows(
            RecognitionException.class,
            () -> service.recognizeLicense(imageBase64)
        );
        
        assertTrue(exception.getMessage().contains("识别服务超时"));
    }

    @Test
    void recognizeLicense_InvalidPlateNumber() throws Exception {
        // 准备测试数据
        String imageBase64 = Base64.getEncoder().encodeToString(
            new byte[]{(byte) 0xFF, (byte) 0xD8, 0x00, 0x00}
        );
        
        Map<String, Object> responseMap = Map.of(
            "success", true,
            "data", Map.of(
                "plate_number", "INVALID",
                "vehicle_type", "小型汽车",
                "confidence", 0.9
            )
        );

        // Mock API响应
        when(restTemplate.exchange(
            anyString(),
            eq(HttpMethod.POST),
            any(HttpEntity.class),
            eq(String.class)
        )).thenReturn(new ResponseEntity<>(objectMapper.writeValueAsString(responseMap), HttpStatus.OK));
        
        when(objectMapper.readValue(anyString(), eq(Map.class)))
            .thenReturn(responseMap);

        // 执行测试并验证异常
        RecognitionException exception = assertThrows(
            RecognitionException.class,
            () -> service.recognizeLicense(imageBase64)
        );
        
        assertTrue(exception.getMessage().contains("车牌格式无效"));
    }
} 