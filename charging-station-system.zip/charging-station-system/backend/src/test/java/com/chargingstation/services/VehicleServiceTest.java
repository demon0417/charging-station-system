package com.chargingstation.services;

import com.chargingstation.dto.VehicleDTO;
import com.chargingstation.exceptions.DuplicateResourceException;
import com.chargingstation.exceptions.ValidationException;
import com.chargingstation.models.Vehicle;
import com.chargingstation.models.enums.VehicleType;
import com.chargingstation.repositories.VehicleRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class VehicleServiceTest {

    @Mock
    private VehicleRepository vehicleRepository;

    @InjectMocks
    private VehicleService vehicleService;

    private VehicleDTO validVehicleDTO;
    private Vehicle mockVehicle;

    @BeforeEach
    void setUp() {
        validVehicleDTO = new VehicleDTO();
        validVehicleDTO.setPlateNumber("京A12345");
        validVehicleDTO.setVehicleType(VehicleType.SMALL);
        validVehicleDTO.setEntryTime(LocalDateTime.now());

        mockVehicle = new Vehicle();
        mockVehicle.setId(1L);
        mockVehicle.setPlateNumber("京A12345");
        mockVehicle.setVehicleType(VehicleType.SMALL);
        mockVehicle.setEntryTime(LocalDateTime.now());
    }

    @Test
    void createVehicle_WithValidData_ShouldSucceed() {
        when(vehicleRepository.existsByPlateNumber(anyString())).thenReturn(false);
        when(vehicleRepository.save(any(Vehicle.class))).thenReturn(mockVehicle);

        Vehicle result = vehicleService.createVehicle(validVehicleDTO);

        assertNotNull(result);
        assertEquals(mockVehicle.getPlateNumber(), result.getPlateNumber());
        verify(vehicleRepository).save(any(Vehicle.class));
    }

    @Test
    void createVehicle_WithEmptyPlateNumber_ShouldThrowException() {
        validVehicleDTO.setPlateNumber("");

        ValidationException exception = assertThrows(
            ValidationException.class,
            () -> vehicleService.createVehicle(validVehicleDTO)
        );

        assertTrue(exception.getMessage().contains("车牌号不能为空"));
    }

    @Test
    void createVehicle_WithInvalidPlateNumber_ShouldThrowException() {
        validVehicleDTO.setPlateNumber("INVALID");

        ValidationException exception = assertThrows(
            ValidationException.class,
            () -> vehicleService.createVehicle(validVehicleDTO)
        );

        assertTrue(exception.getMessage().contains("车牌号格式不正确"));
    }

    @Test
    void createVehicle_WithDuplicatePlateNumber_ShouldThrowException() {
        when(vehicleRepository.existsByPlateNumber(anyString())).thenReturn(true);

        DuplicateResourceException exception = assertThrows(
            DuplicateResourceException.class,
            () -> vehicleService.createVehicle(validVehicleDTO)
        );

        assertTrue(exception.getMessage().contains("车牌号已存在"));
    }

    @Test
    void getVehicleByPlateNumber_WithExistingPlate_ShouldReturnVehicle() {
        when(vehicleRepository.findByPlateNumber(anyString()))
            .thenReturn(Optional.of(mockVehicle));

        Vehicle result = vehicleService.getVehicleByPlateNumber("京A12345");

        assertNotNull(result);
        assertEquals(mockVehicle.getPlateNumber(), result.getPlateNumber());
    }

    @Test
    void getCurrentParkedVehicles_ShouldReturnList() {
        LocalDateTime now = LocalDateTime.now();
        when(vehicleRepository.findCurrentParkedVehicles(any(LocalDateTime.class)))
            .thenReturn(List.of(mockVehicle));

        List<Vehicle> result = vehicleService.getCurrentParkedVehicles();

        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
    }

    @Test
    void batchRecordExit_ShouldUpdateExitTime() {
        List<Long> vehicleIds = List.of(1L, 2L);
        when(vehicleRepository.batchUpdateExitTime(anyList(), any(LocalDateTime.class)))
            .thenReturn(2);

        int updatedCount = vehicleService.batchRecordExit(vehicleIds);

        assertEquals(2, updatedCount);
        verify(vehicleRepository).batchUpdateExitTime(eq(vehicleIds), any(LocalDateTime.class));
    }
} 