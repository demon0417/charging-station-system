package com.chargingstation.services;

import com.chargingstation.exceptions.ResourceNotFoundException;
import com.chargingstation.models.ParkingRecord;
import com.chargingstation.models.Vehicle;
import com.chargingstation.repositories.ParkingRecordRepository;
import com.chargingstation.repositories.VehicleRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ParkingServiceTest {

    @Mock
    private ParkingRecordRepository parkingRecordRepository;

    @Mock
    private VehicleRepository vehicleRepository;

    @InjectMocks
    private ParkingService parkingService;

    private Vehicle mockVehicle;
    private ParkingRecord mockParkingRecord;

    @BeforeEach
    void setUp() {
        // 设置配置值
        ReflectionTestUtils.setField(parkingService, "freeDurationSeconds", 7200L); // 2小时
        ReflectionTestUtils.setField(parkingService, "hourlyRate", new BigDecimal("5")); // 5元/小时

        mockVehicle = new Vehicle();
        mockVehicle.setId(1L);
        mockVehicle.setPlateNumber("京A12345");

        mockParkingRecord = new ParkingRecord();
        mockParkingRecord.setId(1L);
        mockParkingRecord.setVehicle(mockVehicle);
        mockParkingRecord.setStartTime(LocalDateTime.now().minusHours(3));
    }

    @Test
    void startParking_WithValidVehicle_ShouldCreateRecord() {
        when(vehicleRepository.findById(anyLong())).thenReturn(Optional.of(mockVehicle));
        when(parkingRecordRepository.findActiveRecordByVehicleId(anyLong()))
            .thenReturn(Optional.empty());
        when(parkingRecordRepository.save(any(ParkingRecord.class)))
            .thenReturn(mockParkingRecord);

        ParkingRecord result = parkingService.startParking(1L);

        assertNotNull(result);
        assertEquals(mockVehicle, result.getVehicle());
        verify(parkingRecordRepository).save(any(ParkingRecord.class));
    }

    @Test
    void stopParking_WithinFreeDuration_ShouldNotCharge() {
        mockParkingRecord.setStartTime(LocalDateTime.now().minusMinutes(30));
        when(parkingRecordRepository.findActiveRecordByVehicleId(anyLong()))
            .thenReturn(Optional.of(mockParkingRecord));
        when(parkingRecordRepository.save(any(ParkingRecord.class)))
            .thenReturn(mockParkingRecord);

        ParkingRecord result = parkingService.stopParking(1L);

        assertNotNull(result);
        assertEquals(BigDecimal.ZERO, result.getParkingFee());
    }

    @Test
    void stopParking_ExceedFreeDuration_ShouldChargeCorrectly() {
        // 停车3小时，超出免费时间1小时
        mockParkingRecord.setStartTime(LocalDateTime.now().minusHours(3));
        when(parkingRecordRepository.findActiveRecordByVehicleId(anyLong()))
            .thenReturn(Optional.of(mockParkingRecord));
        when(parkingRecordRepository.save(any(ParkingRecord.class)))
            .thenReturn(mockParkingRecord);

        ParkingRecord result = parkingService.stopParking(1L);

        assertNotNull(result);
        assertEquals(new BigDecimal("5.00"), result.getParkingFee());
    }

    @Test
    void stopParking_ExactlyFreeDuration_ShouldNotCharge() {
        mockParkingRecord.setStartTime(LocalDateTime.now().minusHours(2));
        when(parkingRecordRepository.findActiveRecordByVehicleId(anyLong()))
            .thenReturn(Optional.of(mockParkingRecord));
        when(parkingRecordRepository.save(any(ParkingRecord.class)))
            .thenReturn(mockParkingRecord);

        ParkingRecord result = parkingService.stopParking(1L);

        assertNotNull(result);
        assertEquals(BigDecimal.ZERO, result.getParkingFee());
    }

    @Test
    void stopParking_NonExistentRecord_ShouldThrowException() {
        when(parkingRecordRepository.findActiveRecordByVehicleId(anyLong()))
            .thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, 
            () -> parkingService.stopParking(1L));
    }

    @Test
    void calculateDailyIncome_ShouldReturnCorrectAmount() {
        LocalDateTime date = LocalDateTime.now();
        BigDecimal expectedIncome = new BigDecimal("100.00");
        
        when(parkingRecordRepository.calculateDailyIncome(
            any(LocalDateTime.class), 
            any(LocalDateTime.class)
        )).thenReturn(expectedIncome);

        BigDecimal result = parkingService.calculateDailyIncome(date);

        assertEquals(expectedIncome, result);
    }
} 