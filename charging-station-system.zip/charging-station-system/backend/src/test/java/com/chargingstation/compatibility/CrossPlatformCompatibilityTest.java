package com.chargingstation.compatibility;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class CrossPlatformCompatibilityTest {

    @LocalServerPort
    private int port;

    private Map<String, WebDriver> drivers = new HashMap<>();

    @BeforeEach
    void setUp() {
        // 初始化不同浏览器的WebDriver
        drivers.put("chrome", new ChromeDriver());
        drivers.put("firefox", new FirefoxDriver());
        drivers.put("edge", new EdgeDriver());
        if (isMacOS()) {
            drivers.put("safari", new SafariDriver());
        }
    }

    @AfterEach
    void tearDown() {
        drivers.values().forEach(WebDriver::quit);
    }

    @Test
    void loginShouldWorkAcrossBrowsers() {
        drivers.forEach((browser, driver) -> {
            driver.get("http://localhost:" + port);
            
            // 执行登录操作
            WebElement usernameInput = driver.findElement(By.id("username"));
            WebElement passwordInput = driver.findElement(By.id("password"));
            WebElement loginButton = driver.findElement(By.id("login-button"));

            usernameInput.sendKeys("admin");
            passwordInput.sendKeys("password");
            loginButton.click();

            // 验证登录成功
            assertTrue(driver.getCurrentUrl().contains("/dashboard"));
        });
    }

    @Test
    void responsiveLayoutShouldWorkAcrossBrowsers() {
        int[] screenSizes = {375, 768, 1024, 1440};

        drivers.forEach((browser, driver) -> {
            for (int width : screenSizes) {
                driver.manage().window().setSize(new Dimension(width, 800));
                driver.get("http://localhost:" + port + "/dashboard");

                // 验证响应式布局
                WebElement sidebar = driver.findElement(By.className("sidebar"));
                if (width < 768) {
                    assertFalse(sidebar.isDisplayed());
                } else {
                    assertTrue(sidebar.isDisplayed());
                }
            }
        });
    }

    @Test
    void fileUploadShouldWorkAcrossBrowsers() {
        drivers.forEach((browser, driver) -> {
            driver.get("http://localhost:" + port + "/upload");

            // 测试文件上传
            WebElement fileInput = driver.findElement(By.id("file-input"));
            fileInput.sendKeys(getTestFilePath());

            // 验证上传成功
            WebElement uploadStatus = driver.findElement(By.className("upload-status"));
            assertTrue(uploadStatus.getText().contains("上传成功"));
        });
    }

    @Test
    void webSocketsShouldWorkAcrossBrowsers() {
        drivers.forEach((browser, driver) -> {
            driver.get("http://localhost:" + port + "/realtime");

            // 等待WebSocket连接
            WebElement connectionStatus = new WebDriverWait(driver, Duration.ofSeconds(5))
                .until(ExpectedConditions.presenceOfElementLocated(By.id("connection-status")));

            // 验证实时更新
            assertTrue(connectionStatus.getText().contains("已连接"));
        });
    }

    @Test
    void cssAnimationsShouldWorkAcrossBrowsers() {
        drivers.forEach((browser, driver) -> {
            driver.get("http://localhost:" + port + "/animations");

            WebElement animatedElement = driver.findElement(By.className("animated"));
            
            // 验证CSS动画
            String transform = animatedElement.getCssValue("transform");
            assertNotEquals("none", transform);
        });
    }

    private boolean isMacOS() {
        return System.getProperty("os.name").toLowerCase().contains("mac");
    }

    private String getTestFilePath() {
        return new File("src/test/resources/test-file.txt").getAbsolutePath();
    }
} 