package com.chargingstation.device;

import com.chargingstation.device.protocol.ModbusAdapter;
import com.chargingstation.device.protocol.Command;
import com.chargingstation.device.simulator.DeviceSimulator;
import com.chargingstation.device.monitor.CommandExecutionMonitor;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Map;
import java.util.concurrent.TimeoutException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DeviceCommunicationTest {

    @Mock
    private ModbusAdapter modbusAdapter;
    
    @Mock
    private CommandExecutionMonitor monitor;
    
    private DeviceSimulator deviceSimulator;

    @BeforeEach
    void setUp() {
        deviceSimulator = new DeviceSimulator();
    }

    @Test
    void readDeviceStatus_ShouldReturnCorrectResponse() throws Exception {
        // 准备测试数据
        String deviceId = "DEVICE_001";
        Command command = new Command(
            CommandType.READ_STATUS,
            deviceId,
            Map.of()
        );
        
        byte[] expectedRequest = {0x01, 0x03, 0x00, 0x00, 0x00, 0x02};
        byte[] mockResponse = {0x01, 0x03, 0x04, 0x00, 0x00, 0x00, 0x00};
        
        when(modbusAdapter.convertToProtocol(command)).thenReturn(expectedRequest);
        when(modbusAdapter.parseResponse(mockResponse)).thenReturn(
            new Response(true, deviceId, Map.of("voltage", 220.0), null)
        );

        // 执行测试
        Response response = deviceSimulator.handleCommand(command);

        // 验证结果
        assertTrue(response.success());
        assertEquals(220.0, response.data().get("voltage"));
        verify(monitor).recordExecutionStart(eq(deviceId), any());
        verify(monitor).recordExecutionComplete(eq(deviceId), any(), anyLong());
    }

    @Test
    void writeDeviceRegister_WithTimeout_ShouldRetry() throws Exception {
        // 准备测试数据
        String deviceId = "DEVICE_001";
        Command command = new Command(
            CommandType.WRITE_REGISTER,
            deviceId,
            Map.of("address", 0x1000, "value", 100)
        );
        
        when(modbusAdapter.convertToProtocol(command))
            .thenReturn(new byte[]{0x01, 0x06, 0x10, 0x00, 0x00, 0x64});
        
        // 模拟第一次超时,第二次成功
        when(modbusAdapter.parseResponse(any()))
            .thenThrow(TimeoutException.class)
            .thenReturn(new Response(true, deviceId, Map.of(), null));

        // 执行测试
        Response response = deviceSimulator.handleCommand(command);

        // 验证结果
        assertTrue(response.success());
        verify(monitor).recordRetry(eq(deviceId), any(), eq(1));
        verify(modbusAdapter, times(2)).convertToProtocol(command);
    }

    @Test
    void communicationError_ShouldBeHandledGracefully() throws Exception {
        // 准备测试数据
        String deviceId = "DEVICE_001";
        Command command = new Command(
            CommandType.CONTROL,
            deviceId,
            Map.of("operation", "start")
        );
        
        when(modbusAdapter.convertToProtocol(command))
            .thenThrow(new DeviceCommunicationException("通信错误"));

        // 执行测试
        Response response = deviceSimulator.handleCommand(command);

        // 验证结果
        assertFalse(response.success());
        assertNotNull(response.errorMessage());
        verify(monitor).recordExecutionFailure(
            eq(deviceId), 
            any(), 
            contains("通信错误")
        );
    }

    @Test
    void invalidCommand_ShouldBeRejected() {
        // 准备测试数据
        String deviceId = "DEVICE_001";
        Command command = new Command(
            CommandType.READ_REGISTER,
            deviceId,
            Map.of("address", -1) // 无效地址
        );

        // 执行测试并验证异常
        ValidationException exception = assertThrows(
            ValidationException.class,
            () -> deviceSimulator.handleCommand(command)
        );

        assertTrue(exception.getMessage().contains("无效的寄存器地址"));
    }
} 