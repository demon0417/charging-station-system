package com.chargingstation.i18n;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Locale;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
class InternationalizationTest {

    @Autowired
    private MessageSource messageSource;

    @Test
    void messagesShouldBeLocalizedForDifferentLocales() {
        // 测试中文
        LocaleContextHolder.setLocale(Locale.CHINESE);
        assertEquals("车辆管理", getMessage("menu.vehicle"));
        assertEquals("开始充电", getMessage("charging.start"));
        assertEquals("停止充电", getMessage("charging.stop"));

        // 测试英文
        LocaleContextHolder.setLocale(Locale.ENGLISH);
        assertEquals("Vehicle Management", getMessage("menu.vehicle"));
        assertEquals("Start Charging", getMessage("charging.start"));
        assertEquals("Stop Charging", getMessage("charging.stop"));

        // 测试日文
        LocaleContextHolder.setLocale(Locale.JAPANESE);
        assertEquals("車両管理", getMessage("menu.vehicle"));
        assertEquals("充電開始", getMessage("charging.start"));
        assertEquals("充電停止", getMessage("charging.stop"));
    }

    @Test
    void dateFormatsShouldBeLocalized() {
        // 测试中文日期格式
        LocaleContextHolder.setLocale(Locale.CHINESE);
        assertEquals("2024年3月15日", formatDate(LocalDateTime.of(2024, 3, 15, 0, 0)));

        // 测试英文日期格式
        LocaleContextHolder.setLocale(Locale.ENGLISH);
        assertEquals("March 15, 2024", formatDate(LocalDateTime.of(2024, 3, 15, 0, 0)));

        // 测试日文日期格式
        LocaleContextHolder.setLocale(Locale.JAPANESE);
        assertEquals("2024年3月15日", formatDate(LocalDateTime.of(2024, 3, 15, 0, 0)));
    }

    @Test
    void numberFormatsShouldBeLocalized() {
        BigDecimal amount = new BigDecimal("1234567.89");

        // 测试中文数字格式
        LocaleContextHolder.setLocale(Locale.CHINESE);
        assertEquals("¥1,234,567.89", formatCurrency(amount));

        // 测试英文数字格式
        LocaleContextHolder.setLocale(Locale.US);
        assertEquals("$1,234,567.89", formatCurrency(amount));

        // 测试日文数字格式
        LocaleContextHolder.setLocale(Locale.JAPANESE);
        assertEquals("￥1,234,568", formatCurrency(amount));
    }

    @Test
    void fallbackMessagesShouldBeAvailable() {
        // 测试不存在的语言时使用默认语言
        LocaleContextHolder.setLocale(new Locale("xx"));
        assertEquals("Vehicle Management", getMessage("menu.vehicle"));
    }

    @Test
    void parameterizedMessagesShouldBeTranslated() {
        Object[] params = new Object[]{"京A12345", "30"};

        // 测试中文参数化消息
        LocaleContextHolder.setLocale(Locale.CHINESE);
        assertEquals("车辆京A12345已充电30分钟", 
            getMessage("charging.status", params));

        // 测试英文参数化消息
        LocaleContextHolder.setLocale(Locale.ENGLISH);
        assertEquals("Vehicle 京A12345 has been charging for 30 minutes", 
            getMessage("charging.status", params));
    }

    private String getMessage(String code) {
        return messageSource.getMessage(code, null, LocaleContextHolder.getLocale());
    }

    private String getMessage(String code, Object[] args) {
        return messageSource.getMessage(code, args, LocaleContextHolder.getLocale());
    }

    private String formatDate(LocalDateTime date) {
        DateTimeFormatter formatter = DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG)
            .withLocale(LocaleContextHolder.getLocale());
        return date.format(formatter);
    }

    private String formatCurrency(BigDecimal amount) {
        NumberFormat formatter = NumberFormat.getCurrencyInstance(LocaleContextHolder.getLocale());
        return formatter.format(amount);
    }
} 