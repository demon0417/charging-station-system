package com.chargingstation.security;

import com.chargingstation.device.command.BatchCommandProcessor;
import com.chargingstation.security.encryption.ConfigEncryptionService;
import com.chargingstation.security.ids.IntrusionDetectionService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
@ActiveProfiles("test")
class SecurityTest {

    @Autowired
    private BatchCommandProcessor batchProcessor;
    
    @Autowired
    private IntrusionDetectionService idsService;
    
    @Autowired
    private ConfigEncryptionService encryptionService;
    
    @Test
    void sqlInjectionAttempt() {
        // 测试SQL注入攻击
        String maliciousDeviceId = "DEVICE_001' OR '1'='1";
        Map<String, byte[]> commands = new HashMap<>();
        commands.put(maliciousDeviceId, new byte[]{0x01});
        
        assertThrows(SecurityException.class, 
            () -> batchProcessor.sendBatchCommands(commands, 1000));
    }
    
    @Test
    void bufferOverflowAttempt() {
        // 测试缓冲区溢出攻击
        byte[] largeCommand = new byte[1024 * 1024 * 10]; // 10MB
        Map<String, byte[]> commands = new HashMap<>();
        commands.put("DEVICE_001", largeCommand);
        
        assertThrows(SecurityException.class, 
            () -> batchProcessor.sendBatchCommands(commands, 1000));
    }
    
    @Test
    void bruteForceProtection() throws Exception {
        // 模拟暴力攻击
        String deviceId = "DEVICE_001";
        int attempts = 20;
        
        for (int i = 0; i < attempts; i++) {
            try {
                Map<String, byte[]> commands = new HashMap<>();
                commands.put(deviceId, new byte[]{0x01});
                batchProcessor.sendBatchCommands(commands, 100);
            } catch (Exception ignored) {}
        }
        
        // 验证IP是否被封禁
        assertTrue(idsService.isBlocked("127.0.0.1"));
        
        // 等待封禁时间过期
        TimeUnit.SECONDS.sleep(30);
        assertFalse(idsService.isBlocked("127.0.0.1"));
    }
    
    @Test
    @WithMockUser(roles = "USER")
    void unauthorizedAccessAttempt() {
        // 测试越权访问
        assertThrows(AccessDeniedException.class, 
            () -> batchProcessor.sendAdminCommand("DEVICE_001", new byte[]{0x01}));
    }
    
    @Test
    void sensitiveDataEncryption() {
        // 测试敏感数据加密
        String plaintext = "sensitive_data";
        String encrypted = encryptionService.encrypt(plaintext);
        
        assertNotEquals(plaintext, encrypted);
        assertEquals(plaintext, encryptionService.decrypt(encrypted));
    }
    
    @Test
    void xssAttackPrevention() {
        // 测试XSS攻击
        String maliciousInput = "<script>alert('xss')</script>";
        String sanitized = idsService.sanitizeInput(maliciousInput);
        
        assertNotEquals(maliciousInput, sanitized);
        assertFalse(sanitized.contains("<script>"));
    }
    
    @Test
    void sessionFixationProtection() {
        // 测试会话固定攻击防护
        String originalSession = "session_id_123";
        String newSession = sessionManager.regenerateSession(originalSession);
        
        assertNotEquals(originalSession, newSession);
    }
    
    @Test
    void auditLogging() {
        // 测试安全审计日志
        String deviceId = "DEVICE_001";
        String operation = "DELETE";
        
        auditLogger.logSecurityEvent(deviceId, operation);
        
        List<AuditLog> logs = auditLogger.getSecurityLogs(deviceId);
        assertFalse(logs.isEmpty());
        assertEquals(operation, logs.get(0).getOperation());
    }
} 