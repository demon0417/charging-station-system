package com.chargingstation.controllers;

import com.chargingstation.dto.VehicleDTO;
import com.chargingstation.models.Vehicle;
import com.chargingstation.models.enums.VehicleType;
import com.chargingstation.services.VehicleService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.time.LocalDateTime;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(VehicleController.class)
public class VehicleControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private VehicleService vehicleService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void createVehicle_ValidInput_ReturnsCreated() throws Exception {
        // 准备测试数据
        VehicleDTO dto = new VehicleDTO();
        dto.setPlateNumber("京A12345");
        dto.setVehicleType(VehicleType.ELECTRIC_VEHICLE);

        Vehicle vehicle = new Vehicle();
        vehicle.setId(1L);
        vehicle.setPlateNumber(dto.getPlateNumber());
        vehicle.setVehicleType(dto.getVehicleType());

        when(vehicleService.createVehicle(any(VehicleDTO.class))).thenReturn(vehicle);

        // 执行测试
        mockMvc.perform(post("/api/vehicle")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.plateNumber").value("京A12345"));
    }

    @Test
    public void getVehicle_ExistingId_ReturnsVehicle() throws Exception {
        Vehicle vehicle = new Vehicle();
        vehicle.setId(1L);
        vehicle.setPlateNumber("京A12345");
        vehicle.setVehicleType(VehicleType.ELECTRIC_VEHICLE);

        when(vehicleService.getVehicle(1L)).thenReturn(vehicle);

        mockMvc.perform(get("/api/vehicle/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.plateNumber").value("京A12345"));
    }

    @Test
    public void getVehicleByPlateNumber_ExistingPlate_ReturnsVehicle() throws Exception {
        Vehicle vehicle = new Vehicle();
        vehicle.setId(1L);
        vehicle.setPlateNumber("京A12345");

        when(vehicleService.getVehicleByPlateNumber("京A12345")).thenReturn(vehicle);

        mockMvc.perform(get("/api/vehicle/plate/京A12345"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1));
    }
} 