package com.chargingstation.localization;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.test.context.ActiveProfiles;

import java.util.Currency;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.TimeZone;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
class LocalizationTest {

    @Autowired
    private MessageSource messageSource;

    @Test
    void currencyFormatShouldBeLocalized() {
        // 测试不同地区的货币格式
        testCurrencyFormat(Locale.CHINA, "¥", "CNY");
        testCurrencyFormat(Locale.US, "$", "USD");
        testCurrencyFormat(Locale.JAPAN, "¥", "JPY");
    }

    @Test
    void timeZoneShouldBeHandledCorrectly() {
        // 测试不同时区的时间处理
        testTimeZone("Asia/Shanghai", "+0800");
        testTimeZone("America/New_York", "-0500");
        testTimeZone("Europe/London", "+0000");
    }

    @Test
    void phoneNumberFormatShouldBeLocalized() {
        // 测试不同地区的电话号码格式
        testPhoneNumberFormat(Locale.CHINA, "13812345678", "+86 138 1234 5678");
        testPhoneNumberFormat(Locale.US, "2125556789", "+1 (212) 555-6789");
        testPhoneNumberFormat(Locale.JAPAN, "09012345678", "+81 90-1234-5678");
    }

    @Test
    void addressFormatShouldBeLocalized() {
        // 测试不同地区的地址格式
        testAddressFormat(
            Locale.CHINA,
            new Address("北京市", "海淀区", "中关村大街", "1号", "100080"),
            "中国北京市海淀区中关村大街1号 100080"
        );

        testAddressFormat(
            Locale.US,
            new Address("New York", "NY", "5th Avenue", "123", "10001"),
            "123 5th Avenue, New York, NY 10001, USA"
        );

        testAddressFormat(
            Locale.JAPAN,
            new Address("東京都", "渋谷区", "代々木", "1-1-1", "151-0053"),
            "〒151-0053 東京都渋谷区代々木1-1-1"
        );
    }

    @Test
    void measurementUnitsShouldBeLocalized() {
        // 测试不同地区的计量单位
        testMeasurementUnits(Locale.CHINA, "公里", "千瓦时", "摄氏度");
        testMeasurementUnits(Locale.US, "miles", "kWh", "Fahrenheit");
        testMeasurementUnits(Locale.UK, "kilometres", "kWh", "Celsius");
    }

    @Test
    void sortOrderShouldBeLocalized() {
        // 测试不同地区的排序规则
        String[] names = {"张三", "李四", "王五", "赵六"};
        
        // 中文排序（按拼音）
        LocaleContextHolder.setLocale(Locale.CHINESE);
        String[] sortedChinese = sortNames(names);
        assertArrayEquals(new String[]{"李四", "王五", "张三", "赵六"}, sortedChinese);

        // 英文排序
        LocaleContextHolder.setLocale(Locale.ENGLISH);
        String[] sortedEnglish = sortNames(names);
        assertArrayEquals(new String[]{"Li Si", "Wang Wu", "Zhang San", "Zhao Liu"}, sortedEnglish);
    }

    private void testCurrencyFormat(Locale locale, String symbol, String code) {
        LocaleContextHolder.setLocale(locale);
        Currency currency = Currency.getInstance(locale);
        assertEquals(code, currency.getCurrencyCode());
        assertTrue(getCurrencyFormat(1234.56, locale).contains(symbol));
    }

    private void testTimeZone(String zoneId, String expectedOffset) {
        TimeZone zone = TimeZone.getTimeZone(zoneId);
        assertTrue(zone.getDisplayName(locale).contains(expectedOffset));
    }

    private void testPhoneNumberFormat(Locale locale, String number, String expected) {
        LocaleContextHolder.setLocale(locale);
        assertEquals(expected, formatPhoneNumber(number, locale));
    }

    private void testAddressFormat(Locale locale, Address address, String expected) {
        LocaleContextHolder.setLocale(locale);
        assertEquals(expected, formatAddress(address, locale));
    }

    private void testMeasurementUnits(Locale locale, String distance, String power, String temperature) {
        LocaleContextHolder.setLocale(locale);
        ResourceBundle bundle = ResourceBundle.getBundle("messages", locale);
        assertEquals(distance, bundle.getString("unit.distance"));
        assertEquals(power, bundle.getString("unit.power"));
        assertEquals(temperature, bundle.getString("unit.temperature"));
    }

    private String formatPhoneNumber(String number, Locale locale) {
        // 实现电话号码格式化逻辑
        return PhoneNumberUtil.format(number, locale);
    }

    private String formatAddress(Address address, Locale locale) {
        // 实现地址格式化逻辑
        return AddressFormatter.format(address, locale);
    }

    private String[] sortNames(String[] names) {
        // 实现本地化排序逻辑
        return Arrays.stream(names)
            .sorted(Collator.getInstance(LocaleContextHolder.getLocale()))
            .toArray(String[]::new);
    }

    private record Address(String city, String region, String street, String number, String postalCode) {}
} 