package com.chargingstation.device;

import com.chargingstation.device.protocol.ModbusAdapter;
import com.chargingstation.device.protocol.OCPPAdapter;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
class DeviceCompatibilityTest {

    @Autowired
    private List<DeviceAdapter> deviceAdapters;

    @Test
    void differentChargerModelsShouldWork() {
        // 测试不同型号充电桩的兼容性
        Map<String, ChargerSpec> chargerSpecs = Map.of(
            "MODEL_A", new ChargerSpec("7kW", "GB/T", "1.0"),
            "MODEL_B", new ChargerSpec("22kW", "IEC", "2.0"),
            "MODEL_C", new ChargerSpec("50kW", "CHAdeMO", "1.2")
        );

        for (Map.Entry<String, ChargerSpec> entry : chargerSpecs.entrySet()) {
            String model = entry.getKey();
            ChargerSpec spec = entry.getValue();
            
            assertTrue(isChargerSupported(model, spec));
            assertTrue(canCommunicate(model, spec));
            assertTrue(canCharge(model, spec));
        }
    }

    @Test
    void differentProtocolVersionsShouldWork() {
        // 测试不同协议版本的兼容性
        String[] protocols = {"OCPP_1.6", "OCPP_2.0", "MODBUS_RTU", "MODBUS_TCP"};
        
        for (String protocol : protocols) {
            assertTrue(isProtocolSupported(protocol));
            assertTrue(canHandleProtocolMessages(protocol));
        }
    }

    @Test
    void differentCommunicationModesShouldWork() {
        // 测试不同通信方式的兼容性
        String[] modes = {"TCP/IP", "Serial", "4G", "WiFi"};
        
        for (String mode : modes) {
            assertTrue(isCommunicationModeSupported(mode));
            assertTrue(canEstablishConnection(mode));
            assertTrue(canMaintainConnection(mode));
        }
    }

    @Test
    void differentPowerRatingsShouldWork() {
        // 测试不同功率等级的兼容性
        int[] powerRatings = {7, 22, 50, 120, 180};
        
        for (int power : powerRatings) {
            assertTrue(isPowerRatingSupported(power));
            assertTrue(canRegulateOutput(power));
            assertTrue(canMonitorCharging(power));
        }
    }

    @Test
    void differentAuthenticationMethodsShouldWork() {
        // 测试不同认证方式的兼容性
        String[] methods = {"RFID", "QR_CODE", "APP", "MANUAL"};
        
        for (String method : methods) {
            assertTrue(isAuthMethodSupported(method));
            assertTrue(canAuthenticate(method));
            assertTrue(canAuthorize(method));
        }
    }

    @Test
    void differentPaymentSystemsShouldWork() {
        // 测试不同支付系统的兼容性
        String[] systems = {"WECHAT", "ALIPAY", "UNIONPAY", "CREDIT_CARD"};
        
        for (String system : systems) {
            assertTrue(isPaymentSystemSupported(system));
            assertTrue(canProcessPayment(system));
            assertTrue(canRefund(system));
        }
    }

    private boolean isChargerSupported(String model, ChargerSpec spec) {
        return deviceAdapters.stream()
            .anyMatch(adapter -> adapter.supportsCharger(model, spec));
    }

    private boolean canCommunicate(String model, ChargerSpec spec) {
        return deviceAdapters.stream()
            .anyMatch(adapter -> adapter.testCommunication(model, spec));
    }

    private boolean canCharge(String model, ChargerSpec spec) {
        return deviceAdapters.stream()
            .anyMatch(adapter -> adapter.testCharging(model, spec));
    }

    private boolean isProtocolSupported(String protocol) {
        return deviceAdapters.stream()
            .anyMatch(adapter -> adapter.supportsProtocol(protocol));
    }

    private boolean canHandleProtocolMessages(String protocol) {
        return deviceAdapters.stream()
            .anyMatch(adapter -> adapter.testProtocolMessages(protocol));
    }

    private boolean isCommunicationModeSupported(String mode) {
        return deviceAdapters.stream()
            .anyMatch(adapter -> adapter.supportsCommunicationMode(mode));
    }

    private boolean canEstablishConnection(String mode) {
        return deviceAdapters.stream()
            .anyMatch(adapter -> adapter.testConnection(mode));
    }

    private boolean canMaintainConnection(String mode) {
        return deviceAdapters.stream()
            .anyMatch(adapter -> adapter.testConnectionStability(mode));
    }

    private boolean isPowerRatingSupported(int power) {
        return deviceAdapters.stream()
            .anyMatch(adapter -> adapter.supportsPowerRating(power));
    }

    private boolean canRegulateOutput(int power) {
        return deviceAdapters.stream()
            .anyMatch(adapter -> adapter.testPowerRegulation(power));
    }

    private boolean canMonitorCharging(int power) {
        return deviceAdapters.stream()
            .anyMatch(adapter -> adapter.testChargingMonitoring(power));
    }

    private boolean isAuthMethodSupported(String method) {
        return deviceAdapters.stream()
            .anyMatch(adapter -> adapter.supportsAuthMethod(method));
    }

    private boolean canAuthenticate(String method) {
        return deviceAdapters.stream()
            .anyMatch(adapter -> adapter.testAuthentication(method));
    }

    private boolean canAuthorize(String method) {
        return deviceAdapters.stream()
            .anyMatch(adapter -> adapter.testAuthorization(method));
    }

    private boolean isPaymentSystemSupported(String system) {
        return deviceAdapters.stream()
            .anyMatch(adapter -> adapter.supportsPaymentSystem(system));
    }

    private boolean canProcessPayment(String system) {
        return deviceAdapters.stream()
            .anyMatch(adapter -> adapter.testPaymentProcessing(system));
    }

    private boolean canRefund(String system) {
        return deviceAdapters.stream()
            .anyMatch(adapter -> adapter.testRefundProcessing(system));
    }

    private record ChargerSpec(String power, String standard, String version) {}
} 