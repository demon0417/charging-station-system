package com.chargingstation.device;

import com.chargingstation.device.command.BatchCommandProcessor;
import com.chargingstation.device.command.PriorityCommandQueue;
import com.chargingstation.device.monitor.CommandExecutionMonitor;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;
import java.util.stream.IntStream;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
class StressTest {

    @Autowired
    private BatchCommandProcessor batchProcessor;
    
    @Autowired
    private CommandExecutionMonitor monitor;
    
    @Test
    void highConcurrencyStressTest() throws Exception {
        // 配置测试参数
        int deviceCount = 100;          // 模拟100个设备
        int commandsPerDevice = 1000;   // 每个设备1000条指令
        int batchSize = 50;             // 每批次50条指令
        int concurrentThreads = 20;     // 20个并发线程
        
        // 创建线程池
        ExecutorService executorService = Executors.newFixedThreadPool(concurrentThreads);
        CountDownLatch completionLatch = new CountDownLatch(deviceCount);
        List<Future<StressTestResult>> futures = new ArrayList<>();
        
        // 开始时间
        long startTime = System.currentTimeMillis();
        
        // 提交测试任务
        for (int i = 0; i < deviceCount; i++) {
            final String deviceId = "DEVICE_" + i;
            futures.add(executorService.submit(() -> {
                try {
                    return executeDeviceCommands(
                        deviceId, 
                        commandsPerDevice, 
                        batchSize
                    );
                } finally {
                    completionLatch.countDown();
                }
            }));
        }
        
        // 等待所有任务完成
        completionLatch.await(10, TimeUnit.MINUTES);
        
        // 计算总执行时间
        long totalTime = System.currentTimeMillis() - startTime;
        
        // 收集结果
        int totalCommands = 0;
        int successfulCommands = 0;
        int failedCommands = 0;
        
        for (Future<StressTestResult> future : futures) {
            StressTestResult result = future.get();
            totalCommands += result.totalCommands;
            successfulCommands += result.successfulCommands;
            failedCommands += result.failedCommands;
        }
        
        // 验证结果
        double successRate = (double) successfulCommands / totalCommands;
        double throughput = (double) totalCommands / (totalTime / 1000.0);
        
        assertTrue(successRate > 0.99, "成功率应大于99%");
        assertTrue(throughput > 1000, "吞吐量应大于1000 TPS");
        assertTrue(monitor.getAverageResponseTime() < 100, "平均响应时间应小于100ms");
    }
    
    @Test
    void longRunningStabilityTest() throws Exception {
        // 配置测试参数
        int testDurationMinutes = 30;   // 测试持续30分钟
        int deviceCount = 10;           // 模拟10个设备
        
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(deviceCount);
        CountDownLatch testCompletionLatch = new CountDownLatch(1);
        Map<String, AtomicInteger> errorCounts = new ConcurrentHashMap<>();
        
        // 为每个设备创建定期任务
        List<ScheduledFuture<?>> tasks = new ArrayList<>();
        for (int i = 0; i < deviceCount; i++) {
            final String deviceId = "DEVICE_" + i;
            errorCounts.put(deviceId, new AtomicInteger(0));
            
            ScheduledFuture<?> task = scheduler.scheduleAtFixedRate(
                () -> executePeriodicCommands(deviceId, errorCounts.get(deviceId)),
                0, 1, TimeUnit.SECONDS
            );
            tasks.add(task);
        }
        
        // 等待测试完成
        Thread.sleep(TimeUnit.MINUTES.toMillis(testDurationMinutes));
        
        // 停止所有任务
        tasks.forEach(task -> task.cancel(true));
        scheduler.shutdown();
        
        // 验证结果
        for (Map.Entry<String, AtomicInteger> entry : errorCounts.entrySet()) {
            int errorCount = entry.getValue().get();
            assertTrue(errorCount < 100, 
                String.format("设备 %s 错误次数(%d)过多", entry.getKey(), errorCount));
        }
        
        // 验证系统稳定性指标
        assertTrue(monitor.getSuccessRate() > 0.99, "系统成功率应保持在99%以上");
        assertTrue(monitor.get95thPercentileLatency() < 200, "95%请求延迟应小于200ms");
    }
    
    @Test
    void resourceExhaustionTest() throws Exception {
        // 配置测试参数
        int largeCommandSize = 1024 * 1024;  // 1MB的指令
        int commandCount = 1000;             // 1000条指令
        
        // 模拟大量内存使用的指令
        byte[] largeCommand = new byte[largeCommandSize];
        Map<String, byte[]> commands = new HashMap<>();
        for (int i = 0; i < commandCount; i++) {
            commands.put("CMD_" + i, largeCommand);
        }
        
        // 执行测试并监控内存使用
        long initialMemory = Runtime.getRuntime().totalMemory() - 
                           Runtime.getRuntime().freeMemory();
        
        Map<String, byte[]> results = batchProcessor.sendBatchCommands(commands, 5000);
        
        long finalMemory = Runtime.getRuntime().totalMemory() - 
                          Runtime.getRuntime().freeMemory();
        
        // 验证内存使用是否合理
        long memoryIncrease = finalMemory - initialMemory;
        assertTrue(memoryIncrease < 1024 * 1024 * 100, "内存增长不应超过100MB");
        
        // 验证处理结果
        assertEquals(commandCount, results.size(), "应处理所有指令");
    }
    
    private StressTestResult executeDeviceCommands(
            String deviceId, 
            int totalCommands, 
            int batchSize) {
        int successfulCommands = 0;
        int failedCommands = 0;
        
        for (int i = 0; i < totalCommands; i += batchSize) {
            int currentBatchSize = Math.min(batchSize, totalCommands - i);
            Map<String, byte[]> batch = new HashMap<>();
            
            // 准备批量指令
            for (int j = 0; j < currentBatchSize; j++) {
                batch.put(
                    String.format("%s_CMD_%d", deviceId, i + j),
                    generateTestCommand()
                );
            }
            
            try {
                // 发送批量指令
                Map<String, byte[]> results = batchProcessor.sendBatchCommands(batch, 1000);
                successfulCommands += results.size();
                failedCommands += (currentBatchSize - results.size());
            } catch (Exception e) {
                failedCommands += currentBatchSize;
            }
        }
        
        return new StressTestResult(totalCommands, successfulCommands, failedCommands);
    }
    
    private void executePeriodicCommands(String deviceId, AtomicInteger errorCount) {
        try {
            Map<String, byte[]> commands = new HashMap<>();
            commands.put(deviceId, generateTestCommand());
            batchProcessor.sendBatchCommands(commands, 500);
        } catch (Exception e) {
            errorCount.incrementAndGet();
        }
    }
    
    private byte[] generateTestCommand() {
        return new byte[]{0x01, 0x03, 0x00, 0x00, 0x00, 0x01};
    }
    
    private record StressTestResult(
        int totalCommands,
        int successfulCommands,
        int failedCommands
    ) {}
} 