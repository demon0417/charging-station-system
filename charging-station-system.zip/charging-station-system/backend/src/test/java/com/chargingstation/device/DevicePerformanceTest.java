package com.chargingstation.device;

import com.chargingstation.device.benchmark.DeviceBenchmarkService;
import com.chargingstation.device.benchmark.DeviceBenchmarkService.BenchmarkConfig;
import com.chargingstation.device.benchmark.DeviceBenchmarkService.BenchmarkResult;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
class DevicePerformanceTest {

    @Autowired
    private DeviceBenchmarkService benchmarkService;

    @Test
    void singleDevicePerformance_ShouldMeetRequirements() {
        // 配置测试参数
        BenchmarkConfig config = BenchmarkConfig.builder()
            .concurrentUsers(1)
            .commandCount(1000)
            .commandType(CommandType.READ)
            .thinkTime(0)
            .timeout(30)
            .build();

        // 执行测试
        BenchmarkResult result = benchmarkService.runBenchmark(config);

        // 验证结果
        assertTrue(result.successCount() > 0);
        assertTrue(result.averageResponseTime() < 100.0); // 平均响应时间小于100ms
        assertTrue(result.throughput() > 50.0); // 吞吐量大于50 TPS
    }

    @Test
    void highConcurrency_ShouldHandleGracefully() {
        // 配置测试参数
        BenchmarkConfig config = BenchmarkConfig.builder()
            .concurrentUsers(50)
            .commandCount(100)
            .commandType(CommandType.WRITE)
            .thinkTime(10)
            .timeout(60)
            .build();

        // 执行测试
        BenchmarkResult result = benchmarkService.runBenchmark(config);

        // 验证结果
        assertTrue(result.duration().compareTo(Duration.ofMinutes(2)) < 0);
        assertTrue(result.failureCount() / (double)result.totalRequests() < 0.01); // 错误率小于1%
    }

    @Test
    void longRunning_ShouldMaintainStability() {
        // 配置测试参数
        BenchmarkConfig config = BenchmarkConfig.builder()
            .concurrentUsers(10)
            .commandCount(10000)
            .commandType(CommandType.READ)
            .thinkTime(5)
            .timeout(300)
            .build();

        // 执行测试
        BenchmarkResult result = benchmarkService.runBenchmark(config);

        // 验证结果
        assertTrue(result.successCount() > result.totalRequests() * 0.99); // 成功率大于99%
        assertTrue(result.duration().compareTo(Duration.ofMinutes(5)) < 0); // 总耗时小于5分钟
    }

    @Test
    void mixedOperations_ShouldPerformWell() {
        // 执行不同类型的操作混合测试
        BenchmarkResult readResult = benchmarkService.runBenchmark(
            createConfig(CommandType.READ, 1000)
        );
        BenchmarkResult writeResult = benchmarkService.runBenchmark(
            createConfig(CommandType.WRITE, 1000)
        );
        BenchmarkResult controlResult = benchmarkService.runBenchmark(
            createConfig(CommandType.CONTROL, 1000)
        );

        // 验证各类操作的性能指标
        assertAll(
            () -> assertTrue(readResult.averageResponseTime() < writeResult.averageResponseTime()),
            () -> assertTrue(writeResult.averageResponseTime() < controlResult.averageResponseTime()),
            () -> assertTrue(readResult.throughput() > writeResult.throughput()),
            () -> assertTrue(writeResult.throughput() > controlResult.throughput())
        );
    }

    private BenchmarkConfig createConfig(CommandType type, int count) {
        return BenchmarkConfig.builder()
            .concurrentUsers(5)
            .commandCount(count)
            .commandType(type)
            .thinkTime(0)
            .timeout(60)
            .build();
    }
} 