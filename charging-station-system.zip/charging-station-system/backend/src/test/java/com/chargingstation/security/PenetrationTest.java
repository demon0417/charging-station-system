package com.chargingstation.security;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;
import org.springframework.test.context.ActiveProfiles;

import java.util.Collections;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
class PenetrationTest {

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    void sqlInjectionTest() {
        // SQL注入测试
        String[] maliciousInputs = {
            "' OR '1'='1",
            "'; DROP TABLE users; --",
            "' UNION SELECT * FROM users; --",
            "' OR '1'='1' /*",
            "admin' --"
        };

        for (String input : maliciousInputs) {
            ResponseEntity<String> response = restTemplate.getForEntity(
                "/api/vehicle/plate/" + input,
                String.class
            );
            assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        }
    }

    @Test
    void xssAttackTest() {
        // XSS攻击测试
        String[] xssPayloads = {
            "<script>alert('xss')</script>",
            "<img src='x' onerror='alert(1)'>",
            "javascript:alert(1)",
            "<svg onload='alert(1)'>",
            "\"><script>alert('xss')</script>"
        };

        for (String payload : xssPayloads) {
            Map<String, String> requestBody = Collections.singletonMap("name", payload);
            
            ResponseEntity<String> response = restTemplate.postForEntity(
                "/api/vehicle",
                requestBody,
                String.class
            );
            
            assertNotEquals(HttpStatus.OK, response.getStatusCode());
            if (response.getBody() != null) {
                assertFalse(response.getBody().contains("<script>"));
            }
        }
    }

    @Test
    void bruteForceProtectionTest() {
        // 暴力破解防护测试
        String endpoint = "/api/auth/login";
        Map<String, String> credentials = Map.of(
            "username", "admin",
            "password", "wrong"
        );

        int attempts = 20;
        int successfulAttempts = 0;

        for (int i = 0; i < attempts; i++) {
            ResponseEntity<String> response = restTemplate.postForEntity(
                endpoint,
                credentials,
                String.class
            );
            
            if (response.getStatusCode() != HttpStatus.TOO_MANY_REQUESTS) {
                successfulAttempts++;
            }
        }

        assertTrue(successfulAttempts < attempts, "应该在多次失败后被限制访问");
    }

    @Test
    void csrfProtectionTest() {
        // CSRF防护测试
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        
        Map<String, String> requestBody = Collections.singletonMap("data", "test");
        HttpEntity<Map<String, String>> request = new HttpEntity<>(requestBody, headers);
        
        ResponseEntity<String> response = restTemplate.exchange(
            "/api/vehicle",
            HttpMethod.POST,
            request,
            String.class
        );
        
        assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
    }

    @Test
    void jwtTokenTest() {
        // JWT令牌安全测试
        String[] invalidTokens = {
            "invalid.token.signature",
            "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.signature",
            "completely.invalid.token",
            "",
            "null"
        };

        for (String token : invalidTokens) {
            HttpHeaders headers = new HttpHeaders();
            headers.setBearerAuth(token);
            HttpEntity<?> request = new HttpEntity<>(headers);
            
            ResponseEntity<String> response = restTemplate.exchange(
                "/api/vehicle",
                HttpMethod.GET,
                request,
                String.class
            );
            
            assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        }
    }

    @Test
    void directoryTraversalTest() {
        // 目录遍历攻击测试
        String[] maliciousPaths = {
            "../../../etc/passwd",
            "..\\..\\..\\windows\\system32",
            "/etc/shadow",
            "../../application.yml",
            "%2e%2e%2f%2e%2e%2f"
        };

        for (String path : maliciousPaths) {
            ResponseEntity<String> response = restTemplate.getForEntity(
                "/api/files/" + path,
                String.class
            );
            
            assertNotEquals(HttpStatus.OK, response.getStatusCode());
        }
    }
} 