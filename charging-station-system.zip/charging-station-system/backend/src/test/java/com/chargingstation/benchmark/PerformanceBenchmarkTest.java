package com.chargingstation.benchmark;

import com.chargingstation.device.benchmark.DeviceBenchmarkService;
import org.junit.jupiter.api.Test;
import org.openjdk.jmh.annotations.*;
import org.openjdk.jmh.runner.Runner;
import org.openjdk.jmh.runner.options.Options;
import org.openjdk.jmh.runner.options.OptionsBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.concurrent.TimeUnit;

@SpringBootTest
@State(Scope.Benchmark)
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.MILLISECONDS)
public class PerformanceBenchmarkTest {

    @Autowired
    private DeviceBenchmarkService benchmarkService;

    @Test
    void runBenchmarks() throws Exception {
        Options options = new OptionsBuilder()
            .include(this.getClass().getName())
            .warmupIterations(3)
            .measurementIterations(5)
            .forks(1)
            .build();
        new Runner(options).run();
    }

    @Benchmark
    public void deviceCommandBenchmark() {
        BenchmarkConfig config = BenchmarkConfig.builder()
            .concurrentUsers(10)
            .commandCount(1000)
            .commandType(CommandType.READ)
            .build();
        
        BenchmarkResult result = benchmarkService.runBenchmark(config);
        
        // 验证性能指标
        assertTrue(result.averageResponseTime() < 50.0); // 平均响应时间小于50ms
        assertTrue(result.throughput() > 1000.0);        // 吞吐量大于1000 TPS
        assertTrue(result.successRate() > 0.99);         // 成功率大于99%
    }

    @Benchmark
    public void databaseOperationBenchmark() {
        // 数据库读操作基准测试
        long startTime = System.nanoTime();
        for (int i = 0; i < 1000; i++) {
            vehicleRepository.findById((long) (Math.random() * 1000));
        }
        long readTime = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startTime);
        assertTrue(readTime < 1000); // 1000次读操作应在1秒内完成

        // 数据库写操作基准测试
        startTime = System.nanoTime();
        for (int i = 0; i < 100; i++) {
            Vehicle vehicle = new Vehicle();
            vehicle.setPlateNumber("TEST" + i);
            vehicleRepository.save(vehicle);
        }
        long writeTime = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startTime);
        assertTrue(writeTime < 500); // 100次写操作应在500ms内完成
    }

    @Benchmark
    public void cachePerformanceBenchmark() {
        // 缓存命中率测试
        int hits = 0;
        int total = 1000;
        
        for (int i = 0; i < total; i++) {
            String key = "test-key-" + (i % 100);
            if (cacheService.get(key) != null) {
                hits++;
            }
        }
        
        double hitRate = (double) hits / total;
        assertTrue(hitRate > 0.8); // 缓存命中率应大于80%

        // 缓存响应时间测试
        long startTime = System.nanoTime();
        for (int i = 0; i < 1000; i++) {
            cacheService.get("test-key");
        }
        long cacheTime = TimeUnit.NANOSECONDS.toMicros(System.nanoTime() - startTime);
        assertTrue(cacheTime < 1000); // 缓存访问应在1ms内完成
    }

    @Benchmark
    public void apiEndpointBenchmark() {
        // API响应时间测试
        TestRestTemplate restTemplate = new TestRestTemplate();
        long startTime = System.currentTimeMillis();
        
        for (int i = 0; i < 100; i++) {
            ResponseEntity<String> response = restTemplate.getForEntity(
                "/api/vehicle/statistics/current",
                String.class
            );
            assertEquals(HttpStatus.OK, response.getStatusCode());
        }
        
        long apiTime = System.currentTimeMillis() - startTime;
        assertTrue(apiTime < 2000); // 100次API调用应在2秒内完成
    }

    @Benchmark
    public void memoryUsageBenchmark() {
        // 内存使用基准测试
        Runtime runtime = Runtime.getRuntime();
        long initialMemory = runtime.totalMemory() - runtime.freeMemory();
        
        // 执行内存密集操作
        List<Object> objects = new ArrayList<>();
        for (int i = 0; i < 10000; i++) {
            objects.add(new byte[1024]); // 1KB
        }
        
        long finalMemory = runtime.totalMemory() - runtime.freeMemory();
        long memoryIncrease = finalMemory - initialMemory;
        
        assertTrue(memoryIncrease < 20 * 1024 * 1024); // 内存增长不应超过20MB
        
        objects.clear();
        System.gc();
        
        // 验证内存释放
        long afterGC = runtime.totalMemory() - runtime.freeMemory();
        assertTrue(afterGC - initialMemory < 1024 * 1024); // GC后内存增长应小于1MB
    }
} 