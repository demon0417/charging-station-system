package com.chargingstation.integration;

import com.chargingstation.dto.VehicleDTO;
import com.chargingstation.models.ChargingRecord;
import com.chargingstation.models.ParkingRecord;
import com.chargingstation.models.Vehicle;
import com.chargingstation.models.enums.VehicleType;
import com.chargingstation.services.ChargingService;
import com.chargingstation.services.ParkingService;
import com.chargingstation.services.VehicleService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
@Transactional
class ChargingStationIntegrationTest {

    @Autowired
    private VehicleService vehicleService;

    @Autowired
    private ParkingService parkingService;

    @Autowired
    private ChargingService chargingService;

    @Test
    void completeBusinessFlow() {
        // 1. 创建车辆记录
        VehicleDTO vehicleDTO = new VehicleDTO();
        vehicleDTO.setPlateNumber("京A12345");
        vehicleDTO.setVehicleType(VehicleType.SMALL);
        vehicleDTO.setEntryTime(LocalDateTime.now());

        Vehicle vehicle = vehicleService.createVehicle(vehicleDTO);
        assertNotNull(vehicle.getId());

        // 2. 开始停车
        ParkingRecord parkingRecord = parkingService.startParking(vehicle.getId());
        assertNotNull(parkingRecord);
        assertNull(parkingRecord.getEndTime());

        // 3. 模拟时间流逝（3小时）
        // 注意：在实际测试中需要使用 MockTime 或类似机制
        parkingRecord.setStartTime(LocalDateTime.now().minusHours(3));

        // 4. 结束停车并计算费用
        ParkingRecord completedParkingRecord = parkingService.stopParking(vehicle.getId());
        assertNotNull(completedParkingRecord.getEndTime());
        assertTrue(completedParkingRecord.getParkingFee().compareTo(BigDecimal.ZERO) > 0);

        // 5. 开始充电
        ChargingRecord chargingRecord = chargingService.startCharging(vehicle.getId());
        assertNotNull(chargingRecord);
        assertNull(chargingRecord.getEndTime());

        // 6. 结束充电并计算费用
        BigDecimal powerConsumption = new BigDecimal("10.5"); // 10.5度电
        ChargingRecord completedChargingRecord = chargingService.stopCharging(
            vehicle.getId(), 
            powerConsumption
        );
        
        assertNotNull(completedChargingRecord.getEndTime());
        assertTrue(completedChargingRecord.getChargingFee().compareTo(BigDecimal.ZERO) > 0);

        // 7. 验证统计数据
        assertEquals(1, parkingService.getCurrentParkingCount());
        assertEquals(0, chargingService.getCurrentChargingCount());
    }
} 