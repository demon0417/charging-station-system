package com.chargingstation.compatibility;

import com.chargingstation.device.protocol.ModbusAdapter;
import com.chargingstation.device.protocol.OCPPAdapter;
import com.chargingstation.device.protocol.ProtocolAdapter;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
class ProtocolCompatibilityTest {

    @Autowired
    private List<ProtocolAdapter> protocolAdapters;
    
    @Test
    void multipleProtocolSupport() {
        // 测试多协议支持
        assertNotNull(protocolAdapters);
        assertTrue(protocolAdapters.size() >= 2);
        
        boolean hasModbus = false;
        boolean hasOCPP = false;
        
        for (ProtocolAdapter adapter : protocolAdapters) {
            if (adapter instanceof ModbusAdapter) hasModbus = true;
            if (adapter instanceof OCPPAdapter) hasOCPP = true;
        }
        
        assertTrue(hasModbus, "应支持Modbus协议");
        assertTrue(hasOCPP, "应支持OCPP协议");
    }
    
    @Test
    void protocolVersionCompatibility() {
        // 测试协议版本兼容性
        for (ProtocolAdapter adapter : protocolAdapters) {
            assertTrue(adapter.isVersionSupported("1.0"));
            assertTrue(adapter.isVersionSupported("2.0"));
        }
    }
    
    @Test
    void dataFormatCompatibility() {
        // 测试数据格式兼容性
        byte[] modbusData = {0x01, 0x03, 0x00, 0x00, 0x00, 0x02};
        String ocppData = "{\"messageType\":3,\"messageId\":\"123\"}";
        
        for (ProtocolAdapter adapter : protocolAdapters) {
            if (adapter instanceof ModbusAdapter) {
                assertTrue(adapter.validateData(modbusData));
            }
            if (adapter instanceof OCPPAdapter) {
                assertTrue(adapter.validateData(ocppData.getBytes()));
            }
        }
    }
    
    @Test
    void encodingCompatibility() {
        // 测试字符编码兼容性
        String[] encodings = {"UTF-8", "GBK", "ISO-8859-1"};
        
        for (String encoding : encodings) {
            for (ProtocolAdapter adapter : protocolAdapters) {
                assertTrue(adapter.supportsEncoding(encoding));
            }
        }
    }
    
    @Test
    void backwardCompatibility() {
        // 测试向后兼容性
        String[] legacyCommands = {
            "v1_start_charging",
            "v1_stop_charging",
            "v1_get_status"
        };
        
        for (String command : legacyCommands) {
            for (ProtocolAdapter adapter : protocolAdapters) {
                assertTrue(adapter.supportsLegacyCommand(command));
            }
        }
    }
    
    @Test
    void errorHandlingCompatibility() {
        // 测试错误处理兼容性
        Map<String, String> errorCodes = Map.of(
            "ERR_001", "通信超时",
            "ERR_002", "设备离线",
            "ERR_003", "指令无效"
        );
        
        for (Map.Entry<String, String> error : errorCodes.entrySet()) {
            for (ProtocolAdapter adapter : protocolAdapters) {
                assertEquals(
                    error.getValue(),
                    adapter.translateErrorCode(error.getKey())
                );
            }
        }
    }
} 