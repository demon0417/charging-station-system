package com.chargingstation.usability;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;

import java.time.Duration;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class UserExperienceTest {

    @LocalServerPort
    private int port;

    private WebDriver driver;
    private WebDriverWait wait;

    @BeforeEach
    void setUp() {
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.get("http://localhost:" + port);
    }

    @AfterEach
    void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test
    void loginFlowTest() {
        // 测试登录流程
        WebElement usernameInput = driver.findElement(By.id("username"));
        WebElement passwordInput = driver.findElement(By.id("password"));
        WebElement loginButton = driver.findElement(By.id("login-button"));

        // 输入凭据
        usernameInput.sendKeys("admin");
        passwordInput.sendKeys("password");
        loginButton.click();

        // 验证登录成功
        wait.until(ExpectedConditions.urlContains("/dashboard"));
        assertTrue(driver.getCurrentUrl().contains("/dashboard"));

        // 验证错误提示
        usernameInput.clear();
        passwordInput.clear();
        usernameInput.sendKeys("invalid");
        passwordInput.sendKeys("wrong");
        loginButton.click();

        WebElement errorMessage = wait.until(
            ExpectedConditions.visibilityOfElementLocated(By.className("error-message"))
        );
        assertTrue(errorMessage.isDisplayed());
    }

    @Test
    void navigationTest() {
        // 测试导航体验
        login();  // 先登录

        // 验证菜单项可见性
        List<WebElement> menuItems = driver.findElements(By.className("menu-item"));
        assertTrue(menuItems.size() >= 4);  // 至少应有4个菜单项

        // 测试菜单导航
        for (WebElement menuItem : menuItems) {
            menuItem.click();
            wait.until(ExpectedConditions.urlContains(menuItem.getAttribute("data-path")));
            assertTrue(menuItem.getAttribute("class").contains("active"));
        }

        // 测试面包屑导航
        WebElement breadcrumb = driver.findElement(By.className("breadcrumb"));
        assertTrue(breadcrumb.isDisplayed());
        assertTrue(breadcrumb.findElements(By.tagName("a")).size() > 0);
    }

    @Test
    void responsiveLayoutTest() {
        // 测试响应式布局
        int[] screenSizes = {375, 768, 1024, 1440};  // 移动端、平板、桌面、大屏

        for (int width : screenSizes) {
            driver.manage().window().setSize(new Dimension(width, 800));
            Thread.sleep(500);  // 等待重排

            // 验证布局适应性
            WebElement sidebar = driver.findElement(By.className("sidebar"));
            if (width < 768) {
                assertFalse(sidebar.isDisplayed());
                assertTrue(driver.findElement(By.className("mobile-menu")).isDisplayed());
            } else {
                assertTrue(sidebar.isDisplayed());
                assertFalse(driver.findElement(By.className("mobile-menu")).isDisplayed());
            }
        }
    }

    @Test
    void formInteractionTest() {
        // 测试表单交互
        login();
        navigateToVehicleForm();

        // 测试表单验证
        WebElement submitButton = driver.findElement(By.id("submit-button"));
        submitButton.click();

        // 验证必填字段提示
        List<WebElement> errorMessages = driver.findElements(By.className("field-error"));
        assertFalse(errorMessages.isEmpty());

        // 测试实时验证
        WebElement plateNumberInput = driver.findElement(By.id("plate-number"));
        plateNumberInput.sendKeys("invalid");
        WebElement plateNumberError = wait.until(
            ExpectedConditions.visibilityOfElementLocated(By.id("plate-number-error"))
        );
        assertTrue(plateNumberError.isDisplayed());

        // 测试成功提交
        plateNumberInput.clear();
        plateNumberInput.sendKeys("京A12345");
        submitButton.click();

        WebElement successMessage = wait.until(
            ExpectedConditions.visibilityOfElementLocated(By.className("success-message"))
        );
        assertTrue(successMessage.isDisplayed());
    }

    @Test
    void accessibilityTest() {
        // 测试无障碍功能
        login();

        // 测试键盘导航
        WebElement firstMenuItem = driver.findElement(By.className("menu-item"));
        firstMenuItem.sendKeys(Keys.TAB);
        WebElement activeElement = driver.switchTo().activeElement();
        assertEquals("menu-item", activeElement.getAttribute("class"));

        // 测试ARIA标签
        List<WebElement> ariaElements = driver.findElements(By.cssSelector("[aria-label]"));
        assertFalse(ariaElements.isEmpty());

        // 测试颜色对比度
        WebElement header = driver.findElement(By.className("header"));
        String backgroundColor = header.getCssValue("background-color");
        String textColor = header.getCssValue("color");
        assertTrue(hasAdequateContrast(backgroundColor, textColor));
    }

    private void login() {
        driver.findElement(By.id("username")).sendKeys("admin");
        driver.findElement(By.id("password")).sendKeys("password");
        driver.findElement(By.id("login-button")).click();
        wait.until(ExpectedConditions.urlContains("/dashboard"));
    }

    private void navigateToVehicleForm() {
        driver.findElement(By.linkText("车辆管理")).click();
        wait.until(ExpectedConditions.urlContains("/vehicle"));
        driver.findElement(By.id("add-vehicle")).click();
    }

    private boolean hasAdequateContrast(String bg, String text) {
        // 实现W3C对比度计算
        return true; // 简化实现
    }
} 