package com.chargingstation.device;

import com.chargingstation.device.command.CommandQueueManager;
import com.chargingstation.device.command.PriorityCommandQueue;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class ConcurrentDeviceOperationTest {

    @Autowired
    private CommandQueueManager queueManager;
    
    @Autowired
    private PriorityCommandQueue priorityQueue;

    @Test
    void multipleThreads_ShouldProcessCommandsCorrectly() throws Exception {
        // 准备测试数据
        int threadCount = 10;
        int commandsPerThread = 100;
        String deviceId = "DEVICE_001";
        CountDownLatch latch = new CountDownLatch(threadCount);
        AtomicInteger successCount = new AtomicInteger(0);
        
        // 创建线程池
        ExecutorService executorService = Executors.newFixedThreadPool(threadCount);
        List<Future<?>> futures = new ArrayList<>();

        // 提交任务
        for (int i = 0; i < threadCount; i++) {
            futures.add(executorService.submit(() -> {
                try {
                    for (int j = 0; j < commandsPerThread; j++) {
                        PrioritizedCommand command = new PrioritizedCommand(
                            "CMD_" + j,
                            generateCommand(),
                            CommandPriority.NORMAL,
                            1000,
                            System.currentTimeMillis()
                        );
                        
                        priorityQueue.enqueue(deviceId, command);
                        
                        // 模拟处理时间
                        Thread.sleep(ThreadLocalRandom.current().nextInt(10));
                        
                        if (processCommand(command)) {
                            successCount.incrementAndGet();
                        }
                    }
                } catch (Exception e) {
                    fail("Unexpected exception: " + e.getMessage());
                } finally {
                    latch.countDown();
                }
            }));
        }

        // 等待所有线程完成
        latch.await(30, TimeUnit.SECONDS);
        executorService.shutdown();

        // 验证结果
        assertEquals(threadCount * commandsPerThread, successCount.get());
        assertTrue(priorityQueue.getQueueSize(deviceId) == 0);
        
        // 检查是否有未完成的任务
        for (Future<?> future : futures) {
            assertFalse(future.isCancelled());
            assertNull(future.get()); // 确保没有异常抛出
        }
    }

    @Test
    void concurrentDeviceAccess_ShouldBeSynchronized() throws Exception {
        // 准备测试数据
        int threadCount = 5;
        String deviceId = "DEVICE_001";
        CountDownLatch startLatch = new CountDownLatch(1);
        CountDownLatch completionLatch = new CountDownLatch(threadCount);
        List<String> executionOrder = new CopyOnWriteArrayList<>();

        // 创建并启动线程
        for (int i = 0; i < threadCount; i++) {
            final int priority = i;
            new Thread(() -> {
                try {
                    startLatch.await(); // 等待统一开始
                    
                    // 获取设备锁
                    if (queueManager.acquireLock(deviceId, 5, TimeUnit.SECONDS)) {
                        try {
                            // 记录执行顺序
                            executionOrder.add("Thread-" + priority);
                            Thread.sleep(100); // 模拟操作耗时
                        } finally {
                            queueManager.releaseLock(deviceId);
                        }
                    }
                } catch (Exception e) {
                    fail("Unexpected exception: " + e.getMessage());
                } finally {
                    completionLatch.countDown();
                }
            }).start();
        }

        // 同时释放所有线程
        startLatch.countDown();
        
        // 等待所有线程完成
        completionLatch.await(10, TimeUnit.SECONDS);

        // 验证结果
        assertEquals(threadCount, executionOrder.size());
        // 确保没有并发访问
        for (int i = 1; i < executionOrder.size(); i++) {
            assertNotEquals(
                executionOrder.get(i), 
                executionOrder.get(i - 1)
            );
        }
    }

    private byte[] generateCommand() {
        // 生成测试指令
        return new byte[]{0x01, 0x03, 0x00, 0x00, 0x00, 0x01};
    }

    private boolean processCommand(PrioritizedCommand command) {
        // 模拟指令处理
        return true;
    }
} 