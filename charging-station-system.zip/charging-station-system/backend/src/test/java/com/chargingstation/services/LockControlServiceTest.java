package com.chargingstation.services;

import com.chargingstation.device.ModbusClient;
import com.chargingstation.exceptions.DeviceControlException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.concurrent.TimeoutException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LockControlServiceTest {

    @Mock
    private ModbusClient modbusClient;

    @InjectMocks
    private LockControlService service;

    private static final String LOCK_ID = "1";

    @Test
    void unlockLock_Success() throws Exception {
        // 准备模拟响应数据
        byte[] successResponse = {
            0x01,  // 设备地址
            0x06,  // 功能码
            0x10, 0x00,  // 寄存器地址
            0x00, 0x01,  // 数据（开锁指令）
            (byte) 0x9C, (byte) 0x0B  // CRC校验（示例值）
        };
        
        when(modbusClient.sendCommand(any(byte[].class), anyInt()))
            .thenReturn(successResponse);

        // 执行测试
        boolean result = service.unlockLock(LOCK_ID);

        // 验证结果
        assertTrue(result);
        verify(modbusClient).sendCommand(any(byte[].class), eq(3000));
    }

    @Test
    void lockLock_Success() throws Exception {
        // 准备模拟响应数据
        byte[] successResponse = {
            0x01,  // 设备地址
            0x06,  // 功能码
            0x10, 0x00,  // 寄存器地址
            0x00, 0x02,  // 数据（闭锁指令）
            (byte) 0x9C, (byte) 0x0B  // CRC校验（示例值）
        };
        
        when(modbusClient.sendCommand(any(byte[].class), anyInt()))
            .thenReturn(successResponse);

        // 执行测试
        boolean result = service.lockLock(LOCK_ID);

        // 验证结果
        assertTrue(result);
        verify(modbusClient).sendCommand(any(byte[].class), eq(3000));
    }

    @Test
    void unlockLock_Timeout() throws Exception {
        // 模拟超时异常
        when(modbusClient.sendCommand(any(byte[].class), anyInt()))
            .thenThrow(new TimeoutException("通信超时"));

        // 执行测试并验证异常
        DeviceControlException exception = assertThrows(
            DeviceControlException.class,
            () -> service.unlockLock(LOCK_ID)
        );
        
        assertTrue(exception.getMessage().contains("地锁通信超时"));
    }

    @Test
    void lockLock_InvalidResponse() throws Exception {
        // 准备无效的响应数据
        byte[] invalidResponse = {
            0x02,  // 错误的设备地址
            0x06,
            0x10, 0x00,
            0x00, 0x02,
            0x00, 0x00
        };
        
        when(modbusClient.sendCommand(any(byte[].class), anyInt()))
            .thenReturn(invalidResponse);

        // 执行测试并验证异常
        DeviceControlException exception = assertThrows(
            DeviceControlException.class,
            () -> service.lockLock(LOCK_ID)
        );
        
        assertTrue(exception.getMessage().contains("地锁响应无效"));
    }

    @Test
    void unlockLock_DeviceError() throws Exception {
        // 准备错误响应数据
        byte[] errorResponse = {
            0x01,
            (byte) 0x86,  // 错误功能码
            0x02,  // 错误码
            0x00, 0x00, 0x00, 0x00, 0x00
        };
        
        when(modbusClient.sendCommand(any(byte[].class), anyInt()))
            .thenReturn(errorResponse);

        // 执行测试并验证异常
        DeviceControlException exception = assertThrows(
            DeviceControlException.class,
            () -> service.unlockLock(LOCK_ID)
        );
        
        assertTrue(exception.getMessage().contains("地锁响应无效"));
    }

    @Test
    void lockLock_CommunicationError() throws Exception {
        // 模拟通信异常
        when(modbusClient.sendCommand(any(byte[].class), anyInt()))
            .thenThrow(new RuntimeException("通信错误"));

        // 执行测试并验证异常
        DeviceControlException exception = assertThrows(
            DeviceControlException.class,
            () -> service.lockLock(LOCK_ID)
        );
        
        assertTrue(exception.getMessage().contains("地锁控制异常"));
    }

    @Test
    void unlockLock_RetrySuccess() throws Exception {
        // 第一次调用超时，第二次成功
        byte[] successResponse = {
            0x01, 0x06, 0x10, 0x00, 0x00, 0x01,
            (byte) 0x9C, (byte) 0x0B
        };
        
        when(modbusClient.sendCommand(any(byte[].class), anyInt()))
            .thenThrow(new TimeoutException("First attempt timeout"))
            .thenReturn(successResponse);

        // 执行测试
        boolean result = service.unlockLock(LOCK_ID);

        // 验证结果
        assertTrue(result);
        verify(modbusClient, times(2)).sendCommand(any(byte[].class), anyInt());
    }

    @Test
    void getLockStatus_Success() throws Exception {
        // 准备模拟响应数据
        byte[] successResponse = {
            0x01,           // 设备地址
            0x03,           // 功能码
            0x02,           // 字节数
            0x03,           // 状态字节 (已锁定 & 在线)
            0x0F, 0x42,     // 电压值 (12.2V)
            (byte) 0x9C, (byte) 0x0B  // CRC校验
        };
        
        when(modbusClient.sendCommand(any(byte[].class), anyInt()))
            .thenReturn(successResponse);

        // 执行测试
        LockStatusDTO status = service.getLockStatus(LOCK_ID);

        // 验证结果
        assertNotNull(status);
        assertEquals(LOCK_ID, status.getDeviceId());
        assertTrue(status.isLocked());
        assertTrue(status.isOnline());
        assertFalse(status.hasError());
        assertEquals(12.2, status.getVoltage(), 0.1);
    }

    @Test
    void getLockStatus_Error() throws Exception {
        // 准备错误响应数据
        byte[] errorResponse = {
            0x01,           // 设备地址
            0x03,           // 功能码
            0x02,           // 字节数
            0x34,           // 状态字节 (错误状态)
            0x0F, 0x42,     // 电压值
            (byte) 0x9C, (byte) 0x0B  // CRC校验
        };
        
        when(modbusClient.sendCommand(any(byte[].class), anyInt()))
            .thenReturn(errorResponse);

        // 执行测试
        LockStatusDTO status = service.getLockStatus(LOCK_ID);

        // 验证结果
        assertTrue(status.hasError());
        assertEquals("电机故障", status.getErrorMessage());
    }

    @Test
    void batchUnlock_Success() throws Exception {
        // 准备测试数据
        List<String> lockIds = Arrays.asList("1", "2", "3");
        byte[] successResponse = {
            0x01, 0x06, 0x10, 0x00, 0x00, 0x01,
            (byte) 0x9C, (byte) 0x0B
        };
        
        when(modbusClient.sendCommand(any(byte[].class), anyInt()))
            .thenReturn(successResponse);

        // 执行测试
        Map<String, Boolean> results = service.batchUnlock(lockIds);

        // 验证结果
        assertEquals(3, results.size());
        assertTrue(results.values().stream().allMatch(result -> result));
    }

    @Test
    void batchLock_PartialSuccess() throws Exception {
        // 准备测试数据
        List<String> lockIds = Arrays.asList("1", "2", "3");
        
        when(modbusClient.sendCommand(any(byte[].class), anyInt()))
            .thenReturn(new byte[]{0x01, 0x06, 0x10, 0x00, 0x00, 0x02, 0x00, 0x00})  // 成功响应
            .thenThrow(new TimeoutException("超时"))  // 第二个设备超时
            .thenReturn(new byte[]{0x03, 0x06, 0x10, 0x00, 0x00, 0x02, 0x00, 0x00}); // 成功响应

        // 执行测试
        Map<String, Boolean> results = service.batchLock(lockIds);

        // 验证结果
        assertEquals(3, results.size());
        assertTrue(results.get("1"));
        assertFalse(results.get("2"));
        assertTrue(results.get("3"));
    }
} 