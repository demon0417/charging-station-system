-- 车辆表索引
CREATE INDEX idx_vehicle_plate_number ON vehicles(plate_number);
CREATE INDEX idx_vehicle_type ON vehicles(vehicle_type);
CREATE INDEX idx_vehicle_entry_time ON vehicles(entry_time);
CREATE INDEX idx_vehicle_exit_time ON vehicles(exit_time);

-- 停车记录表索引
CREATE INDEX idx_parking_vehicle_id ON parking_records(vehicle_id);
CREATE INDEX idx_parking_start_time ON parking_records(start_time);
CREATE INDEX idx_parking_end_time ON parking_records(end_time);
CREATE INDEX idx_parking_composite ON parking_records(vehicle_id, start_time, end_time);

-- 充电记录表索引
CREATE INDEX idx_charging_vehicle_id ON charging_records(vehicle_id);
CREATE INDEX idx_charging_start_time ON charging_records(start_time);
CREATE INDEX idx_charging_end_time ON charging_records(end_time);
CREATE INDEX idx_charging_composite ON charging_records(vehicle_id, start_time, end_time); 