package com.chargingstation.security.encryption;

import com.amazonaws.services.kms.AWSKMS;
import com.amazonaws.services.kms.model.DecryptRequest;
import com.amazonaws.services.kms.model.EncryptRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.nio.ByteBuffer;
import java.util.Base64;

@Slf4j
@Service
@RequiredArgsConstructor
public class ConfigEncryptionService {

    private final AWSKMS kmsClient;

    @Value("${aws.kms.key-id}")
    private String kmsKeyId;

    public String encryptValue(String plaintext) {
        try {
            ByteBuffer plaintextBuffer = ByteBuffer.wrap(plaintext.getBytes());
            
            EncryptRequest request = new EncryptRequest()
                .withKeyId(kmsKeyId)
                .withPlaintext(plaintextBuffer);

            ByteBuffer ciphertextBuffer = kmsClient.encrypt(request).getCiphertextBlob();
            return Base64.getEncoder().encodeToString(ciphertextBuffer.array());
        } catch (Exception e) {
            log.error("配置加密失败", e);
            throw new SecurityException("配置加密失败", e);
        }
    }

    public String decryptValue(String encryptedValue) {
        try {
            byte[] encryptedBytes = Base64.getDecoder().decode(encryptedValue);
            ByteBuffer encryptedBuffer = ByteBuffer.wrap(encryptedBytes);
            
            DecryptRequest request = new DecryptRequest()
                .withCiphertextBlob(encryptedBuffer);

            ByteBuffer plaintextBuffer = kmsClient.decrypt(request).getPlaintext();
            return new String(plaintextBuffer.array());
        } catch (Exception e) {
            log.error("配置解密失败", e);
            throw new SecurityException("配置解密失败", e);
        }
    }
} 