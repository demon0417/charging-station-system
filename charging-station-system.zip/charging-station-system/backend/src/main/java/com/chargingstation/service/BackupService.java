package com.chargingstation.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;

@Slf4j
@Service
@RequiredArgsConstructor
public class BackupService {

    @Value("${backup.mysql.host}")
    private String dbHost;

    @Value("${backup.mysql.port}")
    private String dbPort;

    @Value("${backup.mysql.database}")
    private String dbName;

    @Value("${backup.mysql.username}")
    private String dbUsername;

    @Value("${backup.mysql.password}")
    private String dbPassword;

    @Value("${backup.directory}")
    private String backupDirectory;

    @Value("${backup.retention-days}")
    private int retentionDays;

    @Scheduled(cron = "0 0 2 * * ?") // 每天凌晨2点执行备份
    public void performBackup() {
        try {
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            String backupFile = String.format("%s/backup_%s.sql", backupDirectory, timestamp);

            // 执行mysqldump命令
            ProcessBuilder processBuilder = new ProcessBuilder(
                "mysqldump",
                "-h", dbHost,
                "-P", dbPort,
                "-u", dbUsername,
                "-p" + dbPassword,
                dbName,
                "--result-file=" + backupFile
            );

            Process process = processBuilder.start();
            int exitCode = process.waitFor();

            if (exitCode == 0) {
                log.info("数据库备份成功: {}", backupFile);
                cleanupOldBackups();
            } else {
                log.error("数据库备份失败，退出码: {}", exitCode);
            }
        } catch (Exception e) {
            log.error("执行备份时发生错误", e);
        }
    }

    private void cleanupOldBackups() {
        File backupDir = new File(backupDirectory);
        if (!backupDir.exists() || !backupDir.isDirectory()) {
            return;
        }

        LocalDateTime cutoffDate = LocalDateTime.now().minusDays(retentionDays);
        File[] backupFiles = backupDir.listFiles((dir, name) -> name.startsWith("backup_") && name.endsWith(".sql"));

        if (backupFiles != null) {
            Arrays.stream(backupFiles)
                .filter(file -> isFileOlderThan(file, cutoffDate))
                .forEach(file -> {
                    if (file.delete()) {
                        log.info("删除过期备份文件: {}", file.getName());
                    }
                });
        }
    }

    private boolean isFileOlderThan(File file, LocalDateTime cutoffDate) {
        String timestamp = file.getName().substring(7, 21); // 提取文件名中的时间戳
        LocalDateTime fileDate = LocalDateTime.parse(timestamp, DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        return fileDate.isBefore(cutoffDate);
    }
} 