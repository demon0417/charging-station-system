package com.chargingstation.device.retry;

import io.github.resilience4j.retry.RetryConfig;
import io.github.resilience4j.retry.RetryRegistry;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;
import java.util.concurrent.TimeoutException;

@Configuration
public class DeviceCommunicationRetryConfig {

    @Bean
    public RetryRegistry deviceRetryRegistry() {
        RetryConfig config = RetryConfig.custom()
            .maxAttempts(3)
            .waitDuration(Duration.ofMillis(500))
            .retryExceptions(
                TimeoutException.class,
                DeviceCommunicationException.class
            )
            .ignoreExceptions(
                DeviceOfflineException.class,
                InvalidCommandException.class
            )
            .build();
            
        return RetryRegistry.of(config);
    }
} 