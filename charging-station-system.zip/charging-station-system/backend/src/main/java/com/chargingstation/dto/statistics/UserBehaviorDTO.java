package com.chargingstation.dto.statistics;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.Map;

@Data
@Builder
public class UserBehaviorDTO {
    private long totalVisits;
    private Duration averageStayTime;
    private BigDecimal totalSpending;
    private Map<Integer, Long> visitTimeDistribution; // 按小时统计访问次数
} 