package com.chargingstation.device.loadbalancer;

import com.chargingstation.device.monitor.CommandExecutionMonitor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

@Slf4j
@Component
@RequiredArgsConstructor
public class DeviceLoadBalancer {

    private final CommandExecutionMonitor monitor;
    
    // 设备负载状态
    private final Map<String, DeviceLoad> deviceLoads = new ConcurrentHashMap<>();
    
    // 轮询计数器
    private final AtomicInteger roundRobinCounter = new AtomicInteger(0);
    
    // 负载阈值
    private static final int HIGH_LOAD_THRESHOLD = 80;  // 高负载阈值(%)
    private static final int MAX_LOAD = 100;           // 最大负载
    
    /**
     * 选择最佳设备
     */
    public String selectDevice(List<String> availableDevices) {
        if (availableDevices == null || availableDevices.isEmpty()) {
            throw new IllegalArgumentException("没有可用的设备");
        }

        // 使用不同的负载均衡策略
        return switch (getCurrentStrategy()) {
            case ROUND_ROBIN -> selectByRoundRobin(availableDevices);
            case LEAST_CONNECTIONS -> selectByLeastConnections(availableDevices);
            case LEAST_LOAD -> selectByLeastLoad(availableDevices);
            case WEIGHTED_RESPONSE_TIME -> selectByWeightedResponseTime(availableDevices);
        };
    }

    /**
     * 更新设备负载
     */
    public void updateDeviceLoad(String deviceId, int commandCount, double responseTime) {
        DeviceLoad load = deviceLoads.computeIfAbsent(deviceId, k -> new DeviceLoad());
        load.updateLoad(commandCount, responseTime);
        
        // 检查负载是否过高
        if (load.getCurrentLoad() > HIGH_LOAD_THRESHOLD) {
            log.warn("设备{}负载过高: {}%", deviceId, load.getCurrentLoad());
        }
    }

    /**
     * 获取当前负载均衡策略
     */
    private LoadBalanceStrategy getCurrentStrategy() {
        // 根据系统负载和性能指标动态选择策略
        double systemLoad = getSystemLoad();
        double avgResponseTime = getAverageResponseTime();
        
        if (systemLoad > HIGH_LOAD_THRESHOLD) {
            return LoadBalanceStrategy.LEAST_LOAD;
        } else if (avgResponseTime > 1000) {  // 1秒
            return LoadBalanceStrategy.WEIGHTED_RESPONSE_TIME;
        } else {
            return LoadBalanceStrategy.ROUND_ROBIN;
        }
    }

    /**
     * 轮询策略
     */
    private String selectByRoundRobin(List<String> devices) {
        int index = roundRobinCounter.getAndIncrement() % devices.size();
        return devices.get(index);
    }

    /**
     * 最少连接策略
     */
    private String selectByLeastConnections(List<String> devices) {
        return devices.stream()
            .min((d1, d2) -> {
                DeviceLoad load1 = deviceLoads.getOrDefault(d1, new DeviceLoad());
                DeviceLoad load2 = deviceLoads.getOrDefault(d2, new DeviceLoad());
                return Integer.compare(load1.getConnectionCount(), load2.getConnectionCount());
            })
            .orElse(devices.get(0));
    }

    /**
     * 最小负载策略
     */
    private String selectByLeastLoad(List<String> devices) {
        return devices.stream()
            .min((d1, d2) -> {
                DeviceLoad load1 = deviceLoads.getOrDefault(d1, new DeviceLoad());
                DeviceLoad load2 = deviceLoads.getOrDefault(d2, new DeviceLoad());
                return Double.compare(load1.getCurrentLoad(), load2.getCurrentLoad());
            })
            .orElse(devices.get(0));
    }

    /**
     * 加权响应时间策略
     */
    private String selectByWeightedResponseTime(List<String> devices) {
        return devices.stream()
            .min((d1, d2) -> {
                DeviceLoad load1 = deviceLoads.getOrDefault(d1, new DeviceLoad());
                DeviceLoad load2 = deviceLoads.getOrDefault(d2, new DeviceLoad());
                double score1 = calculateScore(load1);
                double score2 = calculateScore(load2);
                return Double.compare(score1, score2);
            })
            .orElse(devices.get(0));
    }

    /**
     * 计算设备得分
     */
    private double calculateScore(DeviceLoad load) {
        double loadWeight = 0.4;
        double responseTimeWeight = 0.6;
        return (load.getCurrentLoad() * loadWeight) + 
               (load.getAverageResponseTime() * responseTimeWeight);
    }

    private enum LoadBalanceStrategy {
        ROUND_ROBIN,
        LEAST_CONNECTIONS,
        LEAST_LOAD,
        WEIGHTED_RESPONSE_TIME
    }

    /**
     * 设备负载状态
     */
    private static class DeviceLoad {
        private final AtomicInteger connectionCount = new AtomicInteger(0);
        private volatile double currentLoad = 0.0;
        private volatile double avgResponseTime = 0.0;
        private final Object lock = new Object();

        public void updateLoad(int commands, double responseTime) {
            synchronized (lock) {
                connectionCount.set(commands);
                currentLoad = Math.min((commands * 100.0) / MAX_LOAD, 100.0);
                avgResponseTime = (avgResponseTime * 0.7) + (responseTime * 0.3);  // 指数移动平均
            }
        }

        public int getConnectionCount() {
            return connectionCount.get();
        }

        public double getCurrentLoad() {
            return currentLoad;
        }

        public double getAverageResponseTime() {
            return avgResponseTime;
        }
    }
} 