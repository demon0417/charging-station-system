package com.chargingstation.device.debug;

import com.chargingstation.device.adapter.DeviceAdapter;
import com.chargingstation.dto.DebugCommandDTO;
import com.chargingstation.dto.DebugResultDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Service
@RequiredArgsConstructor
public class RemoteDebugService {

    private final DeviceAdapter deviceAdapter;
    private final Map<String, DebugSession> activeSessions = new ConcurrentHashMap<>();

    /**
     * 启动调试会话
     */
    public DebugSession startDebugSession(String deviceId) {
        // 检查是否已存在会话
        if (activeSessions.containsKey(deviceId)) {
            throw new IllegalStateException("设备已存在调试会话");
        }
        
        // 创建新会话
        DebugSession session = new DebugSession(deviceId);
        activeSessions.put(deviceId, session);
        
        // 初始化设备调试模式
        deviceAdapter.enterDebugMode(deviceId);
        
        return session;
    }

    /**
     * 执行调试命令
     */
    public DebugResultDTO executeCommand(String deviceId, DebugCommandDTO command) {
        DebugSession session = getActiveSession(deviceId);
        
        try {
            // 记录命令
            session.recordCommand(command);
            
            // 执行命令
            Map<String, Object> result = deviceAdapter.executeDebugCommand(
                deviceId,
                command.getCommand(),
                command.getParameters()
            );
            
            // 记录结果
            DebugResultDTO debugResult = DebugResultDTO.builder()
                .success(true)
                .data(result)
                .build();
            session.recordResult(debugResult);
            
            return debugResult;
            
        } catch (Exception e) {
            log.error("调试命令执行失败: {}", command, e);
            DebugResultDTO errorResult = DebugResultDTO.builder()
                .success(false)
                .error(e.getMessage())
                .build();
            session.recordResult(errorResult);
            return errorResult;
        }
    }

    /**
     * 结束调试会话
     */
    public void endDebugSession(String deviceId) {
        DebugSession session = getActiveSession(deviceId);
        
        try {
            // 退出调试模式
            deviceAdapter.exitDebugMode(deviceId);
            
            // 保存调试日志
            session.saveLog();
            
        } finally {
            // 移除会话
            activeSessions.remove(deviceId);
        }
    }

    /**
     * 获取活动会话
     */
    private DebugSession getActiveSession(String deviceId) {
        DebugSession session = activeSessions.get(deviceId);
        if (session == null) {
            throw new IllegalStateException("设备没有活动的调试会话");
        }
        return session;
    }

    /**
     * 获取调试会话状态
     */
    public DebugSession.SessionStatus getSessionStatus(String deviceId) {
        return getActiveSession(deviceId).getStatus();
    }

    /**
     * 获取调试历史记录
     */
    public List<DebugCommandDTO> getDebugHistory(String deviceId) {
        return getActiveSession(deviceId).getCommandHistory();
    }
} 