package com.chargingstation.repositories;

import com.chargingstation.models.ChargingRecord;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;

@Repository
public interface ChargingRecordRepository extends JpaRepository<ChargingRecord, Long> {
    
    @Query("SELECT c FROM ChargingRecord c WHERE c.vehicle.id = :vehicleId AND c.endTime IS NULL")
    Optional<ChargingRecord> findActiveRecordByVehicleId(@Param("vehicleId") Long vehicleId);
    
    Page<ChargingRecord> findByVehicleIdOrderByStartTimeDesc(Long vehicleId, Pageable pageable);
    
    @Query("SELECT c FROM ChargingRecord c WHERE " +
           "(:vehicleId IS NULL OR c.vehicle.id = :vehicleId) AND " +
           "(:startTime IS NULL OR c.startTime >= :startTime) AND " +
           "(:endTime IS NULL OR c.startTime <= :endTime)")
    Page<ChargingRecord> findByConditions(
        @Param("vehicleId") Long vehicleId,
        @Param("startTime") LocalDateTime startTime,
        @Param("endTime") LocalDateTime endTime,
        Pageable pageable
    );
    
    @Query("SELECT COUNT(c) FROM ChargingRecord c WHERE c.endTime IS NULL")
    long countCurrentCharging();
    
    @Query("SELECT SUM(c.chargingFee) FROM ChargingRecord c WHERE " +
           "c.endTime >= :startTime AND c.endTime < :endTime")
    BigDecimal calculateDailyIncome(@Param("startTime") LocalDateTime startTime, 
                                   @Param("endTime") LocalDateTime endTime);
} 