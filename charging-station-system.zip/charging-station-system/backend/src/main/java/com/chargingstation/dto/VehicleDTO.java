package com.chargingstation.dto;

import com.chargingstation.models.enums.VehicleType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class VehicleDTO {
    @NotBlank(message = "车牌号不能为空")
    private String plateNumber;
    
    @NotNull(message = "车辆类型不能为空")
    private VehicleType vehicleType;
    
    private LocalDateTime entryTime = LocalDateTime.now();
} 