package com.chargingstation.device.sync;

import com.chargingstation.device.persistence.DeviceState;
import com.chargingstation.device.persistence.DeviceStateRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Component
@RequiredArgsConstructor
public class DeviceStateSynchronizer {

    private final DeviceStateRepository stateRepository;
    private final Map<String, SyncState> syncStates = new ConcurrentHashMap<>();
    
    // 同步配置
    private static final int BATCH_SIZE = 50;
    private static final long SYNC_INTERVAL = 5000;  // 5秒
    private static final int MAX_RETRY_COUNT = 3;
    
    /**
     * 定时同步任务
     */
    @Scheduled(fixedRate = SYNC_INTERVAL)
    public void synchronizeStates() {
        try {
            List<DeviceState> states = stateRepository.findAll();
            
            for (int i = 0; i < states.size(); i += BATCH_SIZE) {
                List<DeviceState> batch = states.subList(
                    i, 
                    Math.min(i + BATCH_SIZE, states.size())
                );
                synchronizeBatch(batch);
            }
            
        } catch (Exception e) {
            log.error("设备状态同步失败", e);
        }
    }

    /**
     * 批量同步设备状态
     */
    private void synchronizeBatch(List<DeviceState> states) {
        states.parallelStream().forEach(state -> {
            String deviceId = state.getDeviceId();
            SyncState syncState = syncStates.computeIfAbsent(
                deviceId, 
                k -> new SyncState()
            );
            
            try {
                if (needSync(state, syncState)) {
                    synchronizeDevice(state);
                    syncState.updateLastSync();
                    syncState.resetRetryCount();
                }
            } catch (Exception e) {
                handleSyncFailure(deviceId, syncState, e);
            }
        });
    }

    /**
     * 判断是否需要同步
     */
    private boolean needSync(DeviceState state, SyncState syncState) {
        return state.getLastUpdateTime().isAfter(syncState.getLastSyncTime()) ||
               syncState.hasRetries();
    }

    /**
     * 同步单个设备状态
     */
    private void synchronizeDevice(DeviceState state) {
        try {
            // TODO: 实现具体的设备状态同步逻辑
            // 1. 获取设备实时状态
            // 2. 比较并更新差异
            // 3. 持久化更新
            
            log.debug("设备{}状态同步成功", state.getDeviceId());
            
        } catch (Exception e) {
            log.error("设备{}状态同步失败", state.getDeviceId(), e);
            throw e;
        }
    }

    /**
     * 处理同步失败
     */
    private void handleSyncFailure(String deviceId, SyncState syncState, Exception e) {
        syncState.incrementRetryCount();
        
        if (syncState.getRetryCount() >= MAX_RETRY_COUNT) {
            log.error("设备{}状态同步失败次数过多", deviceId, e);
            // TODO: 发送告警通知
        } else {
            log.warn("设备{}状态同步失败,将在下次重试", deviceId, e);
        }
    }

    /**
     * 同步状态类
     */
    private static class SyncState {
        private LocalDateTime lastSyncTime = LocalDateTime.now().minusHours(1);
        private int retryCount = 0;
        private final Object lock = new Object();

        public void updateLastSync() {
            synchronized (lock) {
                lastSyncTime = LocalDateTime.now();
            }
        }

        public void incrementRetryCount() {
            synchronized (lock) {
                retryCount++;
            }
        }

        public void resetRetryCount() {
            synchronized (lock) {
                retryCount = 0;
            }
        }

        public LocalDateTime getLastSyncTime() {
            return lastSyncTime;
        }

        public int getRetryCount() {
            return retryCount;
        }

        public boolean hasRetries() {
            return retryCount > 0 && retryCount < MAX_RETRY_COUNT;
        }
    }
} 