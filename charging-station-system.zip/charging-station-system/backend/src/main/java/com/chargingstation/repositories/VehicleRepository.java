package com.chargingstation.repositories;

import com.chargingstation.models.Vehicle;
import com.chargingstation.models.enums.VehicleType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface VehicleRepository extends JpaRepository<Vehicle, Long> {
    Optional<Vehicle> findByPlateNumber(String plateNumber);
    boolean existsByPlateNumber(String plateNumber);
    Page<Vehicle> findByVehicleType(VehicleType vehicleType, Pageable pageable);
    Page<Vehicle> findByEntryTimeBetween(LocalDateTime start, LocalDateTime end, Pageable pageable);
    @Query("SELECT v FROM Vehicle v WHERE v.entryTime <= :time AND v.exitTime IS NULL")
    List<Vehicle> findCurrentParkedVehicles(@Param("time") LocalDateTime time);
    long countByVehicleType(VehicleType vehicleType);
    @Query("SELECT COUNT(v) FROM Vehicle v WHERE v.entryTime >= :start AND v.entryTime < :end")
    long countDailyVehicles(@Param("start") LocalDateTime start, @Param("end") LocalDateTime end);
    @Query("SELECT v FROM Vehicle v WHERE " +
           "(:plateNumber IS NULL OR v.plateNumber LIKE %:plateNumber%) AND " +
           "(:vehicleType IS NULL OR v.vehicleType = :vehicleType) AND " +
           "(:startTime IS NULL OR v.entryTime >= :startTime) AND " +
           "(:endTime IS NULL OR v.entryTime <= :endTime)")
    Page<Vehicle> findByConditions(
        @Param("plateNumber") String plateNumber,
        @Param("vehicleType") VehicleType vehicleType,
        @Param("startTime") LocalDateTime startTime,
        @Param("endTime") LocalDateTime endTime,
        Pageable pageable
    );
    @Query("UPDATE Vehicle v SET v.exitTime = :exitTime WHERE v.id IN :ids AND v.exitTime IS NULL")
    int batchUpdateExitTime(@Param("ids") List<Long> ids, @Param("exitTime") LocalDateTime exitTime);
} 