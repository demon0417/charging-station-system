package com.chargingstation.services;

import com.chargingstation.device.ModbusClient;
import com.chargingstation.exceptions.DeviceControlException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.concurrent.TimeoutException;

@Slf4j
@Service
@RequiredArgsConstructor
public class LockControlService {

    private final ModbusClient modbusClient;
    
    // Modbus功能码
    private static final byte WRITE_SINGLE_REGISTER = 0x06;
    
    // 地锁控制指令
    private static final byte UNLOCK_COMMAND = 0x01;
    private static final byte LOCK_COMMAND = 0x02;
    
    // 地锁状态寄存器地址
    private static final int STATUS_REGISTER_ADDRESS = 0x1000;
    
    // 超时时间（毫秒）
    private static final int DEFAULT_TIMEOUT = 3000;
    
    // 响应长度（字节）
    private static final int RESPONSE_LENGTH = 8;

    /**
     * 开锁
     */
    @Retryable(
        value = {DeviceControlException.class},
        maxAttempts = 3,
        backoff = @Backoff(delay = 1000)
    )
    public boolean unlockLock(String lockId) {
        log.info("发送开锁指令到地锁: {}", lockId);
        return sendCommand(lockId, UNLOCK_COMMAND);
    }

    /**
     * 闭锁
     */
    @Retryable(
        value = {DeviceControlException.class},
        maxAttempts = 3,
        backoff = @Backoff(delay = 1000)
    )
    public boolean lockLock(String lockId) {
        log.info("发送闭锁指令到地锁: {}", lockId);
        return sendCommand(lockId, LOCK_COMMAND);
    }

    /**
     * 发送Modbus指令
     */
    private boolean sendCommand(String lockId, byte command) {
        try {
            // 构建Modbus指令
            byte[] modbusCommand = buildModbusCommand(lockId, command);
            
            // 发送指令并等待响应
            byte[] response = modbusClient.sendCommand(modbusCommand, DEFAULT_TIMEOUT);
            
            // 验证响应
            if (!validateResponse(response, Byte.parseByte(lockId), command)) {
                String error = String.format(
                    "地锁响应无效 - 设备ID: %s, 指令: 0x%02X, 响应: %s",
                    lockId, command, bytesToHex(response)
                );
                throw new DeviceControlException(error);
            }
            
            log.info("地锁{}指令执行成功 - 指令: 0x{}", lockId, String.format("%02X", command));
            return true;
            
        } catch (TimeoutException e) {
            String error = String.format("地锁通信超时 - 设备ID: %s", lockId);
            log.error(error, e);
            throw new DeviceControlException(error, e);
            
        } catch (Exception e) {
            String error = String.format("地锁控制异常 - 设备ID: %s", lockId);
            log.error(error, e);
            throw new DeviceControlException(error, e);
        }
    }

    /**
     * 构建Modbus指令
     * 格式: [设备地址(1字节)][功能码(1字节)][寄存器地址(2字节)][数据(2字节)][CRC(2字节)]
     */
    private byte[] buildModbusCommand(String lockId, byte command) {
        byte deviceAddress = Byte.parseByte(lockId);
        
        byte[] command = new byte[8];
        command[0] = deviceAddress;                    // 设备地址
        command[1] = WRITE_SINGLE_REGISTER;           // 功能码
        command[2] = (byte) (STATUS_REGISTER_ADDRESS >> 8);  // 寄存器地址高字节
        command[3] = (byte) STATUS_REGISTER_ADDRESS;         // 寄存器地址低字节
        command[4] = 0x00;                            // 数据高字节
        command[5] = command;                         // 数据低字节
        
        // 计算CRC校验
        byte[] crc = calculateCRC(Arrays.copyOfRange(command, 0, 6));
        command[6] = crc[0];
        command[7] = crc[1];
        
        return command;
    }

    /**
     * 验证Modbus响应
     * 格式: [设备地址(1字节)][功能码(1字节)][寄存器地址(2字节)][数据(2字节)][CRC(2字节)]
     */
    private boolean validateResponse(byte[] response, byte deviceAddress, byte command) {
        // 检查响应长度
        if (response == null || response.length != RESPONSE_LENGTH) {
            return false;
        }
        
        // 验证设备地址
        if (response[0] != deviceAddress) {
            return false;
        }
        
        // 验证功能码
        if (response[1] != WRITE_SINGLE_REGISTER) {
            return false;
        }
        
        // 验证寄存器地址
        int address = ((response[2] & 0xFF) << 8) | (response[3] & 0xFF);
        if (address != STATUS_REGISTER_ADDRESS) {
            return false;
        }
        
        // 验证数据
        if (response[4] != 0x00 || response[5] != command) {
            return false;
        }
        
        // 验证CRC校验
        byte[] expectedCrc = calculateCRC(Arrays.copyOfRange(response, 0, 6));
        return response[6] == expectedCrc[0] && response[7] == expectedCrc[1];
    }

    /**
     * 计算CRC校验值
     */
    private byte[] calculateCRC(byte[] data) {
        int crc = 0xFFFF;
        for (byte b : data) {
            crc ^= (b & 0xFF);
            for (int i = 0; i < 8; i++) {
                if ((crc & 0x0001) != 0) {
                    crc = (crc >> 1) ^ 0xA001;
                } else {
                    crc = crc >> 1;
                }
            }
        }
        return new byte[]{(byte) (crc & 0xFF), (byte) ((crc >> 8) & 0xFF)};
    }

    /**
     * 字节数组转十六进制字符串
     */
    private String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02X ", b));
        }
        return sb.toString().trim();
    }

    /**
     * 查询地锁状态
     */
    @Retryable(
        value = {DeviceControlException.class},
        maxAttempts = 3,
        backoff = @Backoff(delay = 1000)
    )
    public LockStatusDTO getLockStatus(String lockId) {
        try {
            // 构建状态查询指令
            byte[] command = buildStatusCommand(lockId);
            
            // 发送指令并等待响应
            byte[] response = modbusClient.sendCommand(command, DEFAULT_TIMEOUT);
            
            // 解析响应
            return parseLockStatus(response);
            
        } catch (TimeoutException e) {
            String error = String.format("地锁状态查询超时 - 设备ID: %s", lockId);
            log.error(error, e);
            throw new DeviceControlException(error, e);
            
        } catch (Exception e) {
            String error = String.format("地锁状态查询异常 - 设备ID: %s", lockId);
            log.error(error, e);
            throw new DeviceControlException(error, e);
        }
    }

    /**
     * 批量开锁
     */
    @Transactional
    public Map<String, Boolean> batchUnlock(List<String> lockIds) {
        return lockIds.parallelStream()
            .collect(Collectors.toMap(
                lockId -> lockId,
                lockId -> {
                    try {
                        return unlockLock(lockId);
                    } catch (Exception e) {
                        log.error("批量开锁失败 - 设备ID: {}", lockId, e);
                        return false;
                    }
                }
            ));
    }

    /**
     * 批量闭锁
     */
    @Transactional
    public Map<String, Boolean> batchLock(List<String> lockIds) {
        return lockIds.parallelStream()
            .collect(Collectors.toMap(
                lockId -> lockId,
                lockId -> {
                    try {
                        return lockLock(lockId);
                    } catch (Exception e) {
                        log.error("批量闭锁失败 - 设备ID: {}", lockId, e);
                        return false;
                    }
                }
            ));
    }

    /**
     * 构建状态查询指令
     * 功能码: 0x03 (读保持寄存器)
     */
    private byte[] buildStatusCommand(String lockId) {
        byte deviceAddress = Byte.parseByte(lockId);
        
        byte[] command = new byte[8];
        command[0] = deviceAddress;                    // 设备地址
        command[1] = 0x03;                            // 功能码：读保持寄存器
        command[2] = (byte) (STATUS_REGISTER_ADDRESS >> 8);  // 寄存器地址高字节
        command[3] = (byte) STATUS_REGISTER_ADDRESS;         // 寄存器地址低字节
        command[4] = 0x00;                            // 寄存器数量高字节
        command[5] = 0x01;                            // 寄存器数量低字节
        
        // 计算CRC校验
        byte[] crc = calculateCRC(Arrays.copyOfRange(command, 0, 6));
        command[6] = crc[0];
        command[7] = crc[1];
        
        return command;
    }

    /**
     * 解析地锁状态响应
     */
    private LockStatusDTO parseLockStatus(byte[] response) {
        // 验证响应格式
        if (response == null || response.length < 7) {
            throw new DeviceControlException("状态响应数据无效");
        }
        
        // 解析状态数据
        byte status = response[3];
        boolean isLocked = (status & 0x01) != 0;
        boolean isOnline = (status & 0x02) != 0;
        boolean hasError = (status & 0x04) != 0;
        byte errorCode = (byte) ((status & 0xF0) >> 4);
        
        return LockStatusDTO.builder()
            .deviceId(String.valueOf(response[0]))
            .isLocked(isLocked)
            .isOnline(isOnline)
            .hasError(hasError)
            .errorCode(errorCode)
            .errorMessage(getErrorMessage(errorCode))
            .voltage(parseVoltage(response[4], response[5]))
            .lastUpdateTime(LocalDateTime.now())
            .build();
    }

    /**
     * 解析电压值
     */
    private double parseVoltage(byte highByte, byte lowByte) {
        int rawValue = ((highByte & 0xFF) << 8) | (lowByte & 0xFF);
        return rawValue * 0.1; // 假设电压值的精度为0.1V
    }

    /**
     * 获取错误描述
     */
    private String getErrorMessage(byte errorCode) {
        return switch (errorCode) {
            case 0x01 -> "电机故障";
            case 0x02 -> "传感器故障";
            case 0x03 -> "通信故障";
            case 0x04 -> "电压异常";
            case 0x05 -> "温度异常";
            default -> "未知故障";
        };
    }
} 