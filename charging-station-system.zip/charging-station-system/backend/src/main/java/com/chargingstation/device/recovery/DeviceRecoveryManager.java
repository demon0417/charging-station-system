package com.chargingstation.device.recovery;

import com.chargingstation.device.command.PriorityCommandQueue;
import com.chargingstation.device.monitor.CommandExecutionMonitor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

@Slf4j
@Component
@RequiredArgsConstructor
public class DeviceRecoveryManager {

    private final CommandExecutionMonitor monitor;
    private final PriorityCommandQueue commandQueue;
    
    // 故障状态
    private final Map<String, DeviceFaultState> faultStates = new ConcurrentHashMap<>();
    
    // 待恢复的指令队列
    private final Map<String, Queue<PriorityCommandQueue.PrioritizedCommand>> recoveryQueues = 
        new ConcurrentHashMap<>();
    
    // 故障阈值
    private static final int ERROR_THRESHOLD = 3;        // 连续错误阈值
    private static final int RECOVERY_ATTEMPTS = 3;      // 恢复尝试次数
    private static final long RECOVERY_INTERVAL = 5000;  // 恢复间隔(毫秒)

    /**
     * 记录故障
     */
    public void recordFault(String deviceId, String faultType, String message) {
        DeviceFaultState state = faultStates.computeIfAbsent(
            deviceId, 
            k -> new DeviceFaultState()
        );
        
        state.recordFault(faultType, message);
        
        if (state.getConsecutiveErrors() >= ERROR_THRESHOLD) {
            handleDeviceFault(deviceId, state);
        }
    }

    /**
     * 处理设备故障
     */
    private void handleDeviceFault(String deviceId, DeviceFaultState state) {
        log.error("设备{}发生故障: {}", deviceId, state.getLastFaultMessage());
        
        // 保存待恢复的指令
        Queue<PriorityCommandQueue.PrioritizedCommand> deviceQueue = 
            recoveryQueues.computeIfAbsent(deviceId, k -> new LinkedBlockingQueue<>());
        
        PriorityCommandQueue.PrioritizedCommand command;
        while ((command = commandQueue.poll(deviceId)) != null) {
            deviceQueue.offer(command);
        }
        
        // 启动恢复流程
        startRecovery(deviceId);
    }

    /**
     * 启动恢复流程
     */
    private void startRecovery(String deviceId) {
        new Thread(() -> {
            int attempts = 0;
            while (attempts < RECOVERY_ATTEMPTS) {
                try {
                    Thread.sleep(RECOVERY_INTERVAL);
                    
                    if (attemptRecovery(deviceId)) {
                        restoreCommands(deviceId);
                        log.info("设备{}恢复成功", deviceId);
                        return;
                    }
                    
                    attempts++;
                    log.warn("设备{}恢复尝试{}失败", deviceId, attempts);
                    
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                } catch (Exception e) {
                    log.error("设备{}恢复过程发生错误", deviceId, e);
                }
            }
            
            log.error("设备{}恢复失败，需要人工干预", deviceId);
        }).start();
    }

    /**
     * 尝试恢复设备
     */
    private boolean attemptRecovery(String deviceId) {
        try {
            // TODO: 实现具体的设备恢复逻辑
            // 1. 重置设备
            // 2. 诊断问题
            // 3. 执行修复操作
            return true;
        } catch (Exception e) {
            log.error("设备{}恢复尝试失败", deviceId, e);
            return false;
        }
    }

    /**
     * 恢复待执行的指令
     */
    private void restoreCommands(String deviceId) {
        Queue<PriorityCommandQueue.PrioritizedCommand> recoveryQueue = recoveryQueues.get(deviceId);
        if (recoveryQueue == null) return;
        
        PriorityCommandQueue.PrioritizedCommand command;
        while ((command = recoveryQueue.poll()) != null) {
            commandQueue.enqueue(deviceId, command);
        }
    }

    /**
     * 设备故障状态
     */
    private static class DeviceFaultState {
        private int consecutiveErrors = 0;
        private String lastFaultType;
        private String lastFaultMessage;
        private LocalDateTime lastFaultTime;
        private final Object lock = new Object();

        public void recordFault(String type, String message) {
            synchronized (lock) {
                consecutiveErrors++;
                lastFaultType = type;
                lastFaultMessage = message;
                lastFaultTime = LocalDateTime.now();
            }
        }

        public void reset() {
            synchronized (lock) {
                consecutiveErrors = 0;
                lastFaultType = null;
                lastFaultMessage = null;
                lastFaultTime = null;
            }
        }

        public int getConsecutiveErrors() {
            return consecutiveErrors;
        }

        public String getLastFaultMessage() {
            return lastFaultMessage;
        }
    }
} 