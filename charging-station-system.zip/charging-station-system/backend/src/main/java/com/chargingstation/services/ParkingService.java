package com.chargingstation.services;

import com.chargingstation.dto.ParkingRecordDTO;
import com.chargingstation.exceptions.ResourceNotFoundException;
import com.chargingstation.exceptions.ValidationException;
import com.chargingstation.models.ParkingRecord;
import com.chargingstation.models.Vehicle;
import com.chargingstation.repositories.ParkingRecordRepository;
import com.chargingstation.repositories.VehicleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class ParkingService {

    private final ParkingRecordRepository parkingRecordRepository;
    private final VehicleRepository vehicleRepository;

    @Value("${charging-station.parking.free-duration}")
    private long freeDurationSeconds;

    @Value("${charging-station.parking.rate}")
    private BigDecimal hourlyRate;

    @Transactional
    public ParkingRecord startParking(Long vehicleId) {
        // 检查车辆是否存在
        Vehicle vehicle = vehicleRepository.findById(vehicleId)
            .orElseThrow(() -> new ResourceNotFoundException("未找到车辆记录: " + vehicleId));
            
        // 检查是否有未结束的停车记录
        parkingRecordRepository.findActiveRecordByVehicleId(vehicleId)
            .ifPresent(record -> {
                throw new ValidationException("该车辆已有未结束的停车记录");
            });

        // 创建新的停车记录
        ParkingRecord record = new ParkingRecord();
        record.setVehicle(vehicle);
        record.setStartTime(LocalDateTime.now());
        
        return parkingRecordRepository.save(record);
    }

    @Transactional
    public ParkingRecord stopParking(Long vehicleId) {
        // 查找未结束的停车记录
        ParkingRecord record = parkingRecordRepository.findActiveRecordByVehicleId(vehicleId)
            .orElseThrow(() -> new ResourceNotFoundException("未找到该车辆的未结束停车记录"));

        // 记录结束时间
        LocalDateTime endTime = LocalDateTime.now();
        record.setEndTime(endTime);

        // 计算停车费用
        record.setParkingFee(calculateParkingFee(record.getStartTime(), endTime));

        return parkingRecordRepository.save(record);
    }

    @Transactional(readOnly = true)
    public Page<ParkingRecord> getParkingHistory(
            Long vehicleId,
            LocalDateTime startTime,
            LocalDateTime endTime,
            Pageable pageable) {
        return parkingRecordRepository.findByConditions(vehicleId, startTime, endTime, pageable);
    }

    private BigDecimal calculateParkingFee(LocalDateTime startTime, LocalDateTime endTime) {
        Duration duration = Duration.between(startTime, endTime);
        long totalSeconds = duration.getSeconds();

        // 如果在免费时间内，返回0
        if (totalSeconds <= freeDurationSeconds) {
            return BigDecimal.ZERO;
        }

        // 计算超出免费时间的小时数
        double extraHours = (double) (totalSeconds - freeDurationSeconds) / 3600;
        // 向上取整小时数
        long billableHours = (long) Math.ceil(extraHours);

        return hourlyRate.multiply(BigDecimal.valueOf(billableHours))
            .setScale(2, RoundingMode.HALF_UP);
    }

    @Transactional(readOnly = true)
    public BigDecimal calculateDailyIncome(LocalDateTime date) {
        LocalDateTime startOfDay = date.toLocalDate().atStartOfDay();
        LocalDateTime endOfDay = startOfDay.plusDays(1);
        return parkingRecordRepository.calculateDailyIncome(startOfDay, endOfDay);
    }

    @Transactional(readOnly = true)
    public long getCurrentParkingCount() {
        return parkingRecordRepository.countCurrentParking();
    }
} 