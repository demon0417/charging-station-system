package com.chargingstation.device.protocol;

import com.chargingstation.device.exception.ProtocolException;
import com.chargingstation.device.validator.DeviceCommandValidator;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class ModbusAdapter implements ProtocolAdapter {
    
    private final DeviceCommandValidator validator;
    
    // Modbus功能码
    private static final byte READ_COILS = 0x01;
    private static final byte READ_DISCRETE_INPUTS = 0x02;
    private static final byte READ_HOLDING_REGISTERS = 0x03;
    private static final byte READ_INPUT_REGISTERS = 0x04;
    private static final byte WRITE_SINGLE_COIL = 0x05;
    private static final byte WRITE_SINGLE_REGISTER = 0x06;
    private static final byte WRITE_MULTIPLE_COILS = 0x0F;
    private static final byte WRITE_MULTIPLE_REGISTERS = 0x10;

    @Override
    public byte[] convertToProtocol(Command command) throws ProtocolException {
        byte[] modbusCommand = switch (command.type()) {
            case READ_STATUS -> buildReadStatusCommand(command);
            case WRITE_REGISTER -> buildWriteRegisterCommand(command);
            case READ_REGISTER -> buildReadRegisterCommand(command);
            case CONTROL -> buildControlCommand(command);
            case CONFIGURE -> buildConfigureCommand(command);
            default -> throw new ProtocolException("不支持的命令类型: " + command.type());
        };
        
        validator.validateModbusCommand(modbusCommand);
        return modbusCommand;
    }

    @Override
    public Response parseResponse(byte[] data) throws ProtocolException {
        if (!validateResponse(data)) {
            throw new ProtocolException("无效的响应数据");
        }
        
        byte deviceId = data[0];
        byte functionCode = data[1];
        
        // 检查是否是错误响应
        if ((functionCode & 0x80) != 0) {
            return new Response(
                false,
                String.valueOf(deviceId),
                Map.of(),
                getErrorMessage(data[2])
            );
        }
        
        // 解析响应数据
        Map<String, Object> responseData = parseResponseData(functionCode, Arrays.copyOfRange(data, 2, data.length - 2));
        
        return new Response(
            true,
            String.valueOf(deviceId),
            responseData,
            null
        );
    }

    @Override
    public boolean validateResponse(byte[] data) {
        if (data == null || data.length < 4) {
            return false;
        }
        
        // 验证CRC
        byte[] expectedCrc = calculateCRC(Arrays.copyOfRange(data, 0, data.length - 2));
        return data[data.length - 2] == expectedCrc[0] && 
               data[data.length - 1] == expectedCrc[1];
    }

    // ... 其他辅助方法实现 ...
} 