package com.chargingstation.device.monitoring;

import com.chargingstation.device.adapter.DeviceAdapter;
import com.chargingstation.dto.DeviceStatusDTO;
import com.chargingstation.monitoring.AlertService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Service
@RequiredArgsConstructor
public class DeviceMonitorService {

    private final DeviceAdapter deviceAdapter;
    private final AlertService alertService;
    private final Map<String, DeviceStatusDTO> deviceStatusCache = new ConcurrentHashMap<>();
    
    // 设备状态监控阈值
    private static final double VOLTAGE_THRESHOLD_HIGH = 380.0;
    private static final double VOLTAGE_THRESHOLD_LOW = 320.0;
    private static final double CURRENT_THRESHOLD = 32.0;
    private static final double TEMPERATURE_THRESHOLD = 75.0;

    /**
     * 定时轮询设备状态
     */
    @Scheduled(fixedRate = 30000) // 每30秒轮询一次
    public void pollDeviceStatus() {
        List<String> deviceIds = deviceAdapter.getAllDeviceIds();
        
        for (String deviceId : deviceIds) {
            try {
                DeviceStatusDTO status = deviceAdapter.getDeviceStatus(deviceId);
                analyzeDeviceStatus(deviceId, status);
                deviceStatusCache.put(deviceId, status);
            } catch (Exception e) {
                log.error("获取设备{}状态失败", deviceId, e);
                alertService.sendDeviceAlert(deviceId, "设备通信异常", AlertService.AlertLevel.ERROR);
            }
        }
    }

    /**
     * 分析设备状态
     */
    private void analyzeDeviceStatus(String deviceId, DeviceStatusDTO status) {
        // 检查电压
        if (status.getVoltage() > VOLTAGE_THRESHOLD_HIGH) {
            alertService.sendDeviceAlert(deviceId, "设备电压过高", AlertService.AlertLevel.WARNING);
        } else if (status.getVoltage() < VOLTAGE_THRESHOLD_LOW) {
            alertService.sendDeviceAlert(deviceId, "设备电压过低", AlertService.AlertLevel.WARNING);
        }

        // 检查电流
        if (status.getCurrent() > CURRENT_THRESHOLD) {
            alertService.sendDeviceAlert(deviceId, "设备电流过大", AlertService.AlertLevel.WARNING);
        }

        // 检查温度
        if (status.getTemperature() > TEMPERATURE_THRESHOLD) {
            alertService.sendDeviceAlert(deviceId, "设备温度过高", AlertService.AlertLevel.WARNING);
        }

        // 检查通信状态
        if (!status.isOnline()) {
            alertService.sendDeviceAlert(deviceId, "设备离线", AlertService.AlertLevel.ERROR);
        }

        // 检查故障状态
        if (status.getFaultCode() != 0) {
            alertService.sendDeviceAlert(
                deviceId, 
                "设备故障: " + getFaultDescription(status.getFaultCode()),
                AlertService.AlertLevel.ERROR
            );
        }
    }

    /**
     * 获取设备实时状态
     */
    public DeviceStatusDTO getDeviceStatus(String deviceId) {
        return deviceStatusCache.get(deviceId);
    }

    /**
     * 获取所有设备状态
     */
    public Map<String, DeviceStatusDTO> getAllDeviceStatus() {
        return deviceStatusCache;
    }

    /**
     * 获取故障描述
     */
    private String getFaultDescription(int faultCode) {
        return switch (faultCode) {
            case 1 -> "过压保护";
            case 2 -> "欠压保护";
            case 3 -> "过流保护";
            case 4 -> "过温保护";
            case 5 -> "接地故障";
            case 6 -> "通信故障";
            default -> "未知故障";
        };
    }
} 