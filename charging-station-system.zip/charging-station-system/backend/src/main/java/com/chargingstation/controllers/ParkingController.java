package com.chargingstation.controllers;

import com.chargingstation.models.ParkingRecord;
import com.chargingstation.services.ParkingService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@RestController
@RequestMapping("/api/parking")
@RequiredArgsConstructor
public class ParkingController {

    private final ParkingService parkingService;

    @PostMapping("/start")
    public ResponseEntity<ParkingRecord> startParking(@RequestParam Long vehicleId) {
        ParkingRecord record = parkingService.startParking(vehicleId);
        return ResponseEntity.ok(record);
    }

    @PostMapping("/stop")
    public ResponseEntity<ParkingRecord> stopParking(@RequestParam Long vehicleId) {
        ParkingRecord record = parkingService.stopParking(vehicleId);
        return ResponseEntity.ok(record);
    }

    @GetMapping("/history")
    public ResponseEntity<Page<ParkingRecord>> getParkingHistory(
            @RequestParam(required = false) Long vehicleId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startTime,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endTime,
            Pageable pageable) {
        Page<ParkingRecord> records = parkingService.getParkingHistory(vehicleId, startTime, endTime, pageable);
        return ResponseEntity.ok(records);
    }

    @GetMapping("/statistics/daily-income")
    public ResponseEntity<BigDecimal> getDailyIncome(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime date) {
        BigDecimal income = parkingService.calculateDailyIncome(date);
        return ResponseEntity.ok(income);
    }

    @GetMapping("/statistics/current")
    public ResponseEntity<Long> getCurrentParkingCount() {
        long count = parkingService.getCurrentParkingCount();
        return ResponseEntity.ok(count);
    }
} 