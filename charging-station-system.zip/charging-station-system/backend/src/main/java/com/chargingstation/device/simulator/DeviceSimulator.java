package com.chargingstation.device.simulator;

import com.chargingstation.device.protocol.Command;
import com.chargingstation.device.protocol.Response;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Component
public class DeviceSimulator {
    
    private final Map<String, DeviceState> deviceStates = new ConcurrentHashMap<>();
    private final Random random = new Random();
    
    /**
     * 处理设备命令
     */
    public Response handleCommand(Command command) {
        // 模拟通信延迟
        simulateDelay();
        
        // 模拟通信错误
        if (shouldSimulateError()) {
            return new Response(false, command.deviceId(), Map.of(), "模拟的通信错误");
        }
        
        // 获取或创建设备状态
        DeviceState state = deviceStates.computeIfAbsent(
            command.deviceId(),
            id -> new DeviceState(id)
        );
        
        // 处理命令
        return switch (command.type()) {
            case READ_STATUS -> handleReadStatus(state);
            case WRITE_REGISTER -> handleWriteRegister(state, command.parameters());
            case READ_REGISTER -> handleReadRegister(state, command.parameters());
            case CONTROL -> handleControl(state, command.parameters());
            case CONFIGURE -> handleConfigure(state, command.parameters());
        };
    }
    
    /**
     * 模拟设备状态更新
     */
    public void updateDeviceStates() {
        deviceStates.values().forEach(state -> {
            // 模拟电压波动
            state.voltage += (random.nextDouble() - 0.5) * 2;
            if (state.voltage < 220) state.voltage = 220;
            if (state.voltage > 240) state.voltage = 240;
            
            // 模拟电流变化
            if (state.charging) {
                state.current = 16 + (random.nextDouble() - 0.5) * 2;
            } else {
                state.current = 0;
            }
            
            // 模拟温度变化
            state.temperature += (random.nextDouble() - 0.5);
            if (state.temperature < 20) state.temperature = 20;
            if (state.temperature > 60) state.temperature = 60;
            
            // 随机生成故障
            if (random.nextDouble() < 0.001) { // 0.1%概率出现故障
                state.faultCode = random.nextInt(5) + 1;
            }
        });
    }
    
    // ... 其他辅助方法实现 ...
    
    /**
     * 设备状态类
     */
    private static class DeviceState {
        final String deviceId;
        boolean online = true;
        boolean charging = false;
        double voltage = 230.0;
        double current = 0.0;
        double temperature = 25.0;
        int faultCode = 0;
        Map<Integer, Integer> registers = new HashMap<>();
        
        DeviceState(String deviceId) {
            this.deviceId = deviceId;
        }
    }
} 