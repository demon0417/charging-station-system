package com.chargingstation.dto;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class LockStatusDTO {
    private String deviceId;
    private boolean isLocked;
    private boolean isOnline;
    private boolean hasError;
    private byte errorCode;
    private String errorMessage;
    private double voltage;
    private LocalDateTime lastUpdateTime;
} 