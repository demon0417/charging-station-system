package com.chargingstation.service;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.PutObjectRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Slf4j
@Service
@RequiredArgsConstructor
public class DisasterRecoveryService {

    private final BackupService backupService;
    private final AmazonS3 s3Client;
    private final AlertService alertService;

    @Value("${backup.s3.bucket}")
    private String backupBucket;

    @Value("${backup.directory}")
    private String backupDirectory;

    @Scheduled(cron = "0 0 3 * * ?") // 每天凌晨3点执行
    public void performDisasterRecoveryBackup() {
        try {
            // 1. 执行数据库备份
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            String backupFile = String.format("%s/backup_%s.sql", backupDirectory, timestamp);
            backupService.performBackup();

            // 2. 上传到云存储
            File backupFileObj = new File(backupFile);
            String s3Key = "disaster-recovery/" + backupFileObj.getName();
            
            s3Client.putObject(new PutObjectRequest(backupBucket, s3Key, backupFileObj));
            log.info("容灾备份已上传到S3: {}/{}", backupBucket, s3Key);

            // 3. 验证备份
            if (!s3Client.doesObjectExist(backupBucket, s3Key)) {
                throw new RuntimeException("备份文件上传验证失败");
            }

            // 4. 清理本地备份
            if (backupFileObj.delete()) {
                log.info("本地备份文件已清理: {}", backupFile);
            }

        } catch (Exception e) {
            log.error("容灾备份失败", e);
            alertService.sendSystemAlert(
                "容灾备份失败",
                "执行容灾备份时发生错误: " + e.getMessage(),
                AlertService.AlertLevel.CRITICAL
            );
        }
    }

    public void restoreFromDisasterRecovery(String backupKey) {
        try {
            // 1. 从S3下载备份文件
            File localBackup = new File(backupDirectory + "/recovery_" + 
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".sql");
            
            s3Client.getObject(backupBucket, backupKey, localBackup);
            log.info("从S3下载备份文件: {}", localBackup.getAbsolutePath());

            // 2. 执行恢复
            ProcessBuilder processBuilder = new ProcessBuilder(
                "./scripts/restore-database.sh",
                "localhost",
                "3306",
                "charging_station",
                "root",
                "root",
                localBackup.getAbsolutePath()
            );

            Process process = processBuilder.start();
            int exitCode = process.waitFor();

            if (exitCode == 0) {
                log.info("数据恢复成功");
                alertService.sendSystemAlert(
                    "数据恢复成功",
                    "从容灾备份恢复数据成功: " + backupKey,
                    AlertService.AlertLevel.INFO
                );
            } else {
                throw new RuntimeException("数据恢复失败，退出码: " + exitCode);
            }

        } catch (Exception e) {
            log.error("从容灾备份恢复失败", e);
            alertService.sendSystemAlert(
                "数据恢复失败",
                "从容灾备份恢复数据时发生错误: " + e.getMessage(),
                AlertService.AlertLevel.CRITICAL
            );
            throw new RuntimeException("恢复失败", e);
        }
    }
} 