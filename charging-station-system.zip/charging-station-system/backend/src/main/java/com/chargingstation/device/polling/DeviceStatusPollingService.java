package com.chargingstation.device.polling;

import com.chargingstation.device.cache.DeviceStatusCache;
import com.chargingstation.dto.LockStatusDTO;
import com.chargingstation.services.LockControlService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Slf4j
@Service
@RequiredArgsConstructor
public class DeviceStatusPollingService {

    private final LockControlService lockControlService;
    private final DeviceStatusCache statusCache;
    private final DeviceAlertService alertService;

    @Value("${device.polling.thread-pool-size:10}")
    private int threadPoolSize;

    private final ExecutorService executorService = Executors.newFixedThreadPool(10);

    /**
     * 定时轮询设备状态
     */
    @Scheduled(fixedRateString = "${device.polling.interval:30000}")
    public void pollDeviceStatus() {
        try {
            List<String> deviceIds = lockControlService.getAllDeviceIds();
            
            // 并行查询设备状态
            List<CompletableFuture<Void>> futures = deviceIds.stream()
                .map(this::pollSingleDevice)
                .toList();
            
            // 等待所有查询完成
            CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
            
        } catch (Exception e) {
            log.error("设备状态轮询失败", e);
        }
    }

    /**
     * 轮询单个设备状态
     */
    private CompletableFuture<Void> pollSingleDevice(String deviceId) {
        return CompletableFuture.runAsync(() -> {
            try {
                // 获取设备状态
                LockStatusDTO status = lockControlService.getLockStatus(deviceId);
                
                // 更新状态缓存
                statusCache.updateStatus(deviceId, status);
                
                // 检查设备状态并发送告警
                checkDeviceStatus(deviceId, status);
                
            } catch (Exception e) {
                log.error("设备{}状态查询失败", deviceId, e);
                alertService.sendDeviceAlert(deviceId, "设备状态查询失败: " + e.getMessage());
            }
        }, executorService);
    }

    /**
     * 检查设备状态
     */
    private void checkDeviceStatus(String deviceId, LockStatusDTO status) {
        // 检查设备是否在线
        if (!status.isOnline()) {
            alertService.sendDeviceAlert(deviceId, "设备离线");
            return;
        }
        
        // 检查是否有故障
        if (status.hasError()) {
            alertService.sendDeviceAlert(
                deviceId,
                "设备故障: " + status.getErrorMessage()
            );
        }
        
        // 检查电压是否异常
        if (status.getVoltage() < 10.0) {
            alertService.sendDeviceAlert(deviceId, "设备电压过低");
        }
    }
} 