package com.chargingstation.dto.statistics;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDate;

@Data
@Builder
public class DailyStatisticsDTO {
    private LocalDate date;
    private long totalVehicles;
    private BigDecimal chargingIncome;
    private BigDecimal parkingIncome;
    private Duration averageChargingTime;
    private Duration averageParkingTime;
} 