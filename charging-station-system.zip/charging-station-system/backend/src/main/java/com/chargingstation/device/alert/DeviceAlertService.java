package com.chargingstation.device.alert;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Service
@RequiredArgsConstructor
public class DeviceAlertService {

    private final JavaMailSender mailSender;
    private final Map<String, LocalDateTime> lastAlertTime = new ConcurrentHashMap<>();

    @Value("${alert.mail.to}")
    private String[] alertRecipients;

    @Value("${alert.mail.from}")
    private String alertSender;

    @Value("${alert.minimum-interval:300}")  // 默认5分钟
    private long minimumAlertInterval;

    /**
     * 发送设备告警
     */
    public void sendDeviceAlert(String deviceId, String message) {
        // 检查告警频率限制
        if (!shouldSendAlert(deviceId)) {
            log.debug("设备{}告警被限流", deviceId);
            return;
        }

        try {
            // 记录告警时间
            lastAlertTime.put(deviceId, LocalDateTime.now());
            
            // 构建邮件内容
            SimpleMailMessage mail = new SimpleMailMessage();
            mail.setFrom(alertSender);
            mail.setTo(alertRecipients);
            mail.setSubject("设备告警 - " + deviceId);
            mail.setText(buildAlertMessage(deviceId, message));
            
            // 发送邮件
            mailSender.send(mail);
            
            log.info("设备{}告警已发送: {}", deviceId, message);
            
        } catch (Exception e) {
            log.error("设备{}告警发送失败", deviceId, e);
        }
    }

    /**
     * 检查是否应该发送告警
     */
    private boolean shouldSendAlert(String deviceId) {
        LocalDateTime lastAlert = lastAlertTime.get(deviceId);
        if (lastAlert == null) {
            return true;
        }
        
        return LocalDateTime.now().minusSeconds(minimumAlertInterval).isAfter(lastAlert);
    }

    /**
     * 构建告警消息
     */
    private String buildAlertMessage(String deviceId, String message) {
        return String.format("""
            设备告警
            -------------------
            设备ID: %s
            时间: %s
            告警内容: %s
            """,
            deviceId,
            LocalDateTime.now(),
            message
        );
    }
} 