package com.chargingstation.device.protocol;

import com.chargingstation.device.exception.ProtocolException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import eu.chargetime.ocpp.model.*;

@Component
@RequiredArgsConstructor
public class OCPPAdapter implements ProtocolAdapter {

    private final OCPPClient ocppClient;
    
    @Override
    public byte[] convertToProtocol(Command command) throws ProtocolException {
        try {
            Request request = switch (command.type()) {
                case READ_STATUS -> buildStatusRequest(command);
                case WRITE_REGISTER -> buildSetConfigurationRequest(command);
                case READ_REGISTER -> buildGetConfigurationRequest(command);
                case CONTROL -> buildRemoteStartRequest(command);
                case CONFIGURE -> buildChangeConfigurationRequest(command);
                default -> throw new ProtocolException("不支持的命令类型: " + command.type());
            };
            
            return serializeRequest(request);
        } catch (Exception e) {
            throw new ProtocolException("OCPP协议转换失败", e);
        }
    }

    @Override
    public Response parseResponse(byte[] data) throws ProtocolException {
        try {
            OCPPResponse ocppResponse = deserializeResponse(data);
            
            return new Response(
                ocppResponse.isAccepted(),
                ocppResponse.getChargePointId(),
                extractResponseData(ocppResponse),
                ocppResponse.getErrorMessage()
            );
        } catch (Exception e) {
            throw new ProtocolException("OCPP响应解析失败", e);
        }
    }

    // ... 其他辅助方法实现 ...
} 