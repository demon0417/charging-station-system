package com.chargingstation.service;

import com.chargingstation.dto.statistics.*;
import com.chargingstation.repositories.*;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class StatisticsService {

    private final ChargingRecordRepository chargingRecordRepository;
    private final ParkingRecordRepository parkingRecordRepository;
    private final VehicleRepository vehicleRepository;

    @Cacheable(value = "dailyStats", key = "#date")
    @Transactional(readOnly = true)
    public DailyStatisticsDTO getDailyStatistics(LocalDateTime date) {
        LocalDateTime startOfDay = date.toLocalDate().atStartOfDay();
        LocalDateTime endOfDay = startOfDay.plusDays(1);

        return DailyStatisticsDTO.builder()
            .date(date.toLocalDate())
            .totalVehicles(vehicleRepository.countDailyVehicles(startOfDay, endOfDay))
            .chargingIncome(chargingRecordRepository.calculateDailyIncome(startOfDay, endOfDay))
            .parkingIncome(parkingRecordRepository.calculateDailyIncome(startOfDay, endOfDay))
            .averageChargingTime(chargingRecordRepository.calculateAverageChargingTime(startOfDay, endOfDay))
            .averageParkingTime(parkingRecordRepository.calculateAverageParkingTime(startOfDay, endOfDay))
            .build();
    }

    @Transactional(readOnly = true)
    public RealTimeStatisticsDTO getRealTimeStatistics() {
        return RealTimeStatisticsDTO.builder()
            .currentChargingCount(chargingRecordRepository.countCurrentCharging())
            .currentParkingCount(parkingRecordRepository.countCurrentParking())
            .availableSpots(calculateAvailableSpots())
            .totalPowerConsumption(calculateTotalPowerConsumption())
            .build();
    }

    @Transactional(readOnly = true)
    public UserBehaviorDTO getUserBehavior(String plateNumber, LocalDateTime startTime, LocalDateTime endTime) {
        return UserBehaviorDTO.builder()
            .totalVisits(countVisits(plateNumber, startTime, endTime))
            .averageStayTime(calculateAverageStayTime(plateNumber, startTime, endTime))
            .totalSpending(calculateTotalSpending(plateNumber, startTime, endTime))
            .visitTimeDistribution(analyzeVisitTimeDistribution(plateNumber, startTime, endTime))
            .build();
    }

    @Transactional(readOnly = true)
    public List<PeakHourDTO> analyzePeakHours(LocalDateTime date) {
        return chargingRecordRepository.findHourlyUsage(date).stream()
            .map(usage -> PeakHourDTO.builder()
                .hour(usage.getHour())
                .usageCount(usage.getCount())
                .build())
            .collect(Collectors.toList());
    }

    private long calculateAvailableSpots() {
        // 实现计算可用车位逻辑
        return 100 - parkingRecordRepository.countCurrentParking();
    }

    private BigDecimal calculateTotalPowerConsumption() {
        return chargingRecordRepository.calculateTotalPowerConsumption(LocalDateTime.now().toLocalDate());
    }

    private long countVisits(String plateNumber, LocalDateTime startTime, LocalDateTime endTime) {
        return parkingRecordRepository.countVisitsByPlateNumber(plateNumber, startTime, endTime);
    }

    private Duration calculateAverageStayTime(String plateNumber, LocalDateTime startTime, LocalDateTime endTime) {
        return parkingRecordRepository.calculateAverageStayTime(plateNumber, startTime, endTime);
    }

    private BigDecimal calculateTotalSpending(String plateNumber, LocalDateTime startTime, LocalDateTime endTime) {
        BigDecimal parkingFees = parkingRecordRepository.calculateTotalFees(plateNumber, startTime, endTime);
        BigDecimal chargingFees = chargingRecordRepository.calculateTotalFees(plateNumber, startTime, endTime);
        return parkingFees.add(chargingFees);
    }

    private Map<Integer, Long> analyzeVisitTimeDistribution(String plateNumber, LocalDateTime startTime, LocalDateTime endTime) {
        return parkingRecordRepository.findVisitTimeDistribution(plateNumber, startTime, endTime);
    }
} 