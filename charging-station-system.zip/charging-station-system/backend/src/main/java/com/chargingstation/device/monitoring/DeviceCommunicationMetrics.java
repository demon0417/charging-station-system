package com.chargingstation.device.monitoring;

import io.micrometer.core.instrument.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
@RequiredArgsConstructor
public class DeviceCommunicationMetrics {
    
    private final MeterRegistry registry;
    
    // 通信延迟指标
    private final Timer communicationLatency = Timer.builder("device.communication.latency")
        .description("设备通信延迟")
        .register(registry);
    
    // 通信错误计数器
    private final Counter communicationErrors = Counter.builder("device.communication.errors")
        .description("设备通信错误次数")
        .register(registry);
    
    // 通信成功率
    private final Counter communicationTotal = Counter.builder("device.communication.total")
        .description("设备通信总次数")
        .register(registry);
    
    // 设备在线率
    private final Gauge deviceOnlineRate;
    
    // 通信带宽使用
    private final DistributionSummary bandwidthUsage = DistributionSummary.builder("device.communication.bandwidth")
        .description("设备通信带宽使用(bytes)")
        .baseUnit("bytes")
        .register(registry);

    /**
     * 记录通信延迟
     */
    public void recordLatency(long milliseconds) {
        communicationLatency.record(milliseconds, TimeUnit.MILLISECONDS);
    }

    /**
     * 记录通信错误
     */
    public void recordError() {
        communicationErrors.increment();
        communicationTotal.increment();
    }

    /**
     * 记录通信成功
     */
    public void recordSuccess() {
        communicationTotal.increment();
    }

    /**
     * 记录带宽使用
     */
    public void recordBandwidthUsage(long bytes) {
        bandwidthUsage.record(bytes);
    }

    /**
     * 获取通信成功率
     */
    public double getSuccessRate() {
        double total = communicationTotal.count();
        if (total == 0) return 1.0;
        return (total - communicationErrors.count()) / total;
    }

    /**
     * 获取平均延迟
     */
    public double getAverageLatency() {
        return communicationLatency.mean();
    }

    /**
     * 获取95分位延迟
     */
    public double get95thPercentileLatency() {
        return communicationLatency.percentile(0.95);
    }

    /**
     * 获取带宽使用统计
     */
    public BandwidthStats getBandwidthStats() {
        return new BandwidthStats(
            bandwidthUsage.mean(),
            bandwidthUsage.max(),
            bandwidthUsage.totalAmount()
        );
    }

    /**
     * 带宽统计数据
     */
    public record BandwidthStats(
        double averageBytes,
        double maxBytes,
        double totalBytes
    ) {}
} 