package com.chargingstation.device.exception;

public class DeviceCommunicationException extends RuntimeException {
    public DeviceCommunicationException(String message) {
        super(message);
    }

    public DeviceCommunicationException(String message, Throwable cause) {
        super(message, cause);
    }
} 