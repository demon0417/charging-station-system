package com.chargingstation.service;

import com.chargingstation.dto.ChargingStatusDTO;
import com.chargingstation.dto.ParkingStatusDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
@RequiredArgsConstructor
public class RealTimeUpdateService {

    private final SimpMessagingTemplate messagingTemplate;
    private final ChargingService chargingService;
    private final ParkingService parkingService;
    private final Map<String, String> deviceSubscriptions = new ConcurrentHashMap<>();

    public void subscribeToDevice(String sessionId, String deviceId) {
        deviceSubscriptions.put(sessionId, deviceId);
    }

    public void unsubscribeFromDevice(String sessionId) {
        deviceSubscriptions.remove(sessionId);
    }

    @Scheduled(fixedRate = 5000) // 每5秒更新一次
    public void broadcastUpdates() {
        deviceSubscriptions.forEach((sessionId, deviceId) -> {
            try {
                // 发送充电状态更新
                ChargingStatusDTO chargingStatus = chargingService.getChargingStatus(Long.valueOf(deviceId));
                messagingTemplate.convertAndSendToUser(
                    sessionId,
                    "/topic/charging-status",
                    chargingStatus
                );

                // 发送停车状态更新
                ParkingStatusDTO parkingStatus = parkingService.getParkingStatus(Long.valueOf(deviceId));
                messagingTemplate.convertAndSendToUser(
                    sessionId,
                    "/topic/parking-status",
                    parkingStatus
                );
            } catch (Exception e) {
                // 记录错误但不中断其他设备的更新
                log.error("Error updating device status: {}", deviceId, e);
            }
        });
    }

    public void sendAlert(String deviceId, String message) {
        messagingTemplate.convertAndSend(
            "/topic/alerts/" + deviceId,
            Map.of("message", message, "timestamp", System.currentTimeMillis())
        );
    }
} 