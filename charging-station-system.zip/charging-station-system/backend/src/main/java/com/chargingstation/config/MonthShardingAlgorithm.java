package com.chargingstation.config;

import org.apache.shardingsphere.api.sharding.standard.PreciseShardingAlgorithm;
import org.apache.shardingsphere.api.sharding.standard.PreciseShardingValue;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collection;

public class MonthShardingAlgorithm implements PreciseShardingAlgorithm<LocalDateTime> {
    
    @Override
    public String doSharding(Collection<String> availableTargetNames, 
                           PreciseShardingValue<LocalDateTime> shardingValue) {
        LocalDateTime dateTime = shardingValue.getValue();
        int month = dateTime.getMonthValue() - 1; // 0-11
        
        for (String tableName : availableTargetNames) {
            if (tableName.endsWith(String.valueOf(month))) {
                return tableName;
            }
        }
        
        throw new UnsupportedOperationException();
    }
} 