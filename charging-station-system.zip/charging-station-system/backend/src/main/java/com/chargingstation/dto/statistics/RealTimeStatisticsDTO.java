package com.chargingstation.dto.statistics;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

@Data
@Builder
public class RealTimeStatisticsDTO {
    private long currentChargingCount;
    private long currentParkingCount;
    private long availableSpots;
    private BigDecimal totalPowerConsumption;
} 