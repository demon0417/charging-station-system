package com.chargingstation.device.scheduler;

import com.chargingstation.device.command.PriorityCommandQueue;
import com.chargingstation.device.monitor.CommandExecutionMonitor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Slf4j
@Component
@RequiredArgsConstructor
public class CommandScheduler {

    private final PriorityCommandQueue commandQueue;
    private final CommandExecutionMonitor monitor;
    private final ExecutorService executorService = Executors.newFixedThreadPool(10);
    
    // 设备调度状态
    private final Map<String, DeviceScheduleState> deviceStates = new ConcurrentHashMap<>();
    private final Set<String> busyDevices = ConcurrentHashMap.newKeySet();
    
    // 调度配置
    private static final int MAX_CONCURRENT_COMMANDS = 3;  // 每个设备最大并发指令数
    private static final long COMMAND_TIMEOUT = 5000;      // 指令超时时间(毫秒)
    private static final int MAX_RETRY_COUNT = 3;          // 最大重试次数

    /**
     * 定时调度任务
     */
    @Scheduled(fixedRate = 100)  // 每100ms执行一次调度
    public void schedule() {
        deviceStates.forEach((deviceId, state) -> {
            if (!busyDevices.contains(deviceId) && 
                state.getCurrentCommands() < MAX_CONCURRENT_COMMANDS) {
                scheduleNextCommand(deviceId);
            }
        });
    }

    /**
     * 调度下一个指令
     */
    private void scheduleNextCommand(String deviceId) {
        PriorityCommandQueue.PrioritizedCommand command = commandQueue.poll(deviceId);
        if (command == null) return;

        try {
            busyDevices.add(deviceId);
            DeviceScheduleState state = deviceStates.get(deviceId);
            state.incrementCommands();

            executorService.submit(() -> {
                try {
                    executeCommand(deviceId, command);
                } finally {
                    state.decrementCommands();
                    busyDevices.remove(deviceId);
                }
            });

        } catch (Exception e) {
            log.error("指令调度失败: {}", e.getMessage());
            busyDevices.remove(deviceId);
        }
    }

    /**
     * 执行指令
     */
    private void executeCommand(String deviceId, PriorityCommandQueue.PrioritizedCommand command) {
        int retryCount = 0;
        while (retryCount < MAX_RETRY_COUNT) {
            try {
                monitor.recordExecutionStart(deviceId, command.commandId());
                long startTime = System.currentTimeMillis();

                // TODO: 实际的指令执行逻辑

                long duration = System.currentTimeMillis() - startTime;
                monitor.recordExecutionComplete(deviceId, command.commandId(), duration);
                return;

            } catch (Exception e) {
                retryCount++;
                monitor.recordExecutionFailure(deviceId, command.commandId(), e.getMessage());
                if (retryCount < MAX_RETRY_COUNT) {
                    monitor.recordRetry(deviceId, command.commandId(), retryCount);
                    try {
                        Thread.sleep(1000); // 重试前等待1秒
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
            }
        }
    }

    /**
     * 设备调度状态
     */
    private static class DeviceScheduleState {
        private int currentCommands = 0;
        private final Object lock = new Object();

        public void incrementCommands() {
            synchronized (lock) {
                currentCommands++;
            }
        }

        public void decrementCommands() {
            synchronized (lock) {
                currentCommands--;
            }
        }

        public int getCurrentCommands() {
            synchronized (lock) {
                return currentCommands;
            }
        }
    }
} 