package com.chargingstation.controllers;

import com.chargingstation.dto.VehicleDTO;
import com.chargingstation.models.Vehicle;
import com.chargingstation.models.enums.VehicleType;
import com.chargingstation.services.VehicleService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/vehicle")
@RequiredArgsConstructor
public class VehicleController {

    private final VehicleService vehicleService;

    @PostMapping
    public ResponseEntity<Vehicle> createVehicle(@Valid @RequestBody VehicleDTO vehicleDTO) {
        Vehicle vehicle = vehicleService.createVehicle(vehicleDTO);
        return new ResponseEntity<>(vehicle, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Vehicle> getVehicle(@PathVariable Long id) {
        Vehicle vehicle = vehicleService.getVehicle(id);
        return ResponseEntity.ok(vehicle);
    }

    @GetMapping("/plate/{plateNumber}")
    public ResponseEntity<Vehicle> getVehicleByPlateNumber(@PathVariable String plateNumber) {
        Vehicle vehicle = vehicleService.getVehicleByPlateNumber(plateNumber);
        return ResponseEntity.ok(vehicle);
    }

    @GetMapping
    public ResponseEntity<Page<Vehicle>> searchVehicles(
            @RequestParam(required = false) String plateNumber,
            @RequestParam(required = false) VehicleType vehicleType,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startTime,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endTime,
            Pageable pageable) {
        Page<Vehicle> vehicles = vehicleService.searchVehicles(plateNumber, vehicleType, startTime, endTime, pageable);
        return ResponseEntity.ok(vehicles);
    }

    @GetMapping("/current")
    public ResponseEntity<List<Vehicle>> getCurrentParkedVehicles() {
        List<Vehicle> vehicles = vehicleService.getCurrentParkedVehicles();
        return ResponseEntity.ok(vehicles);
    }

    @GetMapping("/statistics/type/{vehicleType}")
    public ResponseEntity<Long> getVehicleCountByType(@PathVariable VehicleType vehicleType) {
        long count = vehicleService.getVehicleCountByType(vehicleType);
        return ResponseEntity.ok(count);
    }

    @GetMapping("/statistics/daily")
    public ResponseEntity<Long> getDailyVehicleCount(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime date) {
        long count = vehicleService.getDailyVehicleCount(date);
        return ResponseEntity.ok(count);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteVehicle(@PathVariable Long id) {
        vehicleService.deleteVehicle(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/batch-exit")
    public ResponseEntity<Integer> batchRecordExit(@RequestBody List<Long> vehicleIds) {
        int updatedCount = vehicleService.batchRecordExit(vehicleIds);
        return ResponseEntity.ok(updatedCount);
    }
} 