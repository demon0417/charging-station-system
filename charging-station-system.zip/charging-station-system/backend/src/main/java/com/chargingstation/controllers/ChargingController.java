package com.chargingstation.controllers;

import com.chargingstation.models.ChargingRecord;
import com.chargingstation.services.ChargingService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@RestController
@RequestMapping("/api/charging")
@RequiredArgsConstructor
public class ChargingController {

    private final ChargingService chargingService;

    @PostMapping("/start")
    public ResponseEntity<ChargingRecord> startCharging(@RequestParam Long vehicleId) {
        ChargingRecord record = chargingService.startCharging(vehicleId);
        return ResponseEntity.ok(record);
    }

    @PostMapping("/stop")
    public ResponseEntity<ChargingRecord> stopCharging(
            @RequestParam Long vehicleId,
            @RequestParam BigDecimal powerConsumption) {
        ChargingRecord record = chargingService.stopCharging(vehicleId, powerConsumption);
        return ResponseEntity.ok(record);
    }

    @GetMapping("/history")
    public ResponseEntity<Page<ChargingRecord>> getChargingHistory(
            @RequestParam(required = false) Long vehicleId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startTime,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endTime,
            Pageable pageable) {
        Page<ChargingRecord> records = chargingService.getChargingHistory(vehicleId, startTime, endTime, pageable);
        return ResponseEntity.ok(records);
    }

    @GetMapping("/statistics/daily-income")
    public ResponseEntity<BigDecimal> getDailyIncome(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime date) {
        BigDecimal income = chargingService.calculateDailyIncome(date);
        return ResponseEntity.ok(income);
    }

    @GetMapping("/statistics/current")
    public ResponseEntity<Long> getCurrentChargingCount() {
        long count = chargingService.getCurrentChargingCount();
        return ResponseEntity.ok(count);
    }

    @GetMapping("/status/{vehicleId}")
    public ResponseEntity<ChargingStatusDTO> getChargingStatus(@PathVariable Long vehicleId) {
        ChargingStatusDTO status = chargingService.getChargingStatus(vehicleId);
        return ResponseEntity.ok(status);
    }
} 