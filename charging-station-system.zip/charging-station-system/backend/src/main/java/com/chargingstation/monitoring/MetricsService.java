package com.chargingstation.monitoring;

import io.micrometer.core.instrument.MeterRegistry;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

@Service
@RequiredArgsConstructor
public class MetricsService {
    
    private final MeterRegistry meterRegistry;

    public void recordApiLatency(String endpoint, long timeInMs) {
        meterRegistry.timer("api.latency", "endpoint", endpoint)
            .record(timeInMs, TimeUnit.MILLISECONDS);
    }

    public void incrementApiError(String endpoint, String errorType) {
        meterRegistry.counter("api.errors", "endpoint", endpoint, "error", errorType)
            .increment();
    }

    public void recordDatabaseQueryTime(String operation, long timeInMs) {
        meterRegistry.timer("db.query.time", "operation", operation)
            .record(timeInMs, TimeUnit.MILLISECONDS);
    }

    public void recordActiveUsers(long count) {
        meterRegistry.gauge("users.active", count);
    }
} 