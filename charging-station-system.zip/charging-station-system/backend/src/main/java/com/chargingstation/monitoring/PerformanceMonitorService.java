package com.chargingstation.monitoring;

import io.micrometer.core.instrument.MeterRegistry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

@Slf4j
@Service
@RequiredArgsConstructor
public class PerformanceMonitorService {

    private final MeterRegistry meterRegistry;
    private final Map<String, PerformanceMetrics> endpointMetrics = new ConcurrentHashMap<>();

    public void recordApiCall(String endpoint, long duration, boolean isError) {
        PerformanceMetrics metrics = endpointMetrics.computeIfAbsent(endpoint, 
            k -> new PerformanceMetrics());
        
        metrics.recordCall(duration);
        if (isError) {
            metrics.recordError();
        }

        // 记录到Prometheus
        meterRegistry.timer("api.latency", "endpoint", endpoint)
            .record(duration, TimeUnit.MILLISECONDS);
        
        if (isError) {
            meterRegistry.counter("api.errors", "endpoint", endpoint).increment();
        }

        // 检查是否需要报警
        checkAlertThresholds(endpoint, metrics);
    }

    @Scheduled(fixedRate = 300000) // 每5分钟执行一次
    public void generatePerformanceReport() {
        log.info("性能报告生成开始...");
        
        endpointMetrics.forEach((endpoint, metrics) -> {
            log.info("端点: {}", endpoint);
            log.info("平均响应时间: {}ms", metrics.getAverageLatency());
            log.info("错误率: {}%", metrics.getErrorRate());
            log.info("95th百分位响应时间: {}ms", metrics.get95thPercentile());
            log.info("总调用次数: {}", metrics.getTotalCalls());
            log.info("------------------------");
        });
    }

    private void checkAlertThresholds(String endpoint, PerformanceMetrics metrics) {
        if (metrics.getAverageLatency() > 1000) { // 1秒
            log.warn("性能警告: 端点 {} 平均响应时间过高: {}ms", endpoint, 
                metrics.getAverageLatency());
        }
        
        if (metrics.getErrorRate() > 5) { // 5%
            log.warn("性能警告: 端点 {} 错误率过高: {}%", endpoint, 
                metrics.getErrorRate());
        }
    }

    private static class PerformanceMetrics {
        private long totalLatency = 0;
        private long totalCalls = 0;
        private long errorCalls = 0;
        private final long[] latencies = new long[1000]; // 滑动窗口
        private int currentIndex = 0;

        synchronized void recordCall(long duration) {
            totalLatency += duration;
            totalCalls++;
            latencies[currentIndex] = duration;
            currentIndex = (currentIndex + 1) % latencies.length;
        }

        synchronized void recordError() {
            errorCalls++;
        }

        double getAverageLatency() {
            return totalCalls == 0 ? 0 : (double) totalLatency / totalCalls;
        }

        double getErrorRate() {
            return totalCalls == 0 ? 0 : (double) errorCalls / totalCalls * 100;
        }

        long get95thPercentile() {
            // 简单实现，实际应使用更高效的算法
            long[] sortedLatencies = latencies.clone();
            Arrays.sort(sortedLatencies);
            return sortedLatencies[(int)(sortedLatencies.length * 0.95)];
        }

        long getTotalCalls() {
            return totalCalls;
        }
    }
} 