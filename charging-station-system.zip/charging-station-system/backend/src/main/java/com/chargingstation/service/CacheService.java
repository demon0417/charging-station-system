package com.chargingstation.service;

import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class CacheService {

    private final RedisTemplate<String, Object> redisTemplate;

    public void cacheDeviceStatus(String deviceId, Object status) {
        String key = "device:status:" + deviceId;
        redisTemplate.opsForValue().set(key, status, Duration.ofMinutes(1));
    }

    public Optional<Object> getDeviceStatus(String deviceId) {
        String key = "device:status:" + deviceId;
        return Optional.ofNullable(redisTemplate.opsForValue().get(key));
    }

    public void cacheRateConfig(String configKey, Object config) {
        String key = "rate:config:" + configKey;
        redisTemplate.opsForValue().set(key, config, Duration.ofHours(24));
    }

    public Optional<Object> getRateConfig(String configKey) {
        String key = "rate:config:" + configKey;
        return Optional.ofNullable(redisTemplate.opsForValue().get(key));
    }

    public void invalidateDeviceStatus(String deviceId) {
        String key = "device:status:" + deviceId;
        redisTemplate.delete(key);
    }

    public void invalidateRateConfig(String configKey) {
        String key = "rate:config:" + configKey;
        redisTemplate.delete(key);
    }
} 