package com.chargingstation.device.diagnostic;

import com.chargingstation.device.adapter.DeviceAdapter;
import com.chargingstation.dto.DiagnosticResultDTO;
import com.chargingstation.dto.FaultLogDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class FaultDiagnosticService {

    private final DeviceAdapter deviceAdapter;
    private final Map<String, List<FaultLogDTO>> faultHistory = new ConcurrentHashMap<>();

    /**
     * 执行故障诊断
     */
    public DiagnosticResultDTO diagnose(String deviceId) {
        try {
            // 获取设备状态数据
            Map<String, Object> deviceData = deviceAdapter.getDiagnosticData(deviceId);
            
            // 执行诊断分析
            List<String> issues = new ArrayList<>();
            Map<String, String> recommendations = new HashMap<>();
            
            // 分析电气参数
            analyzeElectricalParameters(deviceData, issues, recommendations);
            
            // 分析通信状态
            analyzeCommunicationStatus(deviceData, issues, recommendations);
            
            // 分析硬件状态
            analyzeHardwareStatus(deviceData, issues, recommendations);
            
            // 记录故障日志
            if (!issues.isEmpty()) {
                recordFault(deviceId, issues);
            }
            
            return DiagnosticResultDTO.builder()
                .deviceId(deviceId)
                .timestamp(LocalDateTime.now())
                .issues(issues)
                .recommendations(recommendations)
                .rawData(deviceData)
                .build();
            
        } catch (Exception e) {
            log.error("设备诊断失败: {}", deviceId, e);
            throw new DiagnosticException("设备诊断失败: " + e.getMessage());
        }
    }

    /**
     * 分析电气参数
     */
    private void analyzeElectricalParameters(
            Map<String, Object> data,
            List<String> issues,
            Map<String, String> recommendations) {
        
        // 检查电压稳定性
        double voltage = (double) data.get("voltage");
        double voltageDelta = (double) data.get("voltage_delta");
        if (voltageDelta > 10.0) {
            issues.add("电压波动过大");
            recommendations.put("voltage", "检查输入电源质量，考虑安装稳压器");
        }
        
        // 检查功率因数
        double powerFactor = (double) data.get("power_factor");
        if (powerFactor < 0.9) {
            issues.add("功率因数过低");
            recommendations.put("power_factor", "检查无功补偿装置");
        }
        
        // 检查谐波失真
        double thd = (double) data.get("thd");
        if (thd > 5.0) {
            issues.add("谐波含量过高");
            recommendations.put("thd", "建议安装谐波滤波器");
        }
    }

    /**
     * 分析通信状态
     */
    private void analyzeCommunicationStatus(
            Map<String, Object> data,
            List<String> issues,
            Map<String, String> recommendations) {
        
        // 检查通信延迟
        double latency = (double) data.get("communication_latency");
        if (latency > 1000) {
            issues.add("通信延迟过高");
            recommendations.put("communication", "检查网络连接质量");
        }
        
        // 检查数据包丢失率
        double packetLoss = (double) data.get("packet_loss_rate");
        if (packetLoss > 0.01) {
            issues.add("数据包丢失率过高");
            recommendations.put("network", "检查网络干扰源");
        }
    }

    /**
     * 分析硬件状态
     */
    private void analyzeHardwareStatus(
            Map<String, Object> data,
            List<String> issues,
            Map<String, String> recommendations) {
        
        // 检查温度传感器
        List<Double> temperatures = (List<Double>) data.get("temperature_sensors");
        for (int i = 0; i < temperatures.size(); i++) {
            if (temperatures.get(i) > 80.0) {
                issues.add("传感器 " + (i+1) + " 温度过高");
                recommendations.put("temperature_" + i, "检查散热系统");
            }
        }
        
        // 检查继电器状态
        Map<String, Boolean> relayStatus = (Map<String, Boolean>) data.get("relay_status");
        for (Map.Entry<String, Boolean> entry : relayStatus.entrySet()) {
            if (!entry.getValue()) {
                issues.add(entry.getKey() + "继电器异常");
                recommendations.put("relay_" + entry.getKey(), "检查继电器触点");
            }
        }
    }

    /**
     * 记录故障日志
     */
    private void recordFault(String deviceId, List<String> issues) {
        FaultLogDTO faultLog = FaultLogDTO.builder()
            .timestamp(LocalDateTime.now())
            .issues(issues)
            .build();
            
        faultHistory.computeIfAbsent(deviceId, k -> new ArrayList<>())
            .add(faultLog);
    }

    /**
     * 获取故障历史
     */
    public List<FaultLogDTO> getFaultHistory(String deviceId) {
        return faultHistory.getOrDefault(deviceId, Collections.emptyList());
    }

    /**
     * 分析故障趋势
     */
    public Map<String, Integer> analyzeFaultTrend(String deviceId, LocalDateTime startTime) {
        List<FaultLogDTO> history = getFaultHistory(deviceId);
        Map<String, Integer> faultCounts = new HashMap<>();
        
        history.stream()
            .filter(log -> log.getTimestamp().isAfter(startTime))
            .forEach(log -> {
                log.getIssues().forEach(issue -> 
                    faultCounts.merge(issue, 1, Integer::sum)
                );
            });
            
        return faultCounts;
    }
} 