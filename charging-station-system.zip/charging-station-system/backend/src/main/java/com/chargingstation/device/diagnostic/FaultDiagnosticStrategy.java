package com.chargingstation.device.diagnostic;

import com.chargingstation.device.alert.DeviceAlertService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Component
@RequiredArgsConstructor
public class FaultDiagnosticStrategy {

    private final DeviceAlertService alertService;
    private final Map<String, DiagnosticContext> diagnosticContexts = new ConcurrentHashMap<>();
    
    // 故障阈值配置
    private static final int ERROR_THRESHOLD = 3;        // 错误阈值
    private static final int WARNING_THRESHOLD = 5;      // 警告阈值
    private static final long DIAGNOSTIC_WINDOW = 3600;  // 诊断窗口(秒)
    
    /**
     * 诊断设备故障
     */
    public DiagnosticResult diagnose(String deviceId, DeviceStatus status) {
        DiagnosticContext context = getOrCreateContext(deviceId);
        List<FaultPattern> matchedPatterns = new ArrayList<>();
        
        // 检查各种故障模式
        if (checkVoltageAnomaly(status)) {
            matchedPatterns.add(FaultPattern.VOLTAGE_ANOMALY);
        }
        if (checkCurrentAnomaly(status)) {
            matchedPatterns.add(FaultPattern.CURRENT_ANOMALY);
        }
        if (checkTemperatureAnomaly(status)) {
            matchedPatterns.add(FaultPattern.TEMPERATURE_ANOMALY);
        }
        if (checkCommunicationAnomaly(status)) {
            matchedPatterns.add(FaultPattern.COMMUNICATION_ANOMALY);
        }
        
        // 更新诊断上下文
        updateDiagnosticContext(context, matchedPatterns);
        
        // 生成诊断结果
        return generateDiagnosticResult(deviceId, context, matchedPatterns);
    }

    /**
     * 检查电压异常
     */
    private boolean checkVoltageAnomaly(DeviceStatus status) {
        return status.getVoltage() < 10.0 || status.getVoltage() > 240.0;
    }

    /**
     * 检查电流异常
     */
    private boolean checkCurrentAnomaly(DeviceStatus status) {
        return status.getCurrent() > 32.0;
    }

    /**
     * 检查温度异常
     */
    private boolean checkTemperatureAnomaly(DeviceStatus status) {
        return status.getTemperature() > 75.0;
    }

    /**
     * 检查通信异常
     */
    private boolean checkCommunicationAnomaly(DeviceStatus status) {
        return !status.isOnline() || status.getLastUpdateTime().isBefore(
            LocalDateTime.now().minusMinutes(5)
        );
    }

    /**
     * 更新诊断上下文
     */
    private void updateDiagnosticContext(DiagnosticContext context, List<FaultPattern> patterns) {
        context.recordPatterns(patterns);
        
        // 清理过期的故障记录
        context.cleanupOldRecords(DIAGNOSTIC_WINDOW);
        
        // 检查是否需要发送告警
        if (context.getErrorCount() >= ERROR_THRESHOLD) {
            alertService.sendDeviceAlert(
                context.getDeviceId(),
                "设备出现严重故障",
                AlertLevel.ERROR
            );
        } else if (context.getWarningCount() >= WARNING_THRESHOLD) {
            alertService.sendDeviceAlert(
                context.getDeviceId(),
                "设备出现异常警告",
                AlertLevel.WARNING
            );
        }
    }

    /**
     * 生成诊断结果
     */
    private DiagnosticResult generateDiagnosticResult(
            String deviceId,
            DiagnosticContext context,
            List<FaultPattern> patterns) {
        return DiagnosticResult.builder()
            .deviceId(deviceId)
            .timestamp(LocalDateTime.now())
            .faultPatterns(patterns)
            .errorCount(context.getErrorCount())
            .warningCount(context.getWarningCount())
            .severity(calculateSeverity(context))
            .suggestedActions(generateSuggestedActions(patterns))
            .build();
    }

    /**
     * 计算故障严重程度
     */
    private FaultSeverity calculateSeverity(DiagnosticContext context) {
        if (context.getErrorCount() >= ERROR_THRESHOLD) {
            return FaultSeverity.CRITICAL;
        } else if (context.getWarningCount() >= WARNING_THRESHOLD) {
            return FaultSeverity.WARNING;
        } else {
            return FaultSeverity.NORMAL;
        }
    }

    /**
     * 生成建议操作
     */
    private List<String> generateSuggestedActions(List<FaultPattern> patterns) {
        return patterns.stream()
            .map(this::getSuggestedActionForPattern)
            .collect(Collectors.toList());
    }

    private String getSuggestedActionForPattern(FaultPattern pattern) {
        return switch (pattern) {
            case VOLTAGE_ANOMALY -> "检查输入电压";
            case CURRENT_ANOMALY -> "检查充电电流";
            case TEMPERATURE_ANOMALY -> "检查散热系统";
            case COMMUNICATION_ANOMALY -> "检查网络连接";
            default -> "进行设备检查";
        };
    }

    /**
     * 故障模式枚举
     */
    private enum FaultPattern {
        VOLTAGE_ANOMALY,
        CURRENT_ANOMALY,
        TEMPERATURE_ANOMALY,
        COMMUNICATION_ANOMALY
    }

    /**
     * 故障严重程度枚举
     */
    private enum FaultSeverity {
        NORMAL,
        WARNING,
        CRITICAL
    }

    /**
     * 诊断上下文类
     */
    private static class DiagnosticContext {
        private final String deviceId;
        private final List<DiagnosticRecord> records = new ArrayList<>();
        private final Object lock = new Object();

        public DiagnosticContext(String deviceId) {
            this.deviceId = deviceId;
        }

        public void recordPatterns(List<FaultPattern> patterns) {
            synchronized (lock) {
                records.add(new DiagnosticRecord(
                    LocalDateTime.now(),
                    new ArrayList<>(patterns)
                ));
            }
        }

        public void cleanupOldRecords(long windowSeconds) {
            synchronized (lock) {
                LocalDateTime cutoff = LocalDateTime.now().minusSeconds(windowSeconds);
                records.removeIf(record -> record.timestamp.isBefore(cutoff));
            }
        }

        public int getErrorCount() {
            return (int) records.stream()
                .filter(r -> r.patterns.contains(FaultPattern.VOLTAGE_ANOMALY) ||
                           r.patterns.contains(FaultPattern.CURRENT_ANOMALY))
                .count();
        }

        public int getWarningCount() {
            return (int) records.stream()
                .filter(r -> r.patterns.contains(FaultPattern.TEMPERATURE_ANOMALY) ||
                           r.patterns.contains(FaultPattern.COMMUNICATION_ANOMALY))
                .count();
        }

        public String getDeviceId() {
            return deviceId;
        }
    }

    /**
     * 诊断记录类
     */
    private record DiagnosticRecord(
        LocalDateTime timestamp,
        List<FaultPattern> patterns
    ) {}

    /**
     * 诊断结果类
     */
    @Builder
    private record DiagnosticResult(
        String deviceId,
        LocalDateTime timestamp,
        List<FaultPattern> faultPatterns,
        int errorCount,
        int warningCount,
        FaultSeverity severity,
        List<String> suggestedActions
    ) {}
} 