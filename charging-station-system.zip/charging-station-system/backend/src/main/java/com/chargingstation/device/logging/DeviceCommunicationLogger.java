package com.chargingstation.device.logging;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.HexFormat;

@Slf4j
@Component
public class DeviceCommunicationLogger {

    /**
     * 记录发送的指令
     */
    public void logCommand(String deviceId, byte[] command) {
        log.debug("发送指令到设备[{}] - 时间: {}, 指令: {}", 
            deviceId,
            LocalDateTime.now(),
            bytesToHex(command)
        );
    }

    /**
     * 记录接收的响应
     */
    public void logResponse(String deviceId, byte[] response) {
        log.debug("接收设备[{}]响应 - 时间: {}, 响应: {}", 
            deviceId,
            LocalDateTime.now(),
            bytesToHex(response)
        );
    }

    /**
     * 记录通信错误
     */
    public void logError(String deviceId, String message, Throwable error) {
        log.error("设备[{}]通信错误 - 时间: {}, 错误: {}", 
            deviceId,
            LocalDateTime.now(),
            message,
            error
        );
    }

    /**
     * 字节数组转十六进制字符串
     */
    private String bytesToHex(byte[] bytes) {
        return HexFormat.of().formatHex(bytes);
    }
} 