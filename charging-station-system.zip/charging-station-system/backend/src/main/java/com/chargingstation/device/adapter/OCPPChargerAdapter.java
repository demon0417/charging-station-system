package com.chargingstation.device.adapter;

import com.chargingstation.device.model.DeviceCommand;
import com.chargingstation.device.model.DeviceResponse;
import eu.chargetime.ocpp.JSONClient;
import eu.chargetime.ocpp.feature.profile.ClientCoreProfile;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Component
public class OCPPChargerAdapter implements DeviceAdapter {
    
    private final Map<String, JSONClient> clientMap = new ConcurrentHashMap<>();
    private final Map<String, DeviceStatusCallback> callbackMap = new ConcurrentHashMap<>();

    @Override
    public Mono<DeviceResponse> sendCommand(DeviceCommand command) {
        return Mono.fromCallable(() -> {
            JSONClient client = getOrCreateClient(command.getDeviceId());
            
            switch (command.getType()) {
                case START_CHARGING:
                    return handleStartCharging(client, command);
                case STOP_CHARGING:
                    return handleStopCharging(client, command);
                case GET_METER_VALUES:
                    return handleGetMeterValues(client, command);
                default:
                    throw new UnsupportedOperationException("Unsupported command type: " + command.getType());
            }
        });
    }

    @Override
    public Mono<Boolean> isDeviceOnline(String deviceId) {
        return Mono.fromCallable(() -> {
            JSONClient client = clientMap.get(deviceId);
            return client != null && client.isConnected();
        });
    }

    @Override
    public Mono<String> getDeviceStatus(String deviceId) {
        return Mono.fromCallable(() -> {
            JSONClient client = getOrCreateClient(deviceId);
            // 发送 StatusNotification 请求
            return client.send(new StatusNotificationRequest()).thenApply(response -> 
                ((StatusNotificationConfirmation) response).getStatus()
            ).get();
        });
    }

    @Override
    public void registerDeviceStatusCallback(String deviceId, DeviceStatusCallback callback) {
        callbackMap.put(deviceId, callback);
    }

    private JSONClient getOrCreateClient(String deviceId) {
        return clientMap.computeIfAbsent(deviceId, this::createClient);
    }

    private JSONClient createClient(String deviceId) {
        ClientCoreProfile core = new ClientCoreProfile();
        JSONClient client = new JSONClient(core);
        
        // 配置OCPP客户端
        client.connect("ws://charger-endpoint/" + deviceId, null);
        
        // 注册状态变更监听器
        core.addFeatureListener(req -> {
            if (req instanceof StatusNotificationRequest) {
                StatusNotificationRequest notification = (StatusNotificationRequest) req;
                DeviceStatusCallback callback = callbackMap.get(deviceId);
                if (callback != null) {
                    callback.onStatusChange(deviceId, notification.getStatus());
                }
            }
            return null;
        });
        
        return client;
    }

    private DeviceResponse handleStartCharging(JSONClient client, DeviceCommand command) {
        // 实现启动充电逻辑
        RemoteStartTransactionRequest request = new RemoteStartTransactionRequest();
        request.setIdTag(command.getParameters().get("idTag"));
        request.setConnectorId(Integer.parseInt(command.getParameters().get("connectorId")));
        
        return client.send(request).thenApply(response -> 
            new DeviceResponse(response.getStatus() == RemoteStartStopStatus.Accepted)
        ).get();
    }

    private DeviceResponse handleStopCharging(JSONClient client, DeviceCommand command) {
        // 实现停止充电逻辑
        RemoteStopTransactionRequest request = new RemoteStopTransactionRequest();
        request.setTransactionId(Integer.parseInt(command.getParameters().get("transactionId")));
        
        return client.send(request).thenApply(response -> 
            new DeviceResponse(response.getStatus() == RemoteStartStopStatus.Accepted)
        ).get();
    }

    private DeviceResponse handleGetMeterValues(JSONClient client, DeviceCommand command) {
        // 实现获取电表读数逻辑
        GetMeterValuesRequest request = new GetMeterValuesRequest();
        request.setConnectorId(Integer.parseInt(command.getParameters().get("connectorId")));
        
        return client.send(request).thenApply(response -> {
            List<MeterValue> values = response.getMeterValue();
            return new DeviceResponse(true, Map.of("meterValues", values));
        }).get();
    }
} 