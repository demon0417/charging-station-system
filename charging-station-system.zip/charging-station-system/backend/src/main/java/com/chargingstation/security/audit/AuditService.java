package com.chargingstation.security.audit;

import com.chargingstation.monitoring.AlertService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuditService {

    private final AuditLogRepository auditLogRepository;
    private final AlertService alertService;

    public void logOperation(String operation, String resourceType, String resourceId, Map<String, Object> details) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String username = auth != null ? auth.getName() : "anonymous";

        AuditLog auditLog = AuditLog.builder()
            .username(username)
            .operation(operation)
            .resourceType(resourceType)
            .resourceId(resourceId)
            .details(details)
            .timestamp(LocalDateTime.now())
            .ipAddress(getCurrentIpAddress())
            .userAgent(getCurrentUserAgent())
            .build();

        auditLogRepository.save(auditLog);

        // 检查是否需要发送安全告警
        if (isSensitiveOperation(operation)) {
            alertService.sendSystemAlert(
                "敏感操作执行",
                String.format("用户 %s 执行了敏感操作: %s", username, operation),
                AlertService.AlertLevel.WARNING
            );
        }
    }

    private boolean isSensitiveOperation(String operation) {
        return operation.startsWith("DELETE_") ||
               operation.startsWith("UPDATE_CONFIG_") ||
               operation.startsWith("GRANT_PERMISSION_");
    }

    private String getCurrentIpAddress() {
        // 从请求上下文获取IP地址
        return ""; // 实现获取IP地址的逻辑
    }

    private String getCurrentUserAgent() {
        // 从请求上下文获取User-Agent
        return ""; // 实现获取User-Agent的逻辑
    }
} 