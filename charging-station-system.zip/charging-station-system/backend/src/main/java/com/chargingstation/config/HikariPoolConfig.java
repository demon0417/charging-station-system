package com.chargingstation.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Configuration
public class HikariPoolConfig {

    @Bean
    @ConfigurationProperties(prefix = "spring.datasource.hikari")
    public HikariConfig hikariConfig() {
        return new HikariConfig();
    }

    @Bean
    @Primary
    public HikariDataSource dataSource() {
        HikariConfig config = hikariConfig();
        // 设置连接池监控
        config.setMetricRegistry(metricRegistry());
        // 设置健康检查
        config.setHealthCheckRegistry(healthCheckRegistry());
        return new HikariDataSource(config);
    }
} 