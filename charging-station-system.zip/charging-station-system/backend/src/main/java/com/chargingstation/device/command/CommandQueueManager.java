package com.chargingstation.device.command;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

@Slf4j
@Component
public class CommandQueueManager {

    private final Map<String, Queue<DeviceCommand>> commandQueues = new ConcurrentHashMap<>();
    private final Map<String, Object> deviceLocks = new ConcurrentHashMap<>();

    /**
     * 添加指令到队列
     */
    public void enqueueCommand(String deviceId, DeviceCommand command) {
        commandQueues.computeIfAbsent(deviceId, k -> new LinkedBlockingQueue<>())
            .offer(command);
        log.debug("设备{}添加指令到队列: {}", deviceId, command);
    }

    /**
     * 获取下一个待执行的指令
     */
    public DeviceCommand getNextCommand(String deviceId) {
        Queue<DeviceCommand> queue = commandQueues.get(deviceId);
        if (queue == null || queue.isEmpty()) {
            return null;
        }
        return queue.poll();
    }

    /**
     * 获取设备锁
     */
    public boolean acquireLock(String deviceId, long timeout, TimeUnit unit) {
        Object lock = deviceLocks.computeIfAbsent(deviceId, k -> new Object());
        synchronized (lock) {
            try {
                return lock.wait(unit.toMillis(timeout));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return false;
            }
        }
    }

    /**
     * 释放设备锁
     */
    public void releaseLock(String deviceId) {
        Object lock = deviceLocks.get(deviceId);
        if (lock != null) {
            synchronized (lock) {
                lock.notifyAll();
            }
        }
    }

    /**
     * 清空设备指令队列
     */
    public void clearQueue(String deviceId) {
        Queue<DeviceCommand> queue = commandQueues.remove(deviceId);
        if (queue != null) {
            queue.clear();
        }
        log.info("清空设备{}的指令队列", deviceId);
    }

    record DeviceCommand(
        String commandId,
        byte[] data,
        int priority,
        long timeout
    ) {}
} 