package com.chargingstation.monitoring;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
public class SqlExecutionPlanAnalyzer {
    
    private final JdbcTemplate jdbcTemplate;

    public void analyzeQuery(String sql) {
        String explainSql = "EXPLAIN FORMAT=JSON " + sql;
        List<Map<String, Object>> executionPlan = jdbcTemplate.queryForList(explainSql);
        
        log.info("SQL执行计划分析 - SQL: {}", sql);
        executionPlan.forEach(row -> {
            log.info("执行计划详情: {}", row);
            analyzeExecutionPlan(row);
        });
    }

    private void analyzeExecutionPlan(Map<String, Object> plan) {
        // 分析扫描行数
        if (plan.containsKey("rows_examined_per_scan")) {
            long rowsExamined = (Long) plan.get("rows_examined_per_scan");
            if (rowsExamined > 1000) {
                log.warn("全表扫描警告 - 扫描行数: {}", rowsExamined);
            }
        }

        // 分析索引使用情况
        if (plan.containsKey("used_keys")) {
            log.info("使用的索引: {}", plan.get("used_keys"));
        } else {
            log.warn("未使用索引的查询");
        }

        // 分析临时表使用情况
        if (plan.containsKey("using_temporary_table")) {
            log.warn("查询使用了临时表");
        }
    }
} 