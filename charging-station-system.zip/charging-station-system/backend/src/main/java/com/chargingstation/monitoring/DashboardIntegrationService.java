package com.chargingstation.monitoring;

import com.chargingstation.dto.DashboardMetrics;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Slf4j
@Service
@RequiredArgsConstructor
public class DashboardIntegrationService {

    private final MeterRegistry meterRegistry;
    private final RestTemplate restTemplate;
    private final PerformanceMonitorService performanceMonitor;

    @Scheduled(fixedRate = 60000) // 每分钟执行一次
    public void pushMetricsToDashboard() {
        try {
            DashboardMetrics metrics = collectMetrics();
            sendMetricsToDashboard(metrics);
        } catch (Exception e) {
            log.error("推送指标到仪表板失败", e);
        }
    }

    private DashboardMetrics collectMetrics() {
        Map<String, Object> metrics = new HashMap<>();
        
        // 系统指标
        metrics.put("cpu_usage", meterRegistry.gauge("system.cpu.usage", 0.0));
        metrics.put("memory_used", meterRegistry.gauge("system.memory.used", 0L));
        metrics.put("disk_free", meterRegistry.gauge("system.disk.free", 0L));
        
        // 业务指标
        metrics.put("active_users", meterRegistry.gauge("users.active", 0L));
        metrics.put("charging_stations", meterRegistry.gauge("stations.active", 0L));
        metrics.put("parking_spots", meterRegistry.gauge("parking.available", 0L));
        
        // 性能指标
        metrics.put("api_latency_p95", performanceMonitor.get95thPercentileLatency());
        metrics.put("error_rate", performanceMonitor.getErrorRate());
        
        return new DashboardMetrics(metrics);
    }

    private void sendMetricsToDashboard(DashboardMetrics metrics) {
        restTemplate.postForEntity("/api/metrics", metrics, Void.class);
    }

    public void recordCustomMetric(String name, double value, String... tags) {
        meterRegistry.gauge(name, value, tags);
    }

    public void trackLatency(String operation, long duration, TimeUnit unit) {
        meterRegistry.timer(operation + ".latency")
            .record(duration, unit);
    }

    public void incrementCounter(String name, String... tags) {
        meterRegistry.counter(name, tags).increment();
    }
} 