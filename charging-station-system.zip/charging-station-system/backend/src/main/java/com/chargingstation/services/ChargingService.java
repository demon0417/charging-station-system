package com.chargingstation.services;

import com.chargingstation.exceptions.ResourceNotFoundException;
import com.chargingstation.exceptions.ValidationException;
import com.chargingstation.models.ChargingRecord;
import com.chargingstation.models.Vehicle;
import com.chargingstation.repositories.ChargingRecordRepository;
import com.chargingstation.repositories.VehicleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class ChargingService {

    private final ChargingRecordRepository chargingRecordRepository;
    private final VehicleRepository vehicleRepository;

    @Value("${charging-station.charging.rate}")
    private BigDecimal ratePerKWh;

    @Transactional
    public ChargingRecord startCharging(Long vehicleId) {
        // 检查车辆是否存在
        Vehicle vehicle = vehicleRepository.findById(vehicleId)
            .orElseThrow(() -> new ResourceNotFoundException("未找到车辆记录: " + vehicleId));
            
        // 检查是否有未结束的充电记录
        chargingRecordRepository.findActiveRecordByVehicleId(vehicleId)
            .ifPresent(record -> {
                throw new ValidationException("该车辆已有未结束的充电记录");
            });

        // 创建新的充电记录
        ChargingRecord record = new ChargingRecord();
        record.setVehicle(vehicle);
        record.setStartTime(LocalDateTime.now());
        
        return chargingRecordRepository.save(record);
    }

    @Transactional
    public ChargingRecord stopCharging(Long vehicleId, BigDecimal powerConsumption) {
        if (powerConsumption == null || powerConsumption.compareTo(BigDecimal.ZERO) <= 0) {
            throw new ValidationException("充电量必须大于0");
        }

        // 查找未结束的充电记录
        ChargingRecord record = chargingRecordRepository.findActiveRecordByVehicleId(vehicleId)
            .orElseThrow(() -> new ResourceNotFoundException("未找到该车辆的未结束充电记录"));

        // 记录结束时间和充电量
        LocalDateTime endTime = LocalDateTime.now();
        record.setEndTime(endTime);
        record.setPowerConsumption(powerConsumption);

        // 计算充电费用
        record.setChargingFee(calculateChargingFee(powerConsumption));

        return chargingRecordRepository.save(record);
    }

    @Transactional(readOnly = true)
    public Page<ChargingRecord> getChargingHistory(
            Long vehicleId,
            LocalDateTime startTime,
            LocalDateTime endTime,
            Pageable pageable) {
        return chargingRecordRepository.findByConditions(vehicleId, startTime, endTime, pageable);
    }

    @Transactional(readOnly = true)
    public BigDecimal calculateDailyIncome(LocalDateTime date) {
        LocalDateTime startOfDay = date.toLocalDate().atStartOfDay();
        LocalDateTime endOfDay = startOfDay.plusDays(1);
        return chargingRecordRepository.calculateDailyIncome(startOfDay, endOfDay);
    }

    @Transactional(readOnly = true)
    public long getCurrentChargingCount() {
        return chargingRecordRepository.countCurrentCharging();
    }

    @Transactional(readOnly = true)
    public ChargingStatusDTO getChargingStatus(Long vehicleId) {
        ChargingRecord record = chargingRecordRepository.findActiveRecordByVehicleId(vehicleId)
            .orElseThrow(() -> new ResourceNotFoundException("未找到该车辆的充电记录"));
        
        ChargingStatusDTO status = new ChargingStatusDTO();
        status.setVehicleId(vehicleId);
        status.setPlateNumber(record.getVehicle().getPlateNumber());
        status.setStartTime(record.getStartTime());
        
        // 计算充电时长（分钟）
        long durationMinutes = Duration.between(record.getStartTime(), LocalDateTime.now()).toMinutes();
        status.setChargingDuration(durationMinutes);
        
        // 模拟当前功率（实际应该从充电桩获取）
        status.setCurrentPower(BigDecimal.valueOf(7.0));
        
        // 预估费用
        BigDecimal estimatedPower = status.getCurrentPower()
            .multiply(BigDecimal.valueOf(durationMinutes))
            .divide(BigDecimal.valueOf(60), 2, RoundingMode.HALF_UP);
        status.setEstimatedFee(calculateChargingFee(estimatedPower));
        
        return status;
    }

    private BigDecimal calculateChargingFee(BigDecimal powerConsumption) {
        return powerConsumption.multiply(ratePerKWh)
            .setScale(2, RoundingMode.HALF_UP);
    }
} 