package com.chargingstation.device.optimize;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Component
public class CommandOptimizer {

    private final Map<String, DeviceOptimizationContext> deviceContexts = new ConcurrentHashMap<>();
    
    // 优化策略配置
    private static final int BATCH_SIZE = 10;              // 批处理大小
    private static final long BATCH_WINDOW_MS = 100;       // 批处理窗口
    private static final int MAX_CONCURRENT_COMMANDS = 5;  // 最大并发指令数
    private static final long THROTTLE_THRESHOLD_MS = 50;  // 节流阈值

    /**
     * 优化指令执行
     */
    public List<byte[]> optimizeCommands(String deviceId, List<byte[]> commands) {
        DeviceOptimizationContext context = getOrCreateContext(deviceId);
        
        // 合并相似指令
        List<byte[]> mergedCommands = mergeSimilarCommands(commands);
        
        // 应用批处理
        if (mergedCommands.size() > BATCH_SIZE) {
            return batchCommands(mergedCommands);
        }
        
        // 应用节流
        if (needThrottle(context)) {
            return throttleCommands(mergedCommands);
        }
        
        return mergedCommands;
    }

    /**
     * 合并相似指令
     */
    private List<byte[]> mergeSimilarCommands(List<byte[]> commands) {
        Map<CommandType, byte[]> mergedMap = new HashMap<>();
        
        for (byte[] command : commands) {
            CommandType type = getCommandType(command);
            if (canMerge(type)) {
                mergedMap.compute(type, (k, v) -> v == null ? command : mergeCommands(v, command));
            } else {
                mergedMap.put(type, command);
            }
        }
        
        return new ArrayList<>(mergedMap.values());
    }

    /**
     * 批处理指令
     */
    private List<byte[]> batchCommands(List<byte[]> commands) {
        List<byte[]> batches = new ArrayList<>();
        List<byte[]> currentBatch = new ArrayList<>();
        
        for (byte[] command : commands) {
            if (currentBatch.size() >= BATCH_SIZE) {
                batches.add(buildBatchCommand(currentBatch));
                currentBatch.clear();
            }
            currentBatch.add(command);
        }
        
        if (!currentBatch.isEmpty()) {
            batches.add(buildBatchCommand(currentBatch));
        }
        
        return batches;
    }

    /**
     * 节流控制
     */
    private List<byte[]> throttleCommands(List<byte[]> commands) {
        List<byte[]> throttledCommands = new ArrayList<>();
        long lastCommandTime = System.currentTimeMillis();
        
        for (byte[] command : commands) {
            long currentTime = System.currentTimeMillis();
            if (currentTime - lastCommandTime < THROTTLE_THRESHOLD_MS) {
                try {
                    Thread.sleep(THROTTLE_THRESHOLD_MS - (currentTime - lastCommandTime));
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
            throttledCommands.add(command);
            lastCommandTime = System.currentTimeMillis();
        }
        
        return throttledCommands;
    }

    private DeviceOptimizationContext getOrCreateContext(String deviceId) {
        return deviceContexts.computeIfAbsent(deviceId, k -> new DeviceOptimizationContext());
    }

    private boolean needThrottle(DeviceOptimizationContext context) {
        return context.getCurrentLoad() > MAX_CONCURRENT_COMMANDS;
    }

    /**
     * 设备优化上下文
     */
    private static class DeviceOptimizationContext {
        private final Queue<Long> commandTimestamps = new LinkedList<>();
        private int currentLoad = 0;

        public synchronized void recordCommand() {
            commandTimestamps.offer(System.currentTimeMillis());
            currentLoad++;
            cleanupOldCommands();
        }

        public synchronized int getCurrentLoad() {
            cleanupOldCommands();
            return currentLoad;
        }

        private void cleanupOldCommands() {
            long threshold = System.currentTimeMillis() - BATCH_WINDOW_MS;
            while (!commandTimestamps.isEmpty() && commandTimestamps.peek() < threshold) {
                commandTimestamps.poll();
                currentLoad--;
            }
        }
    }

    private enum CommandType {
        READ,
        WRITE,
        CONTROL,
        QUERY
    }
} 