package com.chargingstation.services;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.io.File;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Arrays;

@Slf4j
@Service
public class LogCleanupService {

    @Value("${logging.cleanup.max-age-days:30}")
    private int maxAgeDays;

    @Value("${logging.path:logs}")
    private String logPath;

    @Scheduled(cron = "0 0 1 * * ?") // 每天凌晨1点执行
    public void cleanupOldLogs() {
        File logDir = new File(logPath);
        if (!logDir.exists() || !logDir.isDirectory()) {
            log.warn("日志目录不存在: {}", logPath);
            return;
        }

        LocalDateTime cutoffDate = LocalDateTime.now().minusDays(maxAgeDays);
        File[] logFiles = logDir.listFiles((dir, name) -> name.endsWith(".log"));

        if (logFiles != null) {
            Arrays.stream(logFiles)
                .filter(file -> isFileOlderThan(file, cutoffDate))
                .forEach(file -> {
                    if (file.delete()) {
                        log.info("已删除过期日志文件: {}", file.getName());
                    } else {
                        log.error("删除日志文件失败: {}", file.getName());
                    }
                });
        }
    }

    private boolean isFileOlderThan(File file, LocalDateTime cutoffDate) {
        LocalDateTime fileDateTime = LocalDateTime.ofInstant(
            file.lastModified(), 
            ZoneId.systemDefault()
        );
        return fileDateTime.isBefore(cutoffDate);
    }
} 