package com.chargingstation.device.simulator;

import com.chargingstation.device.model.DeviceCommand;
import com.chargingstation.device.model.DeviceResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Component
public class ChargerSimulator {
    
    private final Map<String, DeviceState> deviceStates = new ConcurrentHashMap<>();
    private final Random random = new Random();

    public Mono<DeviceResponse> processCommand(DeviceCommand command) {
        return Mono.fromCallable(() -> {
            DeviceState state = deviceStates.computeIfAbsent(
                command.getDeviceId(), 
                id -> new DeviceState()
            );
            
            switch (command.getType()) {
                case START_CHARGING:
                    return handleStartCharging(state);
                case STOP_CHARGING:
                    return handleStopCharging(state);
                case GET_METER_VALUES:
                    return handleGetMeterValues(state);
                default:
                    throw new UnsupportedOperationException("Unsupported command");
            }
        });
    }

    private DeviceResponse handleStartCharging(DeviceState state) {
        if (state.isCharging) {
            return new DeviceResponse(false, Map.of("error", "Already charging"));
        }
        
        state.isCharging = true;
        state.startPower = state.currentPower;
        simulateRandomFault(state);
        
        return new DeviceResponse(true);
    }

    private DeviceResponse handleStopCharging(DeviceState state) {
        if (!state.isCharging) {
            return new DeviceResponse(false, Map.of("error", "Not charging"));
        }
        
        state.isCharging = false;
        BigDecimal powerConsumed = state.currentPower.subtract(state.startPower);
        
        return new DeviceResponse(true, Map.of("powerConsumed", powerConsumed));
    }

    private DeviceResponse handleGetMeterValues(DeviceState state) {
        if (state.isCharging) {
            // 模拟充电过程中的电量增加
            state.currentPower = state.currentPower.add(
                BigDecimal.valueOf(random.nextDouble() * 0.1)
            );
        }
        
        return new DeviceResponse(true, Map.of(
            "currentPower", state.currentPower,
            "voltage", 220 + random.nextDouble() * 10,
            "current", 10 + random.nextDouble() * 5
        ));
    }

    private void simulateRandomFault(DeviceState state) {
        if (random.nextDouble() < 0.05) { // 5%的故障率
            state.fault = true;
            log.warn("Simulated fault occurred for device: {}", state);
        }
    }

    @Data
    private static class DeviceState {
        private boolean isCharging = false;
        private boolean fault = false;
        private BigDecimal startPower = BigDecimal.ZERO;
        private BigDecimal currentPower = BigDecimal.ZERO;
    }
} 