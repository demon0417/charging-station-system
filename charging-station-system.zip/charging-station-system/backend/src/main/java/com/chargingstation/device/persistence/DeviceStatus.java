package com.chargingstation.device.persistence;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Entity
@Table(name = "device_states")
@Data
public class DeviceState {
    
    @Id
    private String deviceId;
    
    @Enumerated(EnumType.STRING)
    private DeviceStatus status;
    
    private boolean online;
    private double voltage;
    private double current;
    private double temperature;
    private int faultCode;
    
    @Column(name = "last_update_time")
    private LocalDateTime lastUpdateTime;
    
    @Version
    private Long version;
    
    @Column(columnDefinition = "jsonb")
    private String extendedState;  // 存储JSON格式的扩展状态
}

public enum DeviceStatus {
    IDLE,
    CHARGING,
    FAULT,
    MAINTENANCE,
    OFFLINE
} 