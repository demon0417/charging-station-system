package com.chargingstation.services;

import com.chargingstation.dto.VehicleDTO;
import com.chargingstation.exceptions.ResourceNotFoundException;
import com.chargingstation.exceptions.DuplicateResourceException;
import com.chargingstation.exceptions.ValidationException;
import com.chargingstation.models.Vehicle;
import com.chargingstation.models.enums.VehicleType;
import com.chargingstation.repositories.VehicleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.CacheEvict;

import java.util.regex.Pattern;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class VehicleService {
    
    private final VehicleRepository vehicleRepository;
    
    // 中国车牌号正则表达式
    private static final Pattern PLATE_NUMBER_PATTERN = Pattern.compile(
        "^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领][A-Z][A-Z0-9]{4,5}[A-Z0-9挂学警港澳]$"
    );
    
    @CacheEvict(value = "vehicleCache", allEntries = true)
    @Transactional
    public Vehicle createVehicle(VehicleDTO vehicleDTO) {
        // 验证车牌号格式
        validatePlateNumber(vehicleDTO.getPlateNumber());
        
        // 检查车牌号是否已存在
        if (vehicleRepository.existsByPlateNumber(vehicleDTO.getPlateNumber())) {
            throw new DuplicateResourceException("车牌号已存在: " + vehicleDTO.getPlateNumber());
        }
        
        // 创建新车辆记录
        Vehicle vehicle = new Vehicle();
        vehicle.setPlateNumber(vehicleDTO.getPlateNumber());
        vehicle.setVehicleType(vehicleDTO.getVehicleType());
        vehicle.setEntryTime(vehicleDTO.getEntryTime());
        
        return vehicleRepository.save(vehicle);
    }
    
    @Cacheable(value = "vehicleCache", key = "#id")
    @Transactional(readOnly = true)
    public Vehicle getVehicle(Long id) {
        return vehicleRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("未找到车辆记录: " + id));
    }
    
    @Cacheable(value = "vehicleCache", key = "#plateNumber")
    @Transactional(readOnly = true)
    public Vehicle getVehicleByPlateNumber(String plateNumber) {
        return vehicleRepository.findByPlateNumber(plateNumber)
            .orElseThrow(() -> new ResourceNotFoundException("未找到车牌号为 " + plateNumber + " 的车辆"));
    }
    
    @Transactional(readOnly = true)
    public Page<Vehicle> getAllVehicles(Pageable pageable) {
        return vehicleRepository.findAll(pageable);
    }
    
    @Transactional(readOnly = true)
    public Page<Vehicle> getVehiclesByType(VehicleType vehicleType, Pageable pageable) {
        return vehicleRepository.findByVehicleType(vehicleType, pageable);
    }
    
    @Transactional
    public void deleteVehicle(Long id) {
        Vehicle vehicle = getVehicle(id);
        vehicleRepository.delete(vehicle);
    }
    
    private void validatePlateNumber(String plateNumber) {
        if (plateNumber == null || plateNumber.trim().isEmpty()) {
            throw new ValidationException("车牌号不能为空");
        }
        
        if (!PLATE_NUMBER_PATTERN.matcher(plateNumber).matches()) {
            throw new ValidationException("车牌号格式不正确: " + plateNumber);
        }
    }
    
    @Transactional(readOnly = true)
    public List<Vehicle> getCurrentParkedVehicles() {
        return vehicleRepository.findCurrentParkedVehicles(LocalDateTime.now());
    }
    
    @Cacheable(value = "statisticsCache", key = "'countByType:' + #vehicleType")
    @Transactional(readOnly = true)
    public long getVehicleCountByType(VehicleType vehicleType) {
        return vehicleRepository.countByVehicleType(vehicleType);
    }
    
    @Transactional(readOnly = true)
    public long getDailyVehicleCount(LocalDateTime date) {
        LocalDateTime startOfDay = date.toLocalDate().atStartOfDay();
        LocalDateTime endOfDay = startOfDay.plusDays(1);
        return vehicleRepository.countDailyVehicles(startOfDay, endOfDay);
    }
    
    @Transactional(readOnly = true)
    public Page<Vehicle> searchVehicles(
            String plateNumber,
            VehicleType vehicleType,
            LocalDateTime startTime,
            LocalDateTime endTime,
            Pageable pageable) {
        return vehicleRepository.findByConditions(plateNumber, vehicleType, startTime, endTime, pageable);
    }
    
    @Transactional
    public int batchRecordExit(List<Long> vehicleIds) {
        return vehicleRepository.batchUpdateExitTime(vehicleIds, LocalDateTime.now());
    }
} 