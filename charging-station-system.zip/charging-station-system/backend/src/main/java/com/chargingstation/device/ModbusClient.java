package com.chargingstation.device;

import com.chargingstation.exceptions.DeviceControlException;
import jssc.SerialPort;
import jssc.SerialPortException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.util.concurrent.TimeoutException;

@Slf4j
@Component
public class ModbusClient {

    @Value("${modbus.serial.port}")
    private String portName;

    @Value("${modbus.serial.baudrate:9600}")
    private int baudRate;

    private SerialPort serialPort;

    @PostConstruct
    public void init() throws SerialPortException {
        serialPort = new SerialPort(portName);
        serialPort.openPort();
        serialPort.setParams(
            baudRate,
            SerialPort.DATABITS_8,
            SerialPort.STOPBITS_1,
            SerialPort.PARITY_NONE
        );
    }

    @PreDestroy
    public void destroy() {
        try {
            if (serialPort != null && serialPort.isOpened()) {
                serialPort.closePort();
            }
        } catch (SerialPortException e) {
            log.error("关闭串口失败", e);
        }
    }

    /**
     * 发送指令并等待响应
     */
    public synchronized byte[] sendCommand(byte[] command, int timeout) 
            throws DeviceControlException, TimeoutException {
        try {
            // 清空接收缓冲区
            serialPort.purgePort(SerialPort.PURGE_RXCLEAR);
            
            // 发送指令
            serialPort.writeBytes(command);
            
            // 等待响应
            long startTime = System.currentTimeMillis();
            while (System.currentTimeMillis() - startTime < timeout) {
                if (serialPort.getInputBufferBytesCount() > 0) {
                    // 读取响应
                    return serialPort.readBytes();
                }
                Thread.sleep(10);
            }
            
            throw new TimeoutException("等待设备响应超时");
            
        } catch (SerialPortException | InterruptedException e) {
            throw new DeviceControlException("设备通信异常: " + e.getMessage());
        }
    }

    /**
     * 计算CRC校验值
     */
    public static byte[] calculateCRC(byte[] data) {
        int crc = 0xFFFF;
        for (byte b : data) {
            crc ^= (b & 0xFF);
            for (int i = 0; i < 8; i++) {
                if ((crc & 0x0001) != 0) {
                    crc = (crc >> 1) ^ 0xA001;
                } else {
                    crc = crc >> 1;
                }
            }
        }
        return new byte[]{(byte) (crc & 0xFF), (byte) ((crc >> 8) & 0xFF)};
    }
} 