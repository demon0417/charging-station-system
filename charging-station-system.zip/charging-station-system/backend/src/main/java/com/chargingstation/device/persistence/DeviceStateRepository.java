package com.chargingstation.device.persistence;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DeviceStateRepository extends JpaRepository<DeviceState, String> {
    List<DeviceState> findByLastUpdateTimeBefore(LocalDateTime time);
    List<DeviceState> findByStatus(DeviceStatus status);
    @Query("SELECT d FROM DeviceState d WHERE d.voltage < :threshold")
    List<DeviceState> findLowVoltageDevices(@Param("threshold") double threshold);
} 