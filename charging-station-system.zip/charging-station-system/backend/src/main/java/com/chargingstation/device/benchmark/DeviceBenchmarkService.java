package com.chargingstation.device.benchmark;

import com.chargingstation.device.monitor.CommandExecutionMonitor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class DeviceBenchmarkService {

    private final CommandExecutionMonitor monitor;
    private final ExecutorService executorService = Executors.newFixedThreadPool(10);
    
    /**
     * 执行性能基准测试
     */
    public BenchmarkResult runBenchmark(BenchmarkConfig config) {
        log.info("开始执行性能基准测试: {}", config);
        
        LocalDateTime startTime = LocalDateTime.now();
        List<BenchmarkMetric> metrics = new ArrayList<>();
        
        try {
            // 准备测试数据
            List<byte[]> testCommands = generateTestCommands(config);
            
            // 执行测试
            CompletableFuture<Void> testFuture = executeTest(
                config,
                testCommands,
                metrics
            );
            
            // 等待测试完成
            testFuture.get(config.getTimeout(), TimeUnit.SECONDS);
            
            // 生成测试报告
            return generateReport(config, startTime, metrics);
            
        } catch (Exception e) {
            log.error("性能基准测试失败", e);
            throw new BenchmarkException("性能测试执行失败", e);
        }
    }

    /**
     * 生成测试指令
     */
    private List<byte[]> generateTestCommands(BenchmarkConfig config) {
        List<byte[]> commands = new ArrayList<>();
        
        for (int i = 0; i < config.getCommandCount(); i++) {
            commands.add(switch (config.getCommandType()) {
                case READ -> generateReadCommand();
                case WRITE -> generateWriteCommand();
                case CONTROL -> generateControlCommand();
            });
        }
        
        return commands;
    }

    /**
     * 执行测试
     */
    private CompletableFuture<Void> executeTest(
            BenchmarkConfig config,
            List<byte[]> commands,
            List<BenchmarkMetric> metrics) {
        
        List<CompletableFuture<Void>> futures = new ArrayList<>();
        
        // 创建测试任务
        for (int i = 0; i < config.getConcurrentUsers(); i++) {
            futures.add(CompletableFuture.runAsync(() -> {
                for (byte[] command : commands) {
                    executeCommand(command, metrics);
                    
                    // 模拟用户思考时间
                    if (config.getThinkTime() > 0) {
                        try {
                            Thread.sleep(config.getThinkTime());
                        } catch (InterruptedException e) {
                            Thread.currentThread().interrupt();
                            break;
                        }
                    }
                }
            }, executorService));
        }
        
        return CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]));
    }

    /**
     * 执行单个指令
     */
    private void executeCommand(byte[] command, List<BenchmarkMetric> metrics) {
        LocalDateTime startTime = LocalDateTime.now();
        
        try {
            // TODO: 实际的指令执行逻辑
            Thread.sleep(ThreadLocalRandom.current().nextLong(50, 200));
            
            // 记录执行指标
            metrics.add(new BenchmarkMetric(
                startTime,
                Duration.between(startTime, LocalDateTime.now()),
                true,
                null
            ));
            
        } catch (Exception e) {
            metrics.add(new BenchmarkMetric(
                startTime,
                Duration.between(startTime, LocalDateTime.now()),
                false,
                e.getMessage()
            ));
        }
    }

    /**
     * 生成测试报告
     */
    private BenchmarkResult generateReport(
            BenchmarkConfig config,
            LocalDateTime startTime,
            List<BenchmarkMetric> metrics) {
        
        Duration totalDuration = Duration.between(startTime, LocalDateTime.now());
        long successCount = metrics.stream().filter(BenchmarkMetric::success).count();
        long failureCount = metrics.size() - successCount;
        
        double avgResponseTime = metrics.stream()
            .mapToLong(m -> m.duration().toMillis())
            .average()
            .orElse(0.0);
        
        double throughput = metrics.size() / (totalDuration.toMillis() / 1000.0);
        
        return BenchmarkResult.builder()
            .startTime(startTime)
            .duration(totalDuration)
            .totalRequests(metrics.size())
            .successCount(successCount)
            .failureCount(failureCount)
            .averageResponseTime(avgResponseTime)
            .throughput(throughput)
            .config(config)
            .build();
    }

    /**
     * 基准测试配置
     */
    @Builder
    public record BenchmarkConfig(
        int concurrentUsers,
        int commandCount,
        CommandType commandType,
        long thinkTime,
        long timeout
    ) {}

    /**
     * 指令类型枚举
     */
    public enum CommandType {
        READ,
        WRITE,
        CONTROL
    }

    /**
     * 性能指标记录
     */
    private record BenchmarkMetric(
        LocalDateTime timestamp,
        Duration duration,
        boolean success,
        String errorMessage
    ) {}

    /**
     * 测试结果
     */
    @Builder
    public record BenchmarkResult(
        LocalDateTime startTime,
        Duration duration,
        int totalRequests,
        long successCount,
        long failureCount,
        double averageResponseTime,
        double throughput,
        BenchmarkConfig config
    ) {}
} 