package com.chargingstation.security.ids;

import com.chargingstation.monitoring.AlertService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

@Slf4j
@Service
@RequiredArgsConstructor
public class IntrusionDetectionService {

    private final AlertService alertService;
    private final Map<String, Integer> failedLoginAttempts = new ConcurrentHashMap<>();
    private final Map<String, LocalDateTime> ipBlockList = new ConcurrentHashMap<>();

    // SQL注入检测模式
    private static final Pattern SQL_INJECTION_PATTERN = Pattern.compile(
        "(?i)(\\b(select|insert|update|delete|drop|union|exec)\\b)"
    );

    // XSS检测模式
    private static final Pattern XSS_PATTERN = Pattern.compile(
        "(?i)(<script|javascript:|vbscript:|onload=)"
    );

    public boolean detectSqlInjection(String input) {
        if (SQL_INJECTION_PATTERN.matcher(input).find()) {
            reportSecurityThreat("SQL注入尝试", input);
            return true;
        }
        return false;
    }

    public boolean detectXSS(String input) {
        if (XSS_PATTERN.matcher(input).find()) {
            reportSecurityThreat("XSS攻击尝试", input);
            return true;
        }
        return false;
    }

    public void recordFailedLogin(String ip) {
        if (isIpBlocked(ip)) {
            return;
        }

        int attempts = failedLoginAttempts.compute(ip, (k, v) -> v == null ? 1 : v + 1);
        if (attempts >= 5) {
            blockIp(ip);
        }
    }

    private void blockIp(String ip) {
        ipBlockList.put(ip, LocalDateTime.now().plusMinutes(30));
        alertService.sendSystemAlert(
            "IP已被封禁",
            String.format("IP %s 因多次失败登录尝试已被封禁30分钟", ip),
            AlertService.AlertLevel.WARNING
        );
    }

    public boolean isIpBlocked(String ip) {
        LocalDateTime blockUntil = ipBlockList.get(ip);
        return blockUntil != null && blockUntil.isAfter(LocalDateTime.now());
    }

    private void reportSecurityThreat(String threatType, String details) {
        log.warn("检测到安全威胁 - 类型: {}, 详情: {}", threatType, details);
        alertService.sendSystemAlert(
            "检测到安全威胁",
            String.format("类型: %s, 详情: %s", threatType, details),
            AlertService.AlertLevel.ERROR
        );
    }

    @Scheduled(fixedRate = 3600000) // 每小时清理一次
    public void cleanupBlockList() {
        LocalDateTime now = LocalDateTime.now();
        ipBlockList.entrySet().removeIf(entry -> entry.getValue().isBefore(now));
        failedLoginAttempts.clear();
    }
} 