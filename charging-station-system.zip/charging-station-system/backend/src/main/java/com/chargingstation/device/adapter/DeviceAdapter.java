package com.chargingstation.device.adapter;

import com.chargingstation.device.model.DeviceCommand;
import com.chargingstation.device.model.DeviceResponse;
import reactor.core.publisher.Mono;

public interface DeviceAdapter {
    Mono<DeviceResponse> sendCommand(DeviceCommand command);
    Mono<Boolean> isDeviceOnline(String deviceId);
    Mono<String> getDeviceStatus(String deviceId);
    void registerDeviceStatusCallback(String deviceId, DeviceStatusCallback callback);
}

@FunctionalInterface
interface DeviceStatusCallback {
    void onStatusChange(String deviceId, String status);
} 