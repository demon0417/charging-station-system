package com.chargingstation.config;

import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {

    public static final String CHARGING_EVENTS_QUEUE = "charging.events";
    public static final String PARKING_EVENTS_QUEUE = "parking.events";
    public static final String DEVICE_EVENTS_QUEUE = "device.events";
    public static final String EVENTS_EXCHANGE = "charging.station.events";

    @Bean
    public Queue chargingEventsQueue() {
        return QueueBuilder.durable(CHARGING_EVENTS_QUEUE)
            .withArgument("x-dead-letter-exchange", "charging.station.dlx")
            .withArgument("x-dead-letter-routing-key", "charging.events.dlq")
            .build();
    }

    @Bean
    public Queue parkingEventsQueue() {
        return QueueBuilder.durable(PARKING_EVENTS_QUEUE)
            .withArgument("x-dead-letter-exchange", "charging.station.dlx")
            .withArgument("x-dead-letter-routing-key", "parking.events.dlq")
            .build();
    }

    @Bean
    public Queue deviceEventsQueue() {
        return QueueBuilder.durable(DEVICE_EVENTS_QUEUE)
            .withArgument("x-dead-letter-exchange", "charging.station.dlx")
            .withArgument("x-dead-letter-routing-key", "device.events.dlq")
            .build();
    }

    @Bean
    public TopicExchange eventsExchange() {
        return new TopicExchange(EVENTS_EXCHANGE);
    }

    @Bean
    public Binding chargingEventsBinding(Queue chargingEventsQueue, TopicExchange eventsExchange) {
        return BindingBuilder.bind(chargingEventsQueue)
            .to(eventsExchange)
            .with("charging.#");
    }

    @Bean
    public Binding parkingEventsBinding(Queue parkingEventsQueue, TopicExchange eventsExchange) {
        return BindingBuilder.bind(parkingEventsQueue)
            .to(eventsExchange)
            .with("parking.#");
    }

    @Bean
    public Binding deviceEventsBinding(Queue deviceEventsQueue, TopicExchange eventsExchange) {
        return BindingBuilder.bind(deviceEventsQueue)
            .to(eventsExchange)
            .with("device.#");
    }

    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory) {
        RabbitTemplate template = new RabbitTemplate(connectionFactory);
        template.setMessageConverter(new Jackson2JsonMessageConverter());
        return template;
    }
} 