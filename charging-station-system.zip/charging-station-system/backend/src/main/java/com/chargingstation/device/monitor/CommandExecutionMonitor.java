package com.chargingstation.device.monitor;

import io.micrometer.core.instrument.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

@Slf4j
@Component
@RequiredArgsConstructor
public class CommandExecutionMonitor {

    private final MeterRegistry registry;
    private final Map<String, CommandExecutionStats> deviceStats = new ConcurrentHashMap<>();

    // 监控指标
    private final Timer executionTimer;
    private final Counter failureCounter;
    private final Counter timeoutCounter;
    private final Counter retryCounter;
    private final Gauge queueSizeGauge;
    private final DistributionSummary commandSizeHistogram;

    /**
     * 记录指令执行开始
     */
    public void recordExecutionStart(String deviceId, String commandId) {
        getOrCreateStats(deviceId).startExecution(commandId);
        log.debug("设备{}开始执行指令{}", deviceId, commandId);
    }

    /**
     * 记录指令执行完成
     */
    public void recordExecutionComplete(String deviceId, String commandId, long durationMs) {
        CommandExecutionStats stats = getOrCreateStats(deviceId);
        stats.completeExecution(commandId);
        
        // 记录执行时间
        executionTimer.record(Duration.ofMillis(durationMs));
        
        log.debug("设备{}完成指令{}, 耗时{}ms", deviceId, commandId, durationMs);
    }

    /**
     * 记录指令执行失败
     */
    public void recordExecutionFailure(String deviceId, String commandId, String reason) {
        CommandExecutionStats stats = getOrCreateStats(deviceId);
        stats.recordFailure();
        
        // 增加失败计数
        failureCounter.increment();
        
        log.warn("设备{}执行指令{}失败: {}", deviceId, commandId, reason);
    }

    /**
     * 记录指令超时
     */
    public void recordTimeout(String deviceId, String commandId) {
        CommandExecutionStats stats = getOrCreateStats(deviceId);
        stats.recordTimeout();
        
        // 增加超时计数
        timeoutCounter.increment();
        
        log.warn("设备{}指令{}执行超时", deviceId, commandId);
    }

    /**
     * 记录指令重试
     */
    public void recordRetry(String deviceId, String commandId, int attemptCount) {
        CommandExecutionStats stats = getOrCreateStats(deviceId);
        stats.recordRetry();
        
        // 增加重试计数
        retryCounter.increment();
        
        log.info("设备{}指令{}第{}次重试", deviceId, commandId, attemptCount);
    }

    /**
     * 获取设备执行统计
     */
    public CommandExecutionStats getStats(String deviceId) {
        return deviceStats.get(deviceId);
    }

    private CommandExecutionStats getOrCreateStats(String deviceId) {
        return deviceStats.computeIfAbsent(deviceId, k -> new CommandExecutionStats());
    }

    /**
     * 设备执行统计
     */
    public static class CommandExecutionStats {
        private final AtomicLong totalCommands = new AtomicLong();
        private final AtomicLong failedCommands = new AtomicLong();
        private final AtomicLong timeoutCommands = new AtomicLong();
        private final AtomicLong retryCount = new AtomicLong();
        private final Map<String, Long> executingCommands = new ConcurrentHashMap<>();

        public void startExecution(String commandId) {
            totalCommands.incrementAndGet();
            executingCommands.put(commandId, System.currentTimeMillis());
        }

        public void completeExecution(String commandId) {
            executingCommands.remove(commandId);
        }

        public void recordFailure() {
            failedCommands.incrementAndGet();
        }

        public void recordTimeout() {
            timeoutCommands.incrementAndGet();
        }

        public void recordRetry() {
            retryCount.incrementAndGet();
        }

        public long getTotalCommands() {
            return totalCommands.get();
        }

        public long getFailedCommands() {
            return failedCommands.get();
        }

        public long getTimeoutCommands() {
            return timeoutCommands.get();
        }

        public long getRetryCount() {
            return retryCount.get();
        }

        public int getCurrentExecutingCount() {
            return executingCommands.size();
        }

        public double getSuccessRate() {
            long total = totalCommands.get();
            if (total == 0) return 1.0;
            return (double) (total - failedCommands.get()) / total;
        }
    }
} 