package com.chargingstation.device.validator;

import com.chargingstation.device.exception.InvalidCommandException;
import org.springframework.stereotype.Component;

@Component
public class DeviceCommandValidator {

    /**
     * 验证Modbus指令格式
     */
    public void validateModbusCommand(byte[] command) {
        // 检查基本长度
        if (command == null || command.length < 4) {
            throw new InvalidCommandException("指令长度不足");
        }

        // 检查设备地址
        if (command[0] == 0x00) {
            throw new InvalidCommandException("无效的设备地址");
        }

        // 检查功能码
        byte functionCode = command[1];
        if (!isValidFunctionCode(functionCode)) {
            throw new InvalidCommandException("无效的功能码: " + functionCode);
        }

        // 检查数据长度
        int dataLength = command.length - 4; // 减去地址、功能码和CRC
        if (dataLength < 0) {
            throw new InvalidCommandException("数据长度错误");
        }

        // 检查CRC
        byte[] expectedCrc = calculateCRC(command);
        if (command[command.length - 2] != expectedCrc[0] || 
            command[command.length - 1] != expectedCrc[1]) {
            throw new InvalidCommandException("CRC校验失败");
        }
    }

    /**
     * 检查功能码是否有效
     */
    private boolean isValidFunctionCode(byte code) {
        return switch (code) {
            case 0x01, // 读线圈
                 0x02, // 读离散输入
                 0x03, // 读保持寄存器
                 0x04, // 读输入寄存器
                 0x05, // 写单个线圈
                 0x06, // 写单个寄存器
                 0x0F, // 写多个线圈
                 0x10  // 写多个寄存器
                 -> true;
            default -> false;
        };
    }

    /**
     * 计算CRC校验值
     */
    private byte[] calculateCRC(byte[] data) {
        int crc = 0xFFFF;
        for (int i = 0; i < data.length - 2; i++) {
            crc ^= (data[i] & 0xFF);
            for (int j = 0; j < 8; j++) {
                if ((crc & 0x0001) != 0) {
                    crc = (crc >> 1) ^ 0xA001;
                } else {
                    crc = crc >> 1;
                }
            }
        }
        return new byte[]{(byte) (crc & 0xFF), (byte) ((crc >> 8) & 0xFF)};
    }
} 