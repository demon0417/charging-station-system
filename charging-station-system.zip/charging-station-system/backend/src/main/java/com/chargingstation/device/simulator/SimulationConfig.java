package com.chargingstation.device.simulator;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;
import java.util.Map;

@Configuration
@ConfigurationProperties(prefix = "simulation")
@Data
public class SimulationConfig {
    
    private List<DeviceProfile> devices;
    private Map<String, ScenarioConfig> scenarios;
    private FaultSimulation faults;
    private NetworkSimulation network;
    
    @Data
    public static class DeviceProfile {
        private String deviceId;
        private String type;
        private double baseVoltage;
        private double baseCurrent;
        private double baseTemperature;
        private Map<String, Object> attributes;
    }
    
    @Data
    public static class ScenarioConfig {
        private String name;
        private String description;
        private List<SimulationStep> steps;
        private Map<String, Object> parameters;
    }
    
    @Data
    public static class SimulationStep {
        private String action;
        private Map<String, Object> parameters;
        private int duration;  // 秒
        private String condition;
    }
    
    @Data
    public static class FaultSimulation {
        private double faultProbability;
        private List<FaultProfile> faultProfiles;
        private boolean enabled;
    }
    
    @Data
    public static class NetworkSimulation {
        private int minLatency;  // 毫秒
        private int maxLatency;  // 毫秒
        private double packetLossRate;
        private boolean enabled;
    }
} 