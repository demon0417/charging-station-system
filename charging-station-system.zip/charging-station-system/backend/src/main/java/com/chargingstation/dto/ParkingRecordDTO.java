package com.chargingstation.dto;

import lombok.Data;
import java.time.LocalDateTime;
import java.math.BigDecimal;

@Data
public class ParkingRecordDTO {
    private Long vehicleId;
    private String plateNumber;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private BigDecimal parkingFee;
} 