package com.chargingstation.controllers;

import com.chargingstation.dto.statistics.*;
import com.chargingstation.service.StatisticsService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/statistics")
@RequiredArgsConstructor
public class StatisticsController {

    private final StatisticsService statisticsService;

    @GetMapping("/daily")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<DailyStatisticsDTO> getDailyStatistics(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime date) {
        return ResponseEntity.ok(statisticsService.getDailyStatistics(date));
    }

    @GetMapping("/realtime")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<RealTimeStatisticsDTO> getRealTimeStatistics() {
        return ResponseEntity.ok(statisticsService.getRealTimeStatistics());
    }

    @GetMapping("/user-behavior/{plateNumber}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<UserBehaviorDTO> getUserBehavior(
            @PathVariable String plateNumber,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startTime,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endTime) {
        return ResponseEntity.ok(statisticsService.getUserBehavior(plateNumber, startTime, endTime));
    }

    @GetMapping("/peak-hours")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<PeakHourDTO>> getPeakHours(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime date) {
        return ResponseEntity.ok(statisticsService.analyzePeakHours(date));
    }
} 