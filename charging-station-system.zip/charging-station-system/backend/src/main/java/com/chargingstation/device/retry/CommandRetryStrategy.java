package com.chargingstation.device.retry;

import com.chargingstation.device.exception.DeviceCommunicationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeoutException;
import java.util.function.Supplier;

@Slf4j
@Component
public class CommandRetryStrategy {

    /**
     * 执行带重试的指令
     */
    public <T> T executeWithRetry(
            String deviceId,
            Supplier<T> command,
            int maxAttempts,
            long delayMs,
            Class<? extends Exception>... retryableExceptions
    ) throws DeviceCommunicationException {
        int attempts = 0;
        Exception lastException = null;

        while (attempts < maxAttempts) {
            try {
                return command.get();
            } catch (Exception e) {
                lastException = e;
                
                // 检查是否是可重试的异常
                if (!isRetryableException(e, retryableExceptions)) {
                    throw new DeviceCommunicationException(
                        String.format("设备%s指令执行失败: %s", deviceId, e.getMessage()),
                        e
                    );
                }

                attempts++;
                if (attempts < maxAttempts) {
                    log.warn("设备{}指令执行失败,准备第{}次重试: {}", 
                        deviceId, attempts + 1, e.getMessage());
                    sleep(delayMs);
                }
            }
        }

        throw new DeviceCommunicationException(
            String.format("设备%s指令重试%d次后仍然失败", deviceId, maxAttempts),
            lastException
        );
    }

    private boolean isRetryableException(Exception e, Class<? extends Exception>[] retryableExceptions) {
        if (retryableExceptions == null || retryableExceptions.length == 0) {
            return e instanceof TimeoutException;
        }
        
        for (Class<? extends Exception> retryableException : retryableExceptions) {
            if (retryableException.isInstance(e)) {
                return true;
            }
        }
        return false;
    }

    private void sleep(long delayMs) {
        try {
            Thread.sleep(delayMs);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
} 