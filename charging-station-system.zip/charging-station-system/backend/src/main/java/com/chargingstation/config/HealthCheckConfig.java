package com.chargingstation.config;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
public class HealthCheckConfig {

    @Bean
    public HealthIndicator databaseHealthIndicator(JdbcTemplate jdbcTemplate) {
        return () -> {
            try {
                jdbcTemplate.queryForObject("SELECT 1", Integer.class);
                return Health.up().withDetail("database", "Database is running").build();
            } catch (Exception e) {
                return Health.down()
                    .withDetail("database", "Database is down")
                    .withException(e)
                    .build();
            }
        };
    }

    @Bean
    public HealthIndicator redisHealthIndicator(RedisConnectionFactory redisConnectionFactory) {
        return () -> {
            try {
                redisConnectionFactory.getConnection().ping();
                return Health.up().withDetail("redis", "Redis is running").build();
            } catch (Exception e) {
                return Health.down()
                    .withDetail("redis", "Redis is down")
                    .withException(e)
                    .build();
            }
        };
    }
} 