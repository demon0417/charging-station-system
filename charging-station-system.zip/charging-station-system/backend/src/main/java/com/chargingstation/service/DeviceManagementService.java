package com.chargingstation.service;

import com.chargingstation.device.adapter.DeviceAdapter;
import com.chargingstation.device.model.DeviceCommand;
import com.chargingstation.device.model.DeviceResponse;
import com.chargingstation.device.simulator.ChargerSimulator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class DeviceManagementService {
    
    private final Map<String, DeviceAdapter> deviceAdapters;
    private final ChargerSimulator simulator;

    public Mono<DeviceResponse> executeCommand(String deviceId, String commandType, Map<String, String> parameters) {
        DeviceCommand command = new DeviceCommand(deviceId, commandType, parameters);
        
        if (isSimulationMode(deviceId)) {
            return simulator.processCommand(command);
        }
        
        DeviceAdapter adapter = getAdapterForDevice(deviceId);
        return adapter.sendCommand(command)
            .doOnError(e -> log.error("Error executing command on device {}: {}", deviceId, e.getMessage()))
            .onErrorResume(e -> Mono.just(new DeviceResponse(false, Map.of("error", e.getMessage()))));
    }

    public Mono<Boolean> checkDeviceStatus(String deviceId) {
        if (isSimulationMode(deviceId)) {
            return Mono.just(true);
        }
        
        DeviceAdapter adapter = getAdapterForDevice(deviceId);
        return adapter.isDeviceOnline(deviceId);
    }

    private boolean isSimulationMode(String deviceId) {
        return deviceId.startsWith("SIM_");
    }

    private DeviceAdapter getAdapterForDevice(String deviceId) {
        String protocol = determineDeviceProtocol(deviceId);
        DeviceAdapter adapter = deviceAdapters.get(protocol);
        
        if (adapter == null) {
            throw new IllegalArgumentException("No adapter found for protocol: " + protocol);
        }
        
        return adapter;
    }

    private String determineDeviceProtocol(String deviceId) {
        // 根据设备ID或配置确定协议类型
        if (deviceId.startsWith("OCPP_")) {
            return "OCPP";
        } else if (deviceId.startsWith("MODBUS_")) {
            return "MODBUS";
        } else {
            return "DEFAULT";
        }
    }
} 