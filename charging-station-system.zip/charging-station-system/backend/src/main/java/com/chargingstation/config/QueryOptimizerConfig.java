package com.chargingstation.config;

import org.hibernate.cfg.AvailableSettings;
import org.springframework.boot.autoconfigure.orm.jpa.HibernatePropertiesCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

@Configuration
public class QueryOptimizerConfig {

    @Bean
    public HibernatePropertiesCustomizer hibernatePropertiesCustomizer() {
        return hibernateProperties -> {
            // 启用查询计划缓存
            hibernateProperties.put(AvailableSettings.USE_QUERY_CACHE, true);
            hibernateProperties.put(AvailableSettings.USE_SECOND_LEVEL_CACHE, true);
            hibernateProperties.put(AvailableSettings.CACHE_REGION_FACTORY, 
                "org.hibernate.cache.jcache.JCacheRegionFactory");
            
            // 批处理优化
            hibernateProperties.put(AvailableSettings.STATEMENT_BATCH_SIZE, 50);
            hibernateProperties.put(AvailableSettings.ORDER_INSERTS, true);
            hibernateProperties.put(AvailableSettings.ORDER_UPDATES, true);
            
            // 查询优化器设置
            hibernateProperties.put(AvailableSettings.MAX_FETCH_DEPTH, 3);
            hibernateProperties.put(AvailableSettings.DEFAULT_BATCH_FETCH_SIZE, 100);
            hibernateProperties.put(AvailableSettings.QUERY_PLAN_CACHE_MAX_SIZE, 2048);
            
            // 统计信息收集
            hibernateProperties.put(AvailableSettings.GENERATE_STATISTICS, true);
        };
    }
} 