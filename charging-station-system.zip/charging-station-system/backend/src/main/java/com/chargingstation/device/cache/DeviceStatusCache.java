package com.chargingstation.device.cache;

import com.chargingstation.dto.LockStatusDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Component
public class DeviceStatusCache {
    
    private final Map<String, LockStatusDTO> statusCache = new ConcurrentHashMap<>();
    private final Map<String, LocalDateTime> lastUpdateTime = new ConcurrentHashMap<>();
    
    // 缓存过期时间（秒）
    private static final long CACHE_EXPIRATION = 30;

    /**
     * 更新设备状态缓存
     */
    public void updateStatus(String deviceId, LockStatusDTO status) {
        statusCache.put(deviceId, status);
        lastUpdateTime.put(deviceId, LocalDateTime.now());
        log.debug("更新设备{}状态缓存: {}", deviceId, status);
    }

    /**
     * 获取设备状态
     */
    public LockStatusDTO getStatus(String deviceId) {
        LocalDateTime lastUpdate = lastUpdateTime.get(deviceId);
        if (lastUpdate == null) {
            return null;
        }

        // 检查缓存是否过期
        if (LocalDateTime.now().minusSeconds(CACHE_EXPIRATION).isAfter(lastUpdate)) {
            statusCache.remove(deviceId);
            lastUpdateTime.remove(deviceId);
            return null;
        }

        return statusCache.get(deviceId);
    }

    /**
     * 清除设备状态缓存
     */
    public void clearStatus(String deviceId) {
        statusCache.remove(deviceId);
        lastUpdateTime.remove(deviceId);
        log.debug("清除设备{}状态缓存", deviceId);
    }

    /**
     * 获取所有设备状态
     */
    public Map<String, LockStatusDTO> getAllStatus() {
        // 清理过期缓存
        LocalDateTime expirationTime = LocalDateTime.now().minusSeconds(CACHE_EXPIRATION);
        lastUpdateTime.entrySet().removeIf(entry -> 
            entry.getValue().isBefore(expirationTime)
        );
        statusCache.keySet().retainAll(lastUpdateTime.keySet());
        
        return new ConcurrentHashMap<>(statusCache);
    }
} 