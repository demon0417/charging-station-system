package com.chargingstation.ops;

import com.chargingstation.monitoring.AlertService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.io.File;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Service
@RequiredArgsConstructor
public class AutomatedOpsService {

    private final AlertService alertService;
    private final Map<String, HealthStatus> serviceHealth = new ConcurrentHashMap<>();
    
    @Value("${ops.disk.threshold}")
    private int diskThresholdPercent;
    
    @Value("${ops.memory.threshold}")
    private int memoryThresholdPercent;

    @Scheduled(fixedRate = 300000) // 每5分钟执行一次
    public void performHealthCheck() {
        checkDiskSpace();
        checkMemoryUsage();
        checkServiceHealth();
        performLogRotation();
    }

    private void checkDiskSpace() {
        File root = new File("/");
        long totalSpace = root.getTotalSpace();
        long usableSpace = root.getUsableSpace();
        int usedPercent = (int) ((totalSpace - usableSpace) * 100 / totalSpace);

        if (usedPercent > diskThresholdPercent) {
            alertService.sendSystemAlert(
                "磁盘空间警告",
                String.format("磁盘使用率达到 %d%%", usedPercent),
                AlertService.AlertLevel.WARNING
            );
        }
    }

    private void checkMemoryUsage() {
        Runtime runtime = Runtime.getRuntime();
        long maxMemory = runtime.maxMemory();
        long usedMemory = runtime.totalMemory() - runtime.freeMemory();
        int usedPercent = (int) (usedMemory * 100 / maxMemory);

        if (usedPercent > memoryThresholdPercent) {
            alertService.sendSystemAlert(
                "内存使用警告",
                String.format("内存使用率达到 %d%%", usedPercent),
                AlertService.AlertLevel.WARNING
            );
        }
    }

    private void checkServiceHealth() {
        serviceHealth.forEach((service, status) -> {
            if (!status.isHealthy() && 
                LocalDateTime.now().isAfter(status.getLastHealthyTime().plusMinutes(5))) {
                // 尝试重启服务
                restartService(service);
            }
        });
    }

    private void restartService(String service) {
        log.info("正在重启服务: {}", service);
        try {
            // 执行重启命令
            Process process = Runtime.getRuntime().exec("systemctl restart " + service);
            int exitCode = process.waitFor();
            
            if (exitCode == 0) {
                log.info("服务重启成功: {}", service);
                serviceHealth.get(service).setHealthy(true);
            } else {
                log.error("服务重启失败: {}", service);
                alertService.sendSystemAlert(
                    "服务重启失败",
                    "服务 " + service + " 重启失败",
                    AlertService.AlertLevel.CRITICAL
                );
            }
        } catch (Exception e) {
            log.error("重启服务时发生错误", e);
        }
    }

    private void performLogRotation() {
        // 实现日志轮转逻辑
    }

    @Data
    private static class HealthStatus {
        private boolean healthy = true;
        private LocalDateTime lastHealthyTime = LocalDateTime.now();
    }
} 