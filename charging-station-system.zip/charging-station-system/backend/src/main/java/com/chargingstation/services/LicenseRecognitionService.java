package com.chargingstation.services;

import com.chargingstation.dto.LicenseRecognitionResult;
import com.chargingstation.exceptions.RecognitionException;
import com.chargingstation.models.enums.VehicleType;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Base64;
import java.util.Map;
import java.util.concurrent.TimeoutException;

@Slf4j
@Service
@RequiredArgsConstructor
public class LicenseRecognitionService {

    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;

    @Value("${license.recognition.api.url}")
    private String apiUrl;

    @Value("${license.recognition.api.key}")
    private String apiKey;

    @Value("${license.recognition.timeout:5000}")
    private int timeout;

    @Value("${license.recognition.min-confidence:0.8}")
    private double minConfidence;

    /**
     * 识别车牌
     */
    @Retryable(
        value = {TimeoutException.class},
        maxAttempts = 3,
        backoff = @Backoff(delay = 1000)
    )
    public LicenseRecognitionResult recognizeLicense(String imageBase64) {
        validateImage(imageBase64);
        
        try {
            // 准备请求头
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("X-API-Key", apiKey);

            // 准备请求体
            Map<String, String> requestBody = Map.of(
                "image", imageBase64,
                "min_confidence", String.valueOf(minConfidence)
            );

            // 发送请求
            ResponseEntity<String> response = restTemplate.exchange(
                apiUrl,
                HttpMethod.POST,
                new HttpEntity<>(requestBody, headers),
                String.class
            );

            // 解析响应
            return parseResponse(response.getBody());
            
        } catch (Exception e) {
            log.error("车牌识别失败", e);
            if (e instanceof TimeoutException) {
                throw new RecognitionException("识别服务超时", e);
            }
            throw new RecognitionException("车牌识别失败: " + e.getMessage(), e);
        }
    }

    /**
     * 验证图片
     */
    private void validateImage(String imageBase64) {
        if (imageBase64 == null || imageBase64.trim().isEmpty()) {
            throw new RecognitionException("图片数据不能为空");
        }

        try {
            byte[] imageBytes = Base64.getDecoder().decode(imageBase64);
            if (imageBytes.length > 4 * 1024 * 1024) { // 4MB
                throw new RecognitionException("图片大小超过限制");
            }
            
            // 验证图片格式
            if (!isValidImageFormat(imageBytes)) {
                throw new RecognitionException("不支持的图片格式");
            }
        } catch (IllegalArgumentException e) {
            throw new RecognitionException("Base64编码无效");
        }
    }

    /**
     * 验证图片格式
     */
    private boolean isValidImageFormat(byte[] imageBytes) {
        if (imageBytes.length < 4) {
            return false;
        }
        
        // 检查文件头
        return (
            // JPEG
            (imageBytes[0] == (byte) 0xFF && imageBytes[1] == (byte) 0xD8) ||
            // PNG
            (imageBytes[0] == (byte) 0x89 && imageBytes[1] == (byte) 0x50 && 
             imageBytes[2] == (byte) 0x4E && imageBytes[3] == (byte) 0x47)
        );
    }

    /**
     * 解析API响应
     */
    private LicenseRecognitionResult parseResponse(String responseBody) {
        try {
            Map<String, Object> response = objectMapper.readValue(responseBody, Map.class);
            
            // 检查响应状态
            if (!Boolean.TRUE.equals(response.get("success"))) {
                String errorMsg = response.get("message") != null ? 
                    response.get("message").toString() : "未知错误";
                throw new RecognitionException("识别失败: " + errorMsg);
            }

            Map<String, Object> data = (Map<String, Object>) response.get("data");
            if (data == null || data.isEmpty()) {
                throw new RecognitionException("识别结果为空");
            }

            // 提取识别结果
            String plateNumber = (String) data.get("plate_number");
            String vehicleTypeStr = (String) data.get("vehicle_type");
            double confidence = Double.parseDouble(data.get("confidence").toString());

            // 验证置信度
            if (confidence < minConfidence) {
                throw new RecognitionException(
                    String.format("识别置信度(%.2f)低于阈值(%.2f)", confidence, minConfidence)
                );
            }

            // 验证车牌格式
            if (!isValidPlateNumber(plateNumber)) {
                throw new RecognitionException("车牌格式无效: " + plateNumber);
            }

            return LicenseRecognitionResult.builder()
                .plateNumber(plateNumber)
                .vehicleType(mapVehicleType(vehicleTypeStr))
                .confidence(confidence)
                .build();
                
        } catch (Exception e) {
            if (e instanceof RecognitionException) {
                throw (RecognitionException) e;
            }
            throw new RecognitionException("解析识别结果失败: " + e.getMessage(), e);
        }
    }

    /**
     * 验证车牌号格式
     */
    private boolean isValidPlateNumber(String plateNumber) {
        return plateNumber != null && 
               plateNumber.matches("^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领][A-Z][A-Z0-9]{4,5}[A-Z0-9挂学警港澳]$");
    }

    /**
     * 映射车辆类型
     */
    private VehicleType mapVehicleType(String typeStr) {
        if (typeStr == null) {
            return VehicleType.OTHER;
        }
        
        switch (typeStr.toUpperCase()) {
            case "小型汽车":
                return VehicleType.SMALL;
            case "中型汽车":
                return VehicleType.MEDIUM;
            case "大型汽车":
                return VehicleType.LARGE;
            case "新能源":
                return VehicleType.NEW_ENERGY;
            default:
                return VehicleType.OTHER;
        }
    }
} 