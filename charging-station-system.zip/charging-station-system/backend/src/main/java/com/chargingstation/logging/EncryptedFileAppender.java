package com.chargingstation.logging;

import ch.qos.logback.core.FileAppender;
import com.chargingstation.utils.LogEncryptUtil;
import org.springframework.beans.factory.annotation.Autowired;

public class EncryptedFileAppender<E> extends FileAppender<E> {
    
    @Autowired
    private LogEncryptUtil logEncryptUtil;

    @Override
    protected void writeOut(E event) throws Exception {
        String eventStr = event.toString();
        String encryptedEvent = logEncryptUtil.encrypt(eventStr);
        super.writeOut((E) encryptedEvent);
    }
} 