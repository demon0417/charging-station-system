package com.chargingstation.monitoring;

import io.micrometer.core.instrument.MeterRegistry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

@Slf4j
@Aspect
@Component
@RequiredArgsConstructor
public class SlowQueryMonitor {

    private final MeterRegistry meterRegistry;
    private final SqlExecutionPlanAnalyzer sqlAnalyzer;

    @Value("${monitoring.slow-query-threshold:1000}")
    private long slowQueryThreshold;

    @Around("execution(* org.springframework.jdbc.core.JdbcTemplate.*(..))")
    public Object monitorQuery(ProceedingJoinPoint joinPoint) throws Throwable {
        long startTime = System.nanoTime();
        String methodName = joinPoint.getSignature().getName();
        
        try {
            Object result = joinPoint.proceed();
            
            long duration = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startTime);
            recordQueryMetrics(methodName, duration);
            
            if (duration > slowQueryThreshold) {
                handleSlowQuery(joinPoint, duration);
            }
            
            return result;
        } catch (Exception e) {
            recordQueryError(methodName, e);
            throw e;
        }
    }

    private void recordQueryMetrics(String methodName, long duration) {
        meterRegistry.timer("sql.query.duration", "method", methodName)
            .record(Duration.ofMillis(duration));
    }

    private void recordQueryError(String methodName, Exception e) {
        meterRegistry.counter("sql.query.errors", "method", methodName, 
            "error", e.getClass().getSimpleName()).increment();
    }

    private void handleSlowQuery(ProceedingJoinPoint joinPoint, long duration) {
        Object[] args = joinPoint.getArgs();
        if (args.length > 0 && args[0] instanceof String) {
            String sql = (String) args[0];
            log.warn("检测到慢查询 - 执行时间: {}ms, SQL: {}", duration, sql);
            sqlAnalyzer.analyzeQuery(sql);
        }
    }
} 