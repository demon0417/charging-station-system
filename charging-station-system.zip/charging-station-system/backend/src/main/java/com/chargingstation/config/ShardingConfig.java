package com.chargingstation.config;

import org.apache.shardingsphere.api.config.sharding.ShardingRuleConfiguration;
import org.apache.shardingsphere.api.config.sharding.TableRuleConfiguration;
import org.apache.shardingsphere.api.config.sharding.strategy.StandardShardingStrategyConfiguration;
import org.apache.shardingsphere.shardingjdbc.api.ShardingDataSourceFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

@Configuration
public class ShardingConfig {

    @Bean
    public DataSource shardingDataSource(DataSource routingDataSource) throws SQLException {
        ShardingRuleConfiguration shardingRuleConfig = new ShardingRuleConfiguration();
        
        // 配置充电记录分片规则
        shardingRuleConfig.getTableRuleConfigs().add(getChargingRecordTableRule());
        // 配置停车记录分片规则
        shardingRuleConfig.getTableRuleConfigs().add(getParkingRecordTableRule());

        Map<String, DataSource> dataSourceMap = new HashMap<>();
        dataSourceMap.put("ds0", routingDataSource);

        Properties props = new Properties();
        props.put("sql.show", true);

        return ShardingDataSourceFactory.createDataSource(
            dataSourceMap, 
            shardingRuleConfig, 
            props
        );
    }

    private TableRuleConfiguration getChargingRecordTableRule() {
        TableRuleConfiguration result = new TableRuleConfiguration(
            "charging_records", 
            "ds0.charging_records_${0..11}"
        );
        
        // 按月份分片
        result.setTableShardingStrategyConfig(
            new StandardShardingStrategyConfiguration(
                "created_at",
                new MonthShardingAlgorithm()
            )
        );
        
        return result;
    }

    private TableRuleConfiguration getParkingRecordTableRule() {
        TableRuleConfiguration result = new TableRuleConfiguration(
            "parking_records", 
            "ds0.parking_records_${0..11}"
        );
        
        // 按月份分片
        result.setTableShardingStrategyConfig(
            new StandardShardingStrategyConfiguration(
                "created_at",
                new MonthShardingAlgorithm()
            )
        );
        
        return result;
    }
} 