package com.chargingstation.monitoring;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class AlertService {

    private final JavaMailSender mailSender;
    
    @Value("${alert.mail.to}")
    private List<String> alertRecipients;
    
    @Value("${alert.mail.from}")
    private String alertSender;

    public void sendSystemAlert(String subject, String message, AlertLevel level) {
        log.warn("系统告警 - 级别: {}, 主题: {}, 内容: {}", level, subject, message);
        
        SimpleMailMessage mailMessage = new SimpleMailMessage();
        mailMessage.setFrom(alertSender);
        mailMessage.setTo(alertRecipients.toArray(new String[0]));
        mailMessage.setSubject("[" + level + "] " + subject);
        mailMessage.setText(message);
        
        try {
            mailSender.send(mailMessage);
            log.info("告警邮件发送成功");
        } catch (Exception e) {
            log.error("告警邮件发送失败", e);
        }
    }

    public enum AlertLevel {
        INFO,
        WARNING,
        ERROR,
        CRITICAL
    }
} 