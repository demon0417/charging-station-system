package com.chargingstation.service;

import com.chargingstation.models.Vehicle;
import com.chargingstation.models.enums.VehicleType;
import com.chargingstation.repositories.VehicleRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.event.ApplicationStartedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class CacheWarmupService {

    private final RedisTemplate<String, Object> redisTemplate;
    private final VehicleRepository vehicleRepository;
    private final ChargingService chargingService;
    private final ParkingService parkingService;

    @EventListener(ApplicationStartedEvent.class)
    public void warmupOnStartup() {
        log.info("开始缓存预热...");
        warmupVehicleCache();
        warmupRateConfig();
        warmupStatistics();
        log.info("缓存预热完成");
    }

    @Scheduled(cron = "0 0 * * * *") // 每小时执行一次
    public void scheduledWarmup() {
        log.info("开始定时缓存预热...");
        warmupStatistics();
        log.info("定时缓存预热完成");
    }

    private void warmupVehicleCache() {
        // 预热当前停车的车辆信息
        List<Vehicle> currentVehicles = vehicleRepository.findCurrentParkedVehicles(LocalDateTime.now());
        for (Vehicle vehicle : currentVehicles) {
            String key = "vehicle:status:" + vehicle.getId();
            redisTemplate.opsForValue().set(key, vehicle, Duration.ofHours(1));
        }

        // 预热车辆类型统计
        Map<VehicleType, Long> typeStats = currentVehicles.stream()
            .collect(Collectors.groupingBy(Vehicle::getVehicleType, Collectors.counting()));
        redisTemplate.opsForHash().putAll("vehicle:type:stats", typeStats);
    }

    private void warmupRateConfig() {
        // 预热费率配置
        Map<String, Object> rateConfig = Map.of(
            "parking.hourly", 5.0,
            "charging.kwh", 1.5,
            "parking.free.duration", 7200
        );
        redisTemplate.opsForHash().putAll("rate:config", rateConfig);
    }

    private void warmupStatistics() {
        LocalDateTime now = LocalDateTime.now();
        
        // 预热今日统计数据
        String dailyStatsKey = "stats:daily:" + now.toLocalDate();
        Map<String, Object> dailyStats = Map.of(
            "vehicleCount", vehicleRepository.countDailyVehicles(now.toLocalDate().atStartOfDay(), now),
            "chargingIncome", chargingService.calculateDailyIncome(now),
            "parkingIncome", parkingService.calculateDailyIncome(now)
        );
        redisTemplate.opsForHash().putAll(dailyStatsKey, dailyStats);

        // 预热实时统计数据
        String realtimeStatsKey = "stats:realtime";
        Map<String, Object> realtimeStats = Map.of(
            "currentCharging", chargingService.getCurrentChargingCount(),
            "currentParking", parkingService.getCurrentParkingCount()
        );
        redisTemplate.opsForHash().putAll(realtimeStatsKey, realtimeStats);
    }

    public void refreshVehicleCache(Long vehicleId) {
        Vehicle vehicle = vehicleRepository.findById(vehicleId).orElse(null);
        if (vehicle != null) {
            String key = "vehicle:status:" + vehicleId;
            redisTemplate.opsForValue().set(key, vehicle, Duration.ofHours(1));
        }
    }
} 