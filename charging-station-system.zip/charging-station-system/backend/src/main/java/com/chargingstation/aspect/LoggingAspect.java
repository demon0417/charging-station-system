package com.chargingstation.aspect;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.slf4j.MDC;

import java.time.LocalDateTime;
import java.util.Arrays;

@Aspect
@Component
@Slf4j
public class LoggingAspect {

    @Value("${logging.slow-execution-threshold:500}")
    private long slowExecutionThreshold;

    @Around("@annotation(com.chargingstation.annotation.Audited)")
    public Object logAuditOperation(ProceedingJoinPoint joinPoint) throws Throwable {
        String methodName = joinPoint.getSignature().getName();
        String className = joinPoint.getTarget().getClass().getSimpleName();
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication != null ? authentication.getName() : "anonymous";

        try {
            MDC.put("username", username);
            MDC.put("operation", methodName);
            MDC.put("timestamp", LocalDateTime.now().toString());

            log.info("审计日志 - 用户[{}]执行操作[{}.{}], 参数: {}", 
                username, className, methodName, Arrays.toString(joinPoint.getArgs()));
            
            Object result = joinPoint.proceed();
            
            log.info("审计日志 - 操作完成[{}.{}]", className, methodName);
            return result;
        } finally {
            MDC.clear();
        }
    }

    @Around("execution(* com.chargingstation.controllers..*.*(..))")
    public Object logControllerPerformance(ProceedingJoinPoint joinPoint) throws Throwable {
        String methodName = joinPoint.getSignature().getName();
        String className = joinPoint.getTarget().getClass().getSimpleName();
        long startTime = System.currentTimeMillis();

        try {
            Object result = joinPoint.proceed();
            long executionTime = System.currentTimeMillis() - startTime;

            if (executionTime > slowExecutionThreshold) {
                log.warn("性能日志 - 慢请求: {}.{}, 执行时间: {}ms", className, methodName, executionTime);
            } else {
                log.debug("性能日志 - {}.{}, 执行时间: {}ms", className, methodName, executionTime);
            }

            return result;
        } catch (Exception e) {
            log.error("性能日志 - 执行异常: {}.{}, 耗时: {}ms", 
                className, methodName, (System.currentTimeMillis() - startTime), e);
            throw e;
        }
    }

    @Around("execution(* com.chargingstation.security..*.*(..))")
    public Object logSecurityOperation(ProceedingJoinPoint joinPoint) throws Throwable {
        String methodName = joinPoint.getSignature().getName();
        String className = joinPoint.getTarget().getClass().getSimpleName();
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication != null ? authentication.getName() : "anonymous";

        try {
            MDC.put("username", username);
            MDC.put("securityOperation", methodName);

            log.info("安全日志 - 用户[{}]执行安全操作[{}.{}]", username, className, methodName);
            return joinPoint.proceed();
        } catch (Exception e) {
            log.error("安全日志 - 安全操作失败: {}.{}, 用户: {}", className, methodName, username, e);
            throw e;
        } finally {
            MDC.clear();
        }
    }
} 