package com.chargingstation.repositories;

import com.chargingstation.models.ParkingRecord;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;

@Repository
public interface ParkingRecordRepository extends JpaRepository<ParkingRecord, Long> {
    
    @Query("SELECT p FROM ParkingRecord p WHERE p.vehicle.id = :vehicleId AND p.endTime IS NULL")
    Optional<ParkingRecord> findActiveRecordByVehicleId(@Param("vehicleId") Long vehicleId);
    
    Page<Vehicle> findByVehicleIdOrderByStartTimeDesc(Long vehicleId, Pageable pageable);
    
    @Query("SELECT p FROM ParkingRecord p WHERE " +
           "(:vehicleId IS NULL OR p.vehicle.id = :vehicleId) AND " +
           "(:startTime IS NULL OR p.startTime >= :startTime) AND " +
           "(:endTime IS NULL OR p.startTime <= :endTime)")
    Page<ParkingRecord> findByConditions(
        @Param("vehicleId") Long vehicleId,
        @Param("startTime") LocalDateTime startTime,
        @Param("endTime") LocalDateTime endTime,
        Pageable pageable
    );
    
    @Query("SELECT COUNT(p) FROM ParkingRecord p WHERE p.endTime IS NULL")
    long countCurrentParking();
    
    @Query("SELECT SUM(p.parkingFee) FROM ParkingRecord p WHERE " +
           "p.endTime >= :startTime AND p.endTime < :endTime")
    BigDecimal calculateDailyIncome(@Param("startTime") LocalDateTime startTime, 
                                   @Param("endTime") LocalDateTime endTime);
} 