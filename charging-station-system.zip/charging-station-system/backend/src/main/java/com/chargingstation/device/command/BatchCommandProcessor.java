package com.chargingstation.device.command;

import com.chargingstation.device.exception.DeviceCommunicationException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class BatchCommandProcessor {

    private final ExecutorService executorService = Executors.newFixedThreadPool(10);
    private final Map<String, CompletableFuture<byte[]>> pendingCommands = new ConcurrentHashMap<>();

    /**
     * 批量发送指令
     */
    public Map<String, byte[]> sendBatchCommands(Map<String, byte[]> deviceCommands, int timeout) {
        try {
            // 并行发送指令
            List<CompletableFuture<Map.Entry<String, byte[]>>> futures = deviceCommands.entrySet()
                .stream()
                .map(entry -> CompletableFuture.supplyAsync(() -> {
                    try {
                        byte[] response = sendCommand(entry.getKey(), entry.getValue(), timeout);
                        return Map.entry(entry.getKey(), response);
                    } catch (Exception e) {
                        log.error("设备{}指令发送失败", entry.getKey(), e);
                        return Map.entry(entry.getKey(), new byte[0]);
                    }
                }, executorService))
                .collect(Collectors.toList());

            // 等待所有指令完成
            CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();

            // 收集结果
            return futures.stream()
                .map(CompletableFuture::join)
                .collect(Collectors.toMap(
                    Map.Entry::getKey,
                    Map.Entry::getValue
                ));

        } catch (Exception e) {
            throw new DeviceCommunicationException("批量指令处理失败", e);
        }
    }

    /**
     * 取消待处理的指令
     */
    public void cancelPendingCommands(String deviceId) {
        CompletableFuture<byte[]> future = pendingCommands.remove(deviceId);
        if (future != null && !future.isDone()) {
            future.cancel(true);
        }
    }

    /**
     * 获取指令执行状态
     */
    public CommandStatus getCommandStatus(String deviceId) {
        CompletableFuture<byte[]> future = pendingCommands.get(deviceId);
        if (future == null) {
            return new CommandStatus(deviceId, "UNKNOWN", null);
        }
        
        if (future.isDone()) {
            return new CommandStatus(deviceId, "COMPLETED", null);
        }
        
        if (future.isCancelled()) {
            return new CommandStatus(deviceId, "CANCELLED", null);
        }
        
        return new CommandStatus(deviceId, "PENDING", null);
    }

    record CommandStatus(String deviceId, String status, String error) {}
} 