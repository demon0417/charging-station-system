package com.chargingstation.models.enums;

public enum VehicleType {
    ELECTRIC_VEHICLE("电动车"),
    FUEL_VEHICLE("燃油车");

    private final String description;

    VehicleType(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
} 