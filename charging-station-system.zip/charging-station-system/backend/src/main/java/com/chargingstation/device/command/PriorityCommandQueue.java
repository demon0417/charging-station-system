package com.chargingstation.device.command;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Comparator;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.PriorityBlockingQueue;

@Slf4j
@Component
public class PriorityCommandQueue {

    private final Map<String, Queue<PrioritizedCommand>> deviceQueues = new ConcurrentHashMap<>();
    
    // 优先级定义
    public enum CommandPriority {
        EMERGENCY(0),      // 紧急指令
        HIGH(1),          // 高优先级
        NORMAL(2),        // 普通优先级
        LOW(3),           // 低优先级
        BACKGROUND(4);    // 后台任务
        
        private final int value;
        
        CommandPriority(int value) {
            this.value = value;
        }
        
        public int getValue() {
            return value;
        }
    }

    /**
     * 添加指令到优先级队列
     */
    public void enqueue(String deviceId, PrioritizedCommand command) {
        deviceQueues.computeIfAbsent(deviceId, k -> new PriorityBlockingQueue<>(
            11,
            Comparator.comparingInt((PrioritizedCommand c) -> c.priority().getValue())
        )).offer(command);
        
        log.debug("设备{}添加{}优先级指令: {}", 
            deviceId, command.priority(), command.commandId());
    }

    /**
     * 获取下一个待执行的指令
     */
    public PrioritizedCommand poll(String deviceId) {
        Queue<PrioritizedCommand> queue = deviceQueues.get(deviceId);
        if (queue == null || queue.isEmpty()) {
            return null;
        }
        return queue.poll();
    }

    /**
     * 获取队列长度
     */
    public int getQueueSize(String deviceId) {
        Queue<PrioritizedCommand> queue = deviceQueues.get(deviceId);
        return queue != null ? queue.size() : 0;
    }

    /**
     * 清空指定设备的队列
     */
    public void clearQueue(String deviceId) {
        Queue<PrioritizedCommand> queue = deviceQueues.remove(deviceId);
        if (queue != null) {
            queue.clear();
        }
    }

    /**
     * 优先级指令
     */
    public record PrioritizedCommand(
        String commandId,
        byte[] data,
        CommandPriority priority,
        long timeout,
        long timestamp
    ) {}
} 