package com.chargingstation.device.protocol;

import com.chargingstation.device.exception.ProtocolException;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public interface ProtocolAdapter {
    /**
     * 将通用命令转换为特定协议的指令
     */
    byte[] convertToProtocol(Command command) throws ProtocolException;
    
    /**
     * 解析协议响应数据
     */
    Response parseResponse(byte[] data) throws ProtocolException;
    
    /**
     * 验证响应数据的有效性
     */
    boolean validateResponse(byte[] data);
}

/**
 * 通用命令格式
 */
record Command(
    CommandType type,
    String deviceId,
    Map<String, Object> parameters
) {}

/**
 * 通用响应格式
 */
record Response(
    boolean success,
    String deviceId,
    Map<String, Object> data,
    String errorMessage
) {}

/**
 * 命令类型枚举
 */
enum CommandType {
    READ_STATUS,
    WRITE_REGISTER,
    READ_REGISTER,
    CONTROL,
    CONFIGURE
} 