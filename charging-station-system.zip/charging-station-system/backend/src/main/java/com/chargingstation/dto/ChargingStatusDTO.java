package com.chargingstation.dto;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class ChargingStatusDTO {
    private Long vehicleId;
    private String plateNumber;
    private LocalDateTime startTime;
    private Long chargingDuration; // 充电时长（分钟）
    private BigDecimal currentPower; // 当前功率
    private BigDecimal estimatedFee; // 预估费用
} 