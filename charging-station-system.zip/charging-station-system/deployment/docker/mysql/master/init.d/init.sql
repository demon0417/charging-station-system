-- 创建复制用户
CREATE USER 'repl'@'%' IDENTIFIED BY 'repl123';
GRANT REPLICATION SLAVE ON *.* TO 'repl'@'%';
FLUSH PRIVILEGES;

-- 创建应用数据库和表
CREATE DATABASE IF NOT EXISTS charging_station;
USE charging_station;

-- 创建表结构
-- ... (这里包含所有的建表语句) 