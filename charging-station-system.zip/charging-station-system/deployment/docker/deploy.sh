#!/bin/bash

# 设置变量
DOCKER_REGISTRY="your-registry.com"
IMAGE_NAME="charging-station"
IMAGE_TAG=$(date +%Y%m%d_%H%M%S)

# 构建镜像
echo "Building Docker image..."
docker-compose build

# 标记镜像
echo "Tagging image..."
docker tag ${IMAGE_NAME}:latest ${DOCKER_REGISTRY}/${IMAGE_NAME}:${IMAGE_TAG}
docker tag ${IMAGE_NAME}:latest ${DOCKER_REGISTRY}/${IMAGE_NAME}:latest

# 推送镜像
echo "Pushing image to registry..."
docker push ${DOCKER_REGISTRY}/${IMAGE_NAME}:${IMAGE_TAG}
docker push ${DOCKER_REGISTRY}/${IMAGE_NAME}:latest

# 部署应用
echo "Deploying application..."
docker-compose up -d

# 检查服务状态
echo "Checking service status..."
docker-compose ps

# 检查日志
echo "Checking application logs..."
docker-compose logs -f app 