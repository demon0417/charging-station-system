#!/bin/bash

# 安装Istio
istioctl install --set profile=demo -y

# 启用自动注入
kubectl label namespace charging istio-injection=enabled

# 部署Gateway和VirtualService
kubectl apply -f gateway.yaml
kubectl apply -f virtual-service.yaml
kubectl apply -f destination-rule.yaml

# 部署监控
kubectl apply -f monitoring/ 

echo "Istio服务网格部署完成" 