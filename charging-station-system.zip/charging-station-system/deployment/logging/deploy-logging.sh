#!/bin/bash

# 创建命名空间
kubectl create namespace logging

# 部署Elasticsearch
kubectl apply -f elasticsearch/ -n logging

# 部署Fluentd
kubectl apply -f fluentd/ -n logging

# 部署Kibana
kubectl apply -f kibana/ -n logging

# 等待部署完成
kubectl rollout status statefulset/elasticsearch -n logging
kubectl rollout status daemonset/fluentd -n logging
kubectl rollout status deployment/kibana -n logging

echo "日志系统部署完成" 