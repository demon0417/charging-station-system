#!/bin/bash

# 创建命名空间
kubectl create namespace monitoring

# 部署Prometheus
kubectl apply -f prometheus/ -n monitoring

# 部署Grafana
kubectl apply -f grafana/ -n monitoring

# 等待部署完成
kubectl rollout status deployment/prometheus -n monitoring
kubectl rollout status deployment/grafana -n monitoring

# 创建服务监控
kubectl apply -f service-monitor.yaml -n monitoring

echo "监控系统部署完成" 