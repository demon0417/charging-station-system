#!/bin/bash

# 设置变量
NAMESPACE="charging"
DOCKER_REGISTRY="your-registry.com"
IMAGE_NAME="charging-station"
IMAGE_TAG=$(date +%Y%m%d_%H%M%S)

# 创建命名空间
kubectl create namespace $NAMESPACE --dry-run=client -o yaml | kubectl apply -f -

# 应用配置
kubectl apply -f configmap.yaml
kubectl apply -f secret.yaml
kubectl apply -f pvc.yaml
kubectl apply -f network-policy.yaml

# 构建和推送镜像
docker build -t $DOCKER_REGISTRY/$IMAGE_NAME:$IMAGE_TAG -f ../docker/Dockerfile ../../
docker push $DOCKER_REGISTRY/$IMAGE_NAME:$IMAGE_TAG

# 更新镜像版本
sed -i "s|image:.*|image: $DOCKER_REGISTRY/$IMAGE_NAME:$IMAGE_TAG|" deployment.yaml

# 部署应用
kubectl apply -f deployment.yaml
kubectl apply -f service.yaml
kubectl apply -f hpa.yaml

# 等待部署完成
kubectl rollout status deployment/charging-station -n $NAMESPACE

# 检查部署状态
echo "Checking deployment status..."
kubectl get all -n $NAMESPACE

# 检查日志
echo "Checking application logs..."
kubectl logs -l app=charging-station -n $NAMESPACE --tail=100 