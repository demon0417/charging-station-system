<template>
  <div class="base-table">
    <!-- 搜索区域 -->
    <div class="search-area" v-if="showSearch">
      <base-form
        ref="searchForm"
        :fields="searchFields"
        :show-buttons="false"
        label-width="80px"
        inline
      >
        <template #append>
          <el-button type="primary" @click="handleSearch">搜索</el-button>
          <el-button @click="handleResetSearch">重置</el-button>
        </template>
      </base-form>
    </div>

    <!-- 工具栏 -->
    <div class="toolbar" v-if="showToolbar">
      <div class="left">
        <slot name="toolbar-left">
          <el-button
            v-if="showAdd"
            type="primary"
            @click="$emit('add')"
          >
            新增
          </el-button>
          <el-button
            v-if="showBatchDelete"
            type="danger"
            :disabled="!selectedRows.length"
            @click="handleBatchDelete"
          >
            批量删除
          </el-button>
        </slot>
      </div>
      <div class="right">
        <slot name="toolbar-right">
          <el-button-group>
            <el-button
              :icon="Refresh"
              circle
              @click="refreshData"
            />
            <el-button
              :icon="setting ? Setting : List"
              circle
              @click="setting = !setting"
            />
          </el-button-group>
        </slot>
      </div>
    </div>

    <!-- 表格 -->
    <el-table
      ref="tableRef"
      v-loading="loading"
      :data="data"
      :height="height"
      :border="border"
      :stripe="stripe"
      @selection-change="handleSelectionChange"
    >
      <el-table-column
        v-if="showSelection"
        type="selection"
        width="55"
      />
      <el-table-column
        v-if="showIndex"
        type="index"
        width="55"
        label="序号"
      />
      
      <template v-for="column in visibleColumns" :key="column.prop">
        <el-table-column
          v-bind="column"
          :show-overflow-tooltip="true"
        >
          <template #default="scope" v-if="column.render">
            <component
              :is="column.render"
              :row="scope.row"
              :column="column"
              :$index="scope.$index"
            />
          </template>
        </el-table-column>
      </template>

      <el-table-column
        v-if="showOperations"
        label="操作"
        :width="operationWidth"
        fixed="right"
      >
        <template #default="scope">
          <slot name="operations" :row="scope.row">
            <el-button-group>
              <el-button
                v-if="showEdit"
                type="primary"
                link
                @click="$emit('edit', scope.row)"
              >
                编辑
              </el-button>
              <el-button
                v-if="showDelete"
                type="danger"
                link
                @click="handleDelete(scope.row)"
              >
                删除
              </el-button>
            </el-button-group>
          </slot>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页 -->
    <div class="pagination" v-if="showPagination">
      <el-pagination
        v-model:current-page="currentPage"
        v-model:page-size="pageSize"
        :total="total"
        :page-sizes="pageSizes"
        layout="total, sizes, prev, pager, next, jumper"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </div>

    <!-- 列设置抽屉 -->
    <el-drawer
      v-model="setting"
      title="列设置"
      direction="rtl"
      size="300px"
    >
      <el-checkbox-group v-model="selectedColumns">
        <div v-for="column in columns" :key="column.prop" class="column-item">
          <el-checkbox :label="column.prop">
            {{ column.label }}
          </el-checkbox>
        </div>
      </el-checkbox-group>
    </el-drawer>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch } from 'vue'
import { Setting, List, Refresh } from '@element-plus/icons-vue'
import BaseForm from './BaseForm.vue'

const props = defineProps({
  // 表格数据
  data: {
    type: Array,
    required: true
  },
  // 表格列配置
  columns: {
    type: Array,
    required: true
  },
  // 搜索字段配置
  searchFields: {
    type: Array,
    default: () => []
  },
  // 是否显示搜索区域
  showSearch: {
    type: Boolean,
    default: true
  },
  // 是否显示工具栏
  showToolbar: {
    type: Boolean,
    default: true
  },
  // 是否显示序号列
  showIndex: {
    type: Boolean,
    default: true
  },
  // 是否显示选择列
  showSelection: {
    type: Boolean,
    default: false
  },
  // 是否显示操作列
  showOperations: {
    type: Boolean,
    default: true
  },
  // 是否显示新增按钮
  showAdd: {
    type: Boolean,
    default: true
  },
  // 是否显示编辑按钮
  showEdit: {
    type: Boolean,
    default: true
  },
  // 是否显示删除按钮
  showDelete: {
    type: Boolean,
    default: true
  },
  // 是否显示批量删除按钮
  showBatchDelete: {
    type: Boolean,
    default: false
  },
  // 是否显示分页
  showPagination: {
    type: Boolean,
    default: true
  },
  // 表格高度
  height: {
    type: [String, Number],
    default: '100%'
  },
  // 是否带边框
  border: {
    type: Boolean,
    default: true
  },
  // 是否斑马纹
  stripe: {
    type: Boolean,
    default: true
  },
  // 操作列宽度
  operationWidth: {
    type: String,
    default: '150'
  },
  // 分页配置
  total: {
    type: Number,
    default: 0
  },
  pageSizes: {
    type: Array,
    default: () => [10, 20, 50, 100]
  }
})

const emit = defineEmits([
  'add',
  'edit',
  'delete',
  'batch-delete',
  'search',
  'reset',
  'refresh',
  'size-change',
  'current-change'
])

// 表格实例
const tableRef = ref()
// 搜索表单实例
const searchForm = ref()
// 列设置抽屉
const setting = ref(false)
// 加载状态
const loading = ref(false)
// 选中行
const selectedRows = ref([])
// 当前页码
const currentPage = ref(1)
// 每页条数
const pageSize = ref(10)
// 选中的列
const selectedColumns = ref(props.columns.map(column => column.prop))

// 可见列
const visibleColumns = computed(() => {
  return props.columns.filter(column => selectedColumns.value.includes(column.prop))
})

// 处理选择变化
const handleSelectionChange = (selection) => {
  selectedRows.value = selection
}

// 处理删除
const handleDelete = async (row) => {
  try {
    await ElMessageBox.confirm('确定要删除该记录吗？', '提示', {
      type: 'warning'
    })
    emit('delete', row)
  } catch {
    // 用户取消删除
  }
}

// 处理批量删除
const handleBatchDelete = async () => {
  try {
    await ElMessageBox.confirm(
      `确定要删除选中的 ${selectedRows.value.length} 条记录吗？`,
      '提示',
      {
        type: 'warning'
      }
    )
    emit('batch-delete', selectedRows.value)
  } catch {
    // 用户取消删除
  }
}

// 处理搜索
const handleSearch = () => {
  emit('search', searchForm.value?.formData)
}

// 处理重置搜索
const handleResetSearch = () => {
  searchForm.value?.resetFields()
  emit('reset')
}

// 刷新数据
const refreshData = () => {
  emit('refresh')
}

// 处理每页条数变化
const handleSizeChange = (val: number) => {
  pageSize.value = val
  emit('size-change', val)
}

// 处理页码变化
const handleCurrentChange = (val: number) => {
  currentPage.value = val
  emit('current-change', val)
}

// 暴露方法给父组件
defineExpose({
  tableRef,
  searchForm,
  refresh: refreshData,
  clearSelection: () => tableRef.value?.clearSelection()
})
</script>

<style lang="scss" scoped>
.base-table {
  .search-area {
    margin-bottom: 16px;
    padding: 16px;
    background-color: var(--el-bg-color-page);
    border-radius: 4px;
  }

  .toolbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;
  }

  .pagination {
    margin-top: 16px;
    display: flex;
    justify-content: flex-end;
  }

  .column-item {
    padding: 8px 16px;
  }
}
</style> 