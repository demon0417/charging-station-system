<template>
  <div class="upload-container">
    <el-upload
      ref="uploadRef"
      :action="action"
      :headers="headers"
      :multiple="multiple"
      :limit="limit"
      :file-list="fileList"
      :on-preview="handlePreview"
      :on-remove="handleRemove"
      :on-success="handleSuccess"
      :on-error="handleError"
      :before-upload="beforeUpload"
      :on-exceed="handleExceed"
      :accept="accept"
      :drag="drag"
      :disabled="disabled"
      :auto-upload="autoUpload"
    >
      <template #trigger>
        <slot name="trigger">
          <el-button type="primary">选择文件</el-button>
        </slot>
      </template>
      
      <template #tip>
        <slot name="tip">
          <div class="el-upload__tip" v-if="tip">{{ tip }}</div>
        </slot>
      </template>
      
      <template #default>
        <slot>
          <div v-if="drag" class="upload-drag">
            <el-icon class="el-icon--upload"><upload-filled /></el-icon>
            <div class="el-upload__text">
              将文件拖到此处或<em>点击上传</em>
            </div>
          </div>
        </slot>
      </template>
    </el-upload>

    <!-- 预览对话框 -->
    <el-dialog v-model="previewVisible" title="文件预览">
      <div class="preview-content">
        <img v-if="isImage" :src="previewUrl" alt="预览图片" />
        <iframe v-else-if="isPdf" :src="previewUrl" width="100%" height="500px" />
        <div v-else class="preview-fallback">
          该文件类型不支持预览
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { ElMessage } from 'element-plus'
import type { UploadInstance, UploadProps, UploadRawFile } from 'element-plus'

const props = defineProps({
  action: {
    type: String,
    required: true
  },
  headers: {
    type: Object,
    default: () => ({})
  },
  multiple: {
    type: Boolean,
    default: false
  },
  limit: {
    type: Number,
    default: 5
  },
  accept: {
    type: String,
    default: ''
  },
  tip: {
    type: String,
    default: ''
  },
  drag: {
    type: Boolean,
    default: false
  },
  disabled: {
    type: Boolean,
    default: false
  },
  autoUpload: {
    type: Boolean,
    default: true
  },
  maxSize: {
    type: Number,
    default: 10 // MB
  }
})

const emit = defineEmits([
  'success',
  'error',
  'remove',
  'exceed',
  'preview',
  'update:fileList'
])

const uploadRef = ref<UploadInstance>()
const fileList = ref<UploadProps['fileList']>([])
const previewVisible = ref(false)
const previewUrl = ref('')

const isImage = computed(() => {
  return /\.(jpg|jpeg|png|gif)$/i.test(previewUrl.value)
})

const isPdf = computed(() => {
  return /\.pdf$/i.test(previewUrl.value)
})

const handlePreview = async (file: UploadProps['fileList'][number]) => {
  previewUrl.value = file.url || ''
  previewVisible.value = true
  emit('preview', file)
}

const handleRemove = (file: UploadProps['fileList'][number]) => {
  fileList.value = fileList.value?.filter(f => f.uid !== file.uid)
  emit('remove', file)
  emit('update:fileList', fileList.value)
}

const handleSuccess = (response: any, file: UploadProps['fileList'][number]) => {
  ElMessage.success('上传成功')
  emit('success', { response, file })
}

const handleError = (error: Error, file: UploadProps['fileList'][number]) => {
  ElMessage.error('上传失败')
  emit('error', { error, file })
}

const beforeUpload = (file: UploadRawFile) => {
  // 检查文件大小
  const isLt = file.size / 1024 / 1024 < props.maxSize
  if (!isLt) {
    ElMessage.error(`文件大小不能超过 ${props.maxSize}MB!`)
    return false
  }
  return true
}

const handleExceed = (files: File[]) => {
  ElMessage.warning(`最多只能上传 ${props.limit} 个文件`)
  emit('exceed', files)
}

// 暴露方法给父组件
defineExpose({
  uploadRef,
  submit: () => uploadRef.value?.submit(),
  clearFiles: () => uploadRef.value?.clearFiles()
})
</script>

<style scoped>
.upload-container {
  width: 100%;
}

.upload-drag {
  padding: 40px;
  text-align: center;
  border: 1px dashed var(--el-border-color);
  border-radius: 6px;
  cursor: pointer;
  transition: border-color 0.3s;
}

.upload-drag:hover {
  border-color: var(--el-color-primary);
}

.el-icon--upload {
  font-size: 48px;
  color: var(--el-text-color-secondary);
  margin-bottom: 16px;
}

.el-upload__text {
  color: var(--el-text-color-regular);
  font-size: 14px;
}

.el-upload__text em {
  color: var(--el-color-primary);
  font-style: normal;
}

.preview-content {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 200px;
}

.preview-fallback {
  color: var(--el-text-color-secondary);
  font-size: 14px;
}

img {
  max-width: 100%;
  max-height: 500px;
}
</style> 