<template>
  <div class="preview-container">
    <!-- 图片预览 -->
    <div v-if="isImage" class="image-preview">
      <el-image
        :src="url"
        :preview-src-list="[url]"
        fit="contain"
        :initial-index="0"
      >
        <template #error>
          <div class="error-placeholder">
            <el-icon><Picture /></el-icon>
            <span>加载失败</span>
          </div>
        </template>
      </el-image>
    </div>

    <!-- PDF预览 -->
    <div v-else-if="isPdf" class="pdf-preview">
      <iframe :src="url" width="100%" height="100%" frameborder="0" />
    </div>

    <!-- 视频预览 -->
    <div v-else-if="isVideo" class="video-preview">
      <video
        controls
        :src="url"
        class="video-player"
      >
        您的浏览器不支持视频播放
      </video>
    </div>

    <!-- 音频预览 -->
    <div v-else-if="isAudio" class="audio-preview">
      <audio
        controls
        :src="url"
        class="audio-player"
      >
        您的浏览器不支持音频播放
      </audio>
    </div>

    <!-- 文本预览 -->
    <div v-else-if="isText" class="text-preview">
      <pre v-if="textContent" class="text-content">{{ textContent }}</pre>
      <div v-else class="loading-text">
        <el-icon class="loading-icon"><Loading /></el-icon>
        加载中...
      </div>
    </div>

    <!-- 其他文件类型 -->
    <div v-else class="fallback-preview">
      <el-icon class="file-icon"><Document /></el-icon>
      <div class="file-info">
        <div class="file-name">{{ fileName }}</div>
        <div class="file-type">{{ fileType }}</div>
      </div>
      <el-button type="primary" @click="downloadFile">
        下载文件
      </el-button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { Picture, Document, Loading } from '@element-plus/icons-vue'

const props = defineProps<{
  url: string
  fileName?: string
  fileType?: string
}>()

const textContent = ref('')

const isImage = computed(() => {
  return /\.(jpg|jpeg|png|gif|bmp|webp)$/i.test(props.url)
})

const isPdf = computed(() => {
  return /\.pdf$/i.test(props.url)
})

const isVideo = computed(() => {
  return /\.(mp4|webm|ogg)$/i.test(props.url)
})

const isAudio = computed(() => {
  return /\.(mp3|wav|ogg)$/i.test(props.url)
})

const isText = computed(() => {
  return /\.(txt|log|md|json|xml|html|css|js)$/i.test(props.url)
})

const loadTextContent = async () => {
  if (!isText.value) return
  
  try {
    const response = await fetch(props.url)
    textContent.value = await response.text()
  } catch (error) {
    console.error('加载文本内容失败:', error)
    textContent.value = '加载失败'
  }
}

const downloadFile = () => {
  const link = document.createElement('a')
  link.href = props.url
  link.download = props.fileName || 'download'
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
}

onMounted(() => {
  if (isText.value) {
    loadTextContent()
  }
})
</script>

<style scoped>
.preview-container {
  width: 100%;
  height: 100%;
  min-height: 200px;
  display: flex;
  justify-content: center;
  align-items: center;
}

.image-preview,
.pdf-preview,
.video-preview,
.audio-preview,
.text-preview {
  width: 100%;
  height: 100%;
}

.error-placeholder {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  color: var(--el-text-color-secondary);
  font-size: 14px;
  
  .el-icon {
    font-size: 48px;
    margin-bottom: 8px;
  }
}

.video-player,
.audio-player {
  width: 100%;
  max-width: 800px;
}

.text-preview {
  padding: 16px;
  background-color: var(--el-bg-color-page);
  border-radius: 4px;
}

.text-content {
  margin: 0;
  white-space: pre-wrap;
  word-wrap: break-word;
  font-family: monospace;
}

.loading-text {
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--el-text-color-secondary);
  
  .loading-icon {
    margin-right: 8px;
    animation: rotate 1s linear infinite;
  }
}

.fallback-preview {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 24px;
  
  .file-icon {
    font-size: 48px;
    color: var(--el-text-color-secondary);
    margin-bottom: 16px;
  }
  
  .file-info {
    text-align: center;
    margin-bottom: 16px;
    
    .file-name {
      font-size: 16px;
      color: var(--el-text-color-primary);
      margin-bottom: 4px;
    }
    
    .file-type {
      font-size: 14px;
      color: var(--el-text-color-secondary);
    }
  }
}

@keyframes rotate {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}
</style> 