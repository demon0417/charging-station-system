<template>
  <el-dropdown trigger="click" @command="handleThemeChange">
    <el-button type="text">
      <el-icon :size="20">
        <component :is="isDark ? 'Moon' : 'Sunny'" />
      </el-icon>
    </el-button>
    <template #dropdown>
      <el-dropdown-menu>
        <el-dropdown-item command="light">
          <el-icon><Sunny /></el-icon>
          浅色主题
        </el-dropdown-item>
        <el-dropdown-item command="dark">
          <el-icon><Moon /></el-icon>
          深色主题
        </el-dropdown-item>
        <el-dropdown-item command="system">
          <el-icon><Monitor /></el-icon>
          跟随系统
        </el-dropdown-item>
      </el-dropdown-menu>
    </template>
  </el-dropdown>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useThemeStore } from '@/store/theme'

const themeStore = useThemeStore()
const isDark = ref(false)

const handleThemeChange = (theme: string) => {
  themeStore.setTheme(theme)
  updateTheme()
}

const updateTheme = () => {
  isDark.value = themeStore.isDark
  document.documentElement.className = isDark.value ? 'dark' : ''
}

onMounted(() => {
  updateTheme()
})
</script> 