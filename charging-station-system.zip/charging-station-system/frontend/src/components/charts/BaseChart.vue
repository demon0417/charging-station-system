<template>
  <div class="chart-container">
    <div ref="chartRef" :style="{ height: height + 'px', width: '100%' }" />
    <div v-if="loading" class="loading-mask">
      <el-icon class="loading-icon"><Loading /></el-icon>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, watch } from 'vue'
import * as echarts from 'echarts'
import type { EChartsOption } from 'echarts'

const props = defineProps<{
  options: EChartsOption
  height?: number
  loading?: boolean
  theme?: string
  autoResize?: boolean
}>()

const chartRef = ref<HTMLElement>()
let chart: echarts.ECharts | null = null

const initChart = () => {
  if (!chartRef.value) return
  
  chart = echarts.init(chartRef.value, props.theme)
  updateChart()
}

const updateChart = () => {
  if (!chart) return
  chart.setOption(props.options)
}

const handleResize = () => {
  chart?.resize()
}

watch(() => props.options, () => {
  updateChart()
}, { deep: true })

onMounted(() => {
  initChart()
  if (props.autoResize) {
    window.addEventListener('resize', handleResize)
  }
})

onUnmounted(() => {
  if (props.autoResize) {
    window.removeEventListener('resize', handleResize)
  }
  chart?.dispose()
})

// 暴露方法给父组件
defineExpose({
  getChart: () => chart,
  resize: handleResize
})
</script>

<style scoped>
.chart-container {
  position: relative;
  width: 100%;
}

.loading-mask {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(255, 255, 255, 0.7);
  display: flex;
  justify-content: center;
  align-items: center;
}

.loading-icon {
  font-size: 24px;
  animation: rotate 1s linear infinite;
}

@keyframes rotate {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}
</style> 