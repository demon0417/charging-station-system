<template>
  <div class="dashboard-chart">
    <el-card>
      <template #header>
        <div class="card-header">
          <span>{{ title }}</span>
          <el-select v-model="timeRange" size="small">
            <el-option label="今日" value="today" />
            <el-option label="本周" value="week" />
            <el-option label="本月" value="month" />
          </el-select>
        </div>
      </template>
      <div ref="chartRef" :style="{ height: height + 'px' }" />
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, watch } from 'vue'
import * as echarts from 'echarts'
import type { EChartsOption } from 'echarts'

const props = defineProps<{
  title: string
  height?: number
  chartData: any
  chartType: 'line' | 'bar' | 'pie'
}>()

const chartRef = ref<HTMLElement>()
let chart: echarts.ECharts | null = null
const timeRange = ref('today')

const initChart = () => {
  if (!chartRef.value) return
  
  chart = echarts.init(chartRef.value)
  updateChart()
}

const updateChart = () => {
  if (!chart) return
  
  const options: EChartsOption = {
    tooltip: {
      trigger: 'axis'
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      data: props.chartData.xAxis
    },
    yAxis: {
      type: 'value'
    },
    series: [
      {
        type: props.chartType,
        data: props.chartData.series,
        smooth: true,
        areaStyle: props.chartType === 'line' ? {} : undefined
      }
    ]
  }
  
  chart.setOption(options)
}

watch(() => props.chartData, () => {
  updateChart()
}, { deep: true })

watch(timeRange, () => {
  // 触发数据重新加载
  emit('timeRangeChange', timeRange.value)
})

onMounted(() => {
  initChart()
  window.addEventListener('resize', () => chart?.resize())
})

onUnmounted(() => {
  chart?.dispose()
  window.removeEventListener('resize', () => chart?.resize())
})
</script>

<style scoped>
.dashboard-chart {
  width: 100%;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
</style> 