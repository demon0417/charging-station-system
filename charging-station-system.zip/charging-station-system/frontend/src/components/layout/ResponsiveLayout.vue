<template>
  <div class="responsive-layout" :class="{ 'is-mobile': isMobile }">
    <!-- 侧边栏 -->
    <el-drawer
      v-model="showSidebar"
      direction="ltr"
      size="200px"
      v-if="isMobile"
    >
      <sidebar-content />
    </el-drawer>

    <el-aside width="200px" v-else>
      <sidebar-content />
    </el-aside>

    <!-- 主内容区 -->
    <el-container>
      <el-header height="60px">
        <div class="header-content">
          <el-button v-if="isMobile" @click="showSidebar = true">
            <el-icon><Menu /></el-icon>
          </el-button>
          <div class="header-right">
            <theme-switcher />
            <language-switcher />
            <user-menu />
          </div>
        </div>
      </el-header>

      <el-main>
        <router-view v-slot="{ Component }">
          <transition name="page" mode="out-in">
            <component :is="Component" />
          </transition>
        </router-view>
      </el-main>
    </el-container>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted } from 'vue'
import SidebarContent from './SidebarContent.vue'
import ThemeSwitcher from '../ThemeSwitcher.vue'
import LanguageSwitcher from '../LanguageSwitcher.vue'
import UserMenu from '../UserMenu.vue'

const showSidebar = ref(false)
const isMobile = ref(false)

const checkMobile = () => {
  isMobile.value = window.innerWidth < 768
}

onMounted(() => {
  checkMobile()
  window.addEventListener('resize', checkMobile)
})

onUnmounted(() => {
  window.removeEventListener('resize', checkMobile)
})
</script>

<style lang="scss" scoped>
.responsive-layout {
  height: 100vh;
  display: flex;

  &.is-mobile {
    .el-container {
      width: 100%;
    }
  }
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  height: 100%;
  padding: 0 20px;
}

.header-right {
  display: flex;
  align-items: center;
  gap: 16px;
}

@media (max-width: 768px) {
  .el-main {
    padding: 10px;
  }
}
</style> 