<template>
  <div class="sidebar-content">
    <div class="logo">
      <img src="@/assets/logo.png" alt="Logo">
      <h1>充电站管理系统</h1>
    </div>
    
    <el-menu
      :default-active="activeMenu"
      :router="true"
      :collapse="isCollapse"
    >
      <el-menu-item index="/">
        <el-icon><Monitor /></el-icon>
        <span>{{ $t('menu.dashboard') }}</span>
      </el-menu-item>
      
      <el-menu-item index="/charging">
        <el-icon><Lightning /></el-icon>
        <span>{{ $t('menu.charging') }}</span>
      </el-menu-item>
      
      <el-menu-item index="/parking">
        <el-icon><Van /></el-icon>
        <span>{{ $t('menu.parking') }}</span>
      </el-menu-item>
      
      <el-menu-item index="/vehicle">
        <el-icon><List /></el-icon>
        <span>{{ $t('menu.vehicle') }}</span>
      </el-menu-item>
      
      <el-menu-item index="/statistics" v-if="isAdmin">
        <el-icon><TrendCharts /></el-icon>
        <span>{{ $t('menu.statistics') }}</span>
      </el-menu-item>
    </el-menu>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import { useAuthStore } from '@/store/auth'

const route = useRoute()
const authStore = useAuthStore()

const activeMenu = computed(() => route.path)
const isAdmin = computed(() => authStore.isAdmin)
const isCollapse = computed(() => false) // 可以根据需要添加折叠功能
</script>

<style lang="scss" scoped>
.sidebar-content {
  height: 100%;
  display: flex;
  flex-direction: column;
  
  .logo {
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
    
    img {
      width: 32px;
      height: 32px;
    }
    
    h1 {
      margin: 0;
      font-size: 16px;
      color: var(--el-text-color-primary);
    }
  }
  
  .el-menu {
    flex: 1;
    border-right: none;
  }
}
</style> 