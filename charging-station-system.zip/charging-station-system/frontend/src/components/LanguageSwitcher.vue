<template>
  <el-dropdown trigger="click" @command="handleLanguageChange">
    <el-button type="text">
      <el-icon :size="20">
        <component :is="currentLanguageIcon" />
      </el-icon>
    </el-button>
    <template #dropdown>
      <el-dropdown-menu>
        <el-dropdown-item command="zh-CN">
          <el-icon><Flag /></el-icon>
          简体中文
        </el-dropdown-item>
        <el-dropdown-item command="en-US">
          <el-icon><Flag /></el-icon>
          English
        </el-dropdown-item>
      </el-dropdown-menu>
    </template>
  </el-dropdown>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useI18n } from 'vue-i18n'

const { locale } = useI18n()

const currentLanguageIcon = computed(() => {
  return locale.value === 'zh-CN' ? 'Flag' : 'Flag'
})

const handleLanguageChange = (lang: string) => {
  locale.value = lang
  localStorage.setItem('language', lang)
}
</script> 