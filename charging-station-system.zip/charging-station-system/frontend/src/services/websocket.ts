import { Client } from '@stomp/stompjs';
import { useChargingStore } from '@/store/charging';
import { useParkingStore } from '@/store/parking';

export class WebSocketService {
  private client: Client;
  private chargingStore = useChargingStore();
  private parkingStore = useParkingStore();

  constructor() {
    this.client = new Client({
      brokerURL: 'ws://localhost:8080/ws',
      reconnectDelay: 5000,
      heartbeatIncoming: 4000,
      heartbeatOutgoing: 4000
    });

    this.client.onConnect = () => {
      this.subscribeToTopics();
    };

    this.client.onStompError = (frame) => {
      console.error('WebSocket错误:', frame);
    };
  }

  public connect() {
    this.client.activate();
  }

  public disconnect() {
    this.client.deactivate();
  }

  private subscribeToTopics() {
    // 订阅充电状态更新
    this.client.subscribe('/topic/charging-status', (message) => {
      const status = JSON.parse(message.body);
      this.chargingStore.updateChargingStatus(status);
    });

    // 订阅停车状态更新
    this.client.subscribe('/topic/parking-status', (message) => {
      const status = JSON.parse(message.body);
      this.parkingStore.updateParkingStatus(status);
    });

    // 订阅告警消息
    this.client.subscribe('/topic/alerts', (message) => {
      const alert = JSON.parse(message.body);
      // 显示告警通知
      this.showAlert(alert);
    });
  }

  private showAlert(alert: any) {
    // 使用Element Plus的通知组件
    ElNotification({
      title: alert.title,
      message: alert.message,
      type: alert.type,
      duration: 5000
    });
  }
}

export const wsService = new WebSocketService(); 