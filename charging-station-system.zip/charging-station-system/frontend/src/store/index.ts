import { defineStore } from 'pinia';
import { ref, computed } from 'vue';
import type { User } from '@/types';
import { login, refreshToken } from '@/api/auth';

export const useAuthStore = defineStore('auth', () => {
  const user = ref<User | null>(null);
  const token = ref<string | null>(null);
  const refreshTokenValue = ref<string | null>(null);

  const isAuthenticated = computed(() => !!token.value);
  const isAdmin = computed(() => user.value?.role === 'ADMIN');

  async function loginUser(username: string, password: string) {
    const response = await login(username, password);
    user.value = {
      username: response.username,
      role: response.role
    };
    token.value = response.accessToken;
    refreshTokenValue.value = response.refreshToken;
    
    localStorage.setItem('token', response.accessToken);
    localStorage.setItem('refreshToken', response.refreshToken);
    localStorage.setItem('userRole', response.role);
  }

  async function refreshUserToken() {
    if (!refreshTokenValue.value) return;
    
    try {
      const response = await refreshToken(refreshTokenValue.value);
      token.value = response.accessToken;
      refreshTokenValue.value = response.refreshToken;
      
      localStorage.setItem('token', response.accessToken);
      localStorage.setItem('refreshToken', response.refreshToken);
    } catch (error) {
      logout();
    }
  }

  function logout() {
    user.value = null;
    token.value = null;
    refreshTokenValue.value = null;
    localStorage.removeItem('token');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('userRole');
  }

  return {
    user,
    token,
    isAuthenticated,
    isAdmin,
    loginUser,
    refreshUserToken,
    logout
  };
}); 