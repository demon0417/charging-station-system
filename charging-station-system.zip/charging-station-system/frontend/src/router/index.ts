import { createRouter, createWebHistory } from 'vue-router';
import Layout from '@/layouts/MainLayout.vue';
import LoginView from '@/views/auth/LoginView.vue';
import DashboardView from '@/views/dashboard/DashboardView.vue';
import ChargingView from '@/views/charging/ChargingView.vue';
import ParkingView from '@/views/parking/ParkingView.vue';
import VehicleView from '@/views/vehicle/VehicleView.vue';
import StatisticsView from '@/views/statistics/StatisticsView.vue';

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/login',
      name: 'login',
      component: LoginView,
      meta: { requiresAuth: false }
    },
    {
      path: '/',
      component: Layout,
      meta: { requiresAuth: true },
      children: [
        {
          path: '',
          name: 'dashboard',
          component: DashboardView
        },
        {
          path: 'charging',
          name: 'charging',
          component: ChargingView
        },
        {
          path: 'parking',
          name: 'parking',
          component: ParkingView
        },
        {
          path: 'vehicle',
          name: 'vehicle',
          component: VehicleView
        },
        {
          path: 'statistics',
          name: 'statistics',
          component: StatisticsView,
          meta: { requiresAdmin: true }
        }
      ]
    }
  ]
});

// 路由守卫
router.beforeEach((to, from, next) => {
  const token = localStorage.getItem('token');
  const userRole = localStorage.getItem('userRole');

  if (to.meta.requiresAuth && !token) {
    next('/login');
  } else if (to.meta.requiresAdmin && userRole !== 'ADMIN') {
    next('/');
  } else {
    next();
  }
});

export default router; 