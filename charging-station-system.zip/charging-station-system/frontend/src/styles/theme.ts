import { ThemeConfig } from 'element-plus'

export const lightTheme: ThemeConfig = {
  primary: '#409EFF',
  success: '#67C23A',
  warning: '#E6A23C',
  danger: '#F56C6C',
  info: '#909399',
  
  // 自定义主题变量
  '--el-color-primary': '#409EFF',
  '--el-color-success': '#67C23A',
  '--el-color-warning': '#E6A23C',
  '--el-color-danger': '#F56C6C',
  '--el-color-info': '#909399',
  
  // 背景色
  '--el-bg-color': '#ffffff',
  '--el-bg-color-page': '#f2f3f5',
  '--el-bg-color-overlay': '#ffffff',
  
  // 文字颜色
  '--el-text-color-primary': '#303133',
  '--el-text-color-regular': '#606266',
  '--el-text-color-secondary': '#909399',
  '--el-text-color-placeholder': '#c0c4cc',
  
  // 边框颜色
  '--el-border-color': '#dcdfe6',
  '--el-border-color-light': '#e4e7ed',
  '--el-border-color-lighter': '#ebeef5',
  '--el-border-color-extra-light': '#f2f6fc',
}

export const darkTheme: ThemeConfig = {
  primary: '#409EFF',
  success: '#67C23A',
  warning: '#E6A23C',
  danger: '#F56C6C',
  info: '#909399',
  
  // 自定义主题变量
  '--el-color-primary': '#409EFF',
  '--el-color-success': '#67C23A',
  '--el-color-warning': '#E6A23C',
  '--el-color-danger': '#F56C6C',
  '--el-color-info': '#909399',
  
  // 背景色
  '--el-bg-color': '#141414',
  '--el-bg-color-page': '#0a0a0a',
  '--el-bg-color-overlay': '#1d1e1f',
  
  // 文字颜色
  '--el-text-color-primary': '#ffffff',
  '--el-text-color-regular': '#d0d0d0',
  '--el-text-color-secondary': '#a8a8a8',
  '--el-text-color-placeholder': '#8c8c8c',
  
  // 边框颜色
  '--el-border-color': '#434343',
  '--el-border-color-light': '#434343',
  '--el-border-color-lighter': '#434343',
  '--el-border-color-extra-light': '#434343',
} 