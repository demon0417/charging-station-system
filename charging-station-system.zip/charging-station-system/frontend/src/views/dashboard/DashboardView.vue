<template>
  <div class="dashboard">
    <el-row :gutter="20">
      <!-- 统计卡片 -->
      <el-col :span="6" v-for="stat in statistics" :key="stat.title">
        <el-card class="stat-card" :body-style="{ padding: '20px' }">
          <div class="stat-content">
            <div class="stat-icon">
              <el-icon :size="24">
                <component :is="stat.icon" />
              </el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-title">{{ stat.title }}</div>
              <div class="stat-value">{{ stat.value }}</div>
              <div class="stat-change" :class="stat.trend">
                {{ stat.change }}%
                <el-icon>
                  <component :is="stat.trend === 'up' ? 'ArrowUp' : 'ArrowDown'" />
                </el-icon>
              </div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="20" class="chart-row">
      <!-- 收入趋势图 -->
      <el-col :span="12">
        <dashboard-chart
          title="收入趋势"
          :chart-data="incomeData"
          chart-type="line"
          :height="350"
          @timeRangeChange="handleIncomeTimeRangeChange"
        />
      </el-col>
      
      <!-- 使用率分析 -->
      <el-col :span="12">
        <dashboard-chart
          title="使用率分析"
          :chart-data="usageData"
          chart-type="bar"
          :height="350"
          @timeRangeChange="handleUsageTimeRangeChange"
        />
      </el-col>
    </el-row>

    <el-row :gutter="20" class="chart-row">
      <!-- 车辆类型分布 -->
      <el-col :span="8">
        <dashboard-chart
          title="车辆类型分布"
          :chart-data="vehicleTypeData"
          chart-type="pie"
          :height="300"
        />
      </el-col>
      
      <!-- 实时监控 -->
      <el-col :span="16">
        <el-card>
          <template #header>
            <div class="card-header">
              <span>实时监控</span>
              <el-button type="text" @click="refreshMonitoring">刷新</el-button>
            </div>
          </template>
          <el-table :data="monitoringData" height="250" stripe>
            <el-table-column prop="deviceId" label="设备ID" width="120" />
            <el-table-column prop="status" label="状态">
              <template #default="{ row }">
                <el-tag :type="row.status === 'online' ? 'success' : 'danger'">
                  {{ row.status === 'online' ? '在线' : '离线' }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="currentPower" label="当前功率" />
            <el-table-column prop="lastUpdate" label="最后更新时间" />
          </el-table>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import DashboardChart from '@/components/charts/DashboardChart.vue'
import { useDeviceStore } from '@/store/device'
import { useStatisticsStore } from '@/store/statistics'

const deviceStore = useDeviceStore()
const statisticsStore = useStatisticsStore()

const statistics = ref([
  {
    title: '今日收入',
    value: '¥0',
    change: 0,
    trend: 'up',
    icon: 'Money'
  },
  {
    title: '当前充电',
    value: '0',
    change: 0,
    trend: 'up',
    icon: 'Lightning'
  },
  {
    title: '当前停车',
    value: '0',
    change: 0,
    trend: 'down',
    icon: 'Van'
  },
  {
    title: '设备在线率',
    value: '0%',
    change: 0,
    trend: 'up',
    icon: 'Monitor'
  }
])

const incomeData = ref({
  xAxis: [],
  series: []
})

const usageData = ref({
  xAxis: [],
  series: []
})

const vehicleTypeData = ref({
  series: []
})

const monitoringData = ref([])

const loadData = async () => {
  // 加载统计数据
  const dailyStats = await statisticsStore.getDailyStatistics()
  statistics.value[0].value = `¥${dailyStats.totalIncome}`
  statistics.value[1].value = dailyStats.currentCharging.toString()
  statistics.value[2].value = dailyStats.currentParking.toString()
  statistics.value[3].value = `${dailyStats.deviceOnlineRate}%`
  
  // 加载图表数据
  const [income, usage, vehicleType] = await Promise.all([
    statisticsStore.getIncomeData(),
    statisticsStore.getUsageData(),
    statisticsStore.getVehicleTypeData()
  ])
  
  incomeData.value = income
  usageData.value = usage
  vehicleTypeData.value = vehicleType
  
  // 加载监控数据
  monitoringData.value = await deviceStore.getDeviceStatus()
}

const handleIncomeTimeRangeChange = (range: string) => {
  // 重新加载收入数据
  statisticsStore.getIncomeData(range).then(data => {
    incomeData.value = data
  })
}

const handleUsageTimeRangeChange = (range: string) => {
  // 重新加载使用率数据
  statisticsStore.getUsageData(range).then(data => {
    usageData.value = data
  })
}

const refreshMonitoring = () => {
  deviceStore.getDeviceStatus().then(data => {
    monitoringData.value = data
  })
}

onMounted(() => {
  loadData()
})
</script>

<style scoped>
.dashboard {
  padding: 20px;
}

.chart-row {
  margin-top: 20px;
}

.stat-card {
  margin-bottom: 20px;
}

.stat-content {
  display: flex;
  align-items: center;
}

.stat-icon {
  margin-right: 16px;
  padding: 12px;
  border-radius: 8px;
  background-color: var(--el-color-primary-light-9);
}

.stat-info {
  flex: 1;
}

.stat-title {
  font-size: 14px;
  color: var(--el-text-color-secondary);
}

.stat-value {
  font-size: 24px;
  font-weight: bold;
  margin: 8px 0;
}

.stat-change {
  font-size: 12px;
  display: flex;
  align-items: center;
  
  &.up {
    color: var(--el-color-success);
  }
  
  &.down {
    color: var(--el-color-danger);
  }
}
</style> 