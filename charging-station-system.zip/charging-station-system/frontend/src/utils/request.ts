import axios from 'axios';
import { useAuthStore } from '@/store/auth';
import router from '@/router';

const request = axios.create({
  baseURL: '/api',
  timeout: 10000
});

// 请求拦截器
request.interceptors.request.use(
  (config) => {
    const authStore = useAuthStore();
    if (authStore.token) {
      config.headers.Authorization = `Bearer ${authStore.token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// 响应拦截器
request.interceptors.response.use(
  (response) => {
    return response.data;
  },
  async (error) => {
    const authStore = useAuthStore();
    
    if (error.response?.status === 401) {
      // token过期，尝试刷新
      try {
        await authStore.refreshUserToken();
        // 重试原请求
        return request(error.config);
      } catch (refreshError) {
        // 刷新token失败，退出登录
        authStore.logout();
        router.push('/login');
      }
    }
    
    // 显示错误提示
    ElMessage.error(error.response?.data?.message || '请求失败');
    return Promise.reject(error);
  }
);

export default request; 