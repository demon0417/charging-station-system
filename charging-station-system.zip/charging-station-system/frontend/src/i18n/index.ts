import { createI18n } from 'vue-i18n'

const messages = {
  'zh-CN': {
    common: {
      confirm: '确认',
      cancel: '取消',
      save: '保存',
      delete: '删除',
      edit: '编辑',
      search: '搜索',
      loading: '加载中...',
      noData: '暂无数据'
    },
    auth: {
      login: '登录',
      logout: '退出登录',
      username: '用户名',
      password: '密码',
      rememberMe: '记住我',
      loginSuccess: '登录成功',
      loginFailed: '登录失败'
    },
    dashboard: {
      title: '仪表盘',
      todayIncome: '今日收入',
      currentCharging: '当前充电',
      currentParking: '当前停车',
      deviceOnline: '设备在线率',
      incomeTrend: '收入趋势',
      usageAnalysis: '使用率分析',
      vehicleTypes: '车辆类型分布',
      realTimeMonitor: '实时监控'
    },
    vehicle: {
      plateNumber: '车牌号',
      type: '车型',
      entryTime: '入场时间',
      exitTime: '出场时间',
      status: '状态'
    },
    charging: {
      startCharging: '开始充电',
      stopCharging: '停止充电',
      chargingTime: '充电时长',
      powerConsumption: '用电量',
      chargingFee: '充电费用'
    },
    parking: {
      startParking: '开始停车',
      stopParking: '结束停车',
      parkingTime: '停车时长',
      parkingFee: '停车费用'
    }
  },
  'en-US': {
    common: {
      confirm: 'Confirm',
      cancel: 'Cancel',
      save: 'Save',
      delete: 'Delete',
      edit: 'Edit',
      search: 'Search',
      loading: 'Loading...',
      noData: 'No Data'
    },
    auth: {
      login: 'Login',
      logout: 'Logout',
      username: 'Username',
      password: 'Password',
      rememberMe: 'Remember Me',
      loginSuccess: 'Login Success',
      loginFailed: 'Login Failed'
    },
    dashboard: {
      title: 'Dashboard',
      todayIncome: "Today's Income",
      currentCharging: 'Current Charging',
      currentParking: 'Current Parking',
      deviceOnline: 'Device Online Rate',
      incomeTrend: 'Income Trend',
      usageAnalysis: 'Usage Analysis',
      vehicleTypes: 'Vehicle Types',
      realTimeMonitor: 'Real-time Monitor'
    },
    vehicle: {
      plateNumber: 'Plate Number',
      type: 'Type',
      entryTime: 'Entry Time',
      exitTime: 'Exit Time',
      status: 'Status'
    },
    charging: {
      startCharging: 'Start Charging',
      stopCharging: 'Stop Charging',
      chargingTime: 'Charging Time',
      powerConsumption: 'Power Consumption',
      chargingFee: 'Charging Fee'
    },
    parking: {
      startParking: 'Start Parking',
      stopParking: 'Stop Parking',
      parkingTime: 'Parking Time',
      parkingFee: 'Parking Fee'
    }
  }
}

export default createI18n({
  locale: localStorage.getItem('language') || 'zh-CN',
  fallbackLocale: 'zh-CN',
  messages,
  legacy: false
}) 